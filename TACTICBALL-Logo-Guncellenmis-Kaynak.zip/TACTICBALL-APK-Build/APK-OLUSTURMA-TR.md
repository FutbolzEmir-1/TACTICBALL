# TACTICBALL APK oluşturma

Bu klasör, kullanıcının verdiği TACTICBALL React/Vite kaynak kodunu Android APK'ya dönüştürmek için hazırlanmıştır.

## APK'yı bulutta oluşturma
1. Bu ZIP'i bilgisayarda açın.
2. Klasörü kendi GitHub hesabınızda yeni bir depoya (repository) yükleyin.
3. GitHub'da deponun **Actions** sekmesini açın.
4. Soldan **Build TACTICBALL APK** iş akışını seçin.
5. **Run workflow** düğmesine basın.
6. İşlem başarılı olunca çalışmanın altındaki **Artifacts** bölümünden `TACTICBALL-debug-apk` dosyasını indirin.
7. ZIP'i açın; içindeki `app-debug.apk` Android telefona kurulabilir.

## Önemli
- Bu kaynak paketinde Android SDK/Gradle kurulu olmadığı için burada gerçek APK derlenemedi.
- GitHub Actions derlemesi internet erişimi ve GitHub hesabı gerektirir.
- Bu debug APK test ve kişisel kurulum içindir. Google Play yayını için ayrıca imzalı release AAB hazırlanmalı; gizlilik politikası, mağaza görselleri ve uygulama beyanları tamamlanmalıdır.
- Uygulamanın bazı özellikleri harici API anahtarı gerektiriyorsa ayrıca güvenli sunucu yapılandırması gerekebilir. API anahtarını uygulamanın içine açık şekilde koymayın.
