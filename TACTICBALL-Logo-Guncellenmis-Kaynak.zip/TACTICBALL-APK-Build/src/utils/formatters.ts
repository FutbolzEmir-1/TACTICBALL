import {
  Mentality,
  PassingStyle,
  PlayerRole,
  Position,
  PressingIntensity,
  TempoStyle,
  TrainingFocus,
} from '../types/game';

export const POSITION_LABEL: Record<Position, string> = {
  GK: 'KL',
  DEF: 'DEF',
  MID: 'ORT',
  FWD: 'FOR',
};

export const ROLE_LABELS: Record<PlayerRole, string> = {
  GK_SWEEPER: 'Libero Kaleci',
  GK_CLASSIC: 'Klasik Kaleci',
  DEF_STOPPER: 'Sert Stoper',
  DEF_BALL: 'Oyun Kurucu Stoper',
  DEF_WINGBACK: 'Hücumcu Kanat Bek',
  MID_ANCHOR: 'Ön Libero (6)',
  MID_B2B: 'İki Yönlü (Box-to-Box)',
  MID_MAESTRO: 'Derin Oyun Kurucu',
  MID_CAM: 'On Numara (10)',
  FWD_INSIDE: 'İçe Kateden Kanat',
  FWD_WINGER: 'Çizgi Kanat',
  FWD_COMPLETE: 'Komple Forvet',
  FWD_POACHER: 'Fırsatçı Golcü',
};

export const ROLES_BY_POSITION: Record<Position, PlayerRole[]> = {
  GK: ['GK_SWEEPER', 'GK_CLASSIC'],
  DEF: ['DEF_STOPPER', 'DEF_BALL', 'DEF_WINGBACK'],
  MID: ['MID_ANCHOR', 'MID_B2B', 'MID_MAESTRO', 'MID_CAM'],
  FWD: ['FWD_INSIDE', 'FWD_WINGER', 'FWD_COMPLETE', 'FWD_POACHER'],
};

export const MENTALITY_LABELS: Record<Mentality, string> = {
  DEFENSIVE: 'Savunma Güvenliği',
  BALANCED: 'Dengeli Oyun',
  ATTACKING: 'Hücum Ağırlıklı',
  ALL_OUT: 'Tam Saha Hücum',
};

export const PRESSING_LABELS: Record<PressingIntensity, string> = {
  LOW: 'Düşük Blok (Kontra)',
  MEDIUM: 'Orta Saha Baskısı',
  GEGENPRESS: 'Gegenpress (Şok Baskı)',
};

export const PASSING_LABELS: Record<PassingStyle, string> = {
  SHORT: 'Kısa Pas (Tiki-Taka)',
  MIXED: 'Karma Pas',
  DIRECT: 'Direkt & Uzun Top',
};

export const TEMPO_LABELS: Record<TempoStyle, string> = {
  SLOW: 'Kontrollü Tempo',
  NORMAL: 'Standart Tempo',
  HIGH: 'Yüksek Tempo',
};

export const TRAINING_LABELS: Record<TrainingFocus, { title: string; desc: string }> = {
  BALANCED: { title: 'Dengeli Program', desc: 'Tüm özelliklerde istikrarlı koruma ve standart kondisyon.' },
  FITNESS: { title: 'Kondisyon & Güç', desc: 'Fiziksel gelişim artar; haftalık yorgunluk geri kazanımı biraz yavaşlar.' },
  ATTACK: { title: 'Hücum & Bitiricilik', desc: 'Genç forvet ve orta sahaların şut/bitiricilik gelişimi hızlanır.' },
  DEFENSE: { title: 'Savunma & Pozisyon', desc: 'Defans hattının markaj ve pozisyon alma gelişimi hızlanır.' },
  TACTICAL: { title: 'Taktiksel Uyum', desc: 'Pas kalitesi ve genç oyuncuların genel gelişim hızı yükselir.' },
  RECOVERY: { title: 'Rejenerasyon & Dinlenme', desc: 'Kondisyon toparlanması maksimuma çıkar, sakatlık riski düşer.' },
};

export function formatMoneyM(val: number): string {
  const sign = val < 0 ? '-' : '';
  return `${sign}€${Math.abs(val).toFixed(1)}M`;
}

export function formatWageK(val: number): string {
  return `€${Math.round(val)}K/hf`;
}
