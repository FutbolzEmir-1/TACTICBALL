import React from 'react';
import { Club } from '../types/game';

interface ClubCrestProps {
  club: Pick<
    Club,
    'id' | 'shortName' | 'primaryColor' | 'secondaryColor' | 'crestPattern' | 'crestIcon'
  >;
  size?: number;
  className?: string;
}

export const ClubCrest: React.FC<ClubCrestProps> = ({ club, size = 36, className = '' }) => {
  const clipId = `crest_clip_${club.id}_${size}`;

  const renderPattern = () => {
    switch (club.crestPattern) {
      case 'stripes':
        return (
          <>
            <rect x="0" y="0" width="64" height="64" fill={club.primaryColor} />
            <rect x="11" y="0" width="10" height="64" fill={club.secondaryColor} />
            <rect x="31" y="0" width="10" height="64" fill={club.secondaryColor} />
            <rect x="51" y="0" width="10" height="64" fill={club.secondaryColor} />
          </>
        );
      case 'halves':
        return (
          <>
            <rect x="0" y="0" width="32" height="64" fill={club.primaryColor} />
            <rect x="32" y="0" width="32" height="64" fill={club.secondaryColor} />
          </>
        );
      case 'sash':
        return (
          <>
            <rect x="0" y="0" width="64" height="64" fill={club.primaryColor} />
            <polygon points="-10,54 54,-10 74,10 10,74" fill={club.secondaryColor} />
          </>
        );
      case 'hoops':
        return (
          <>
            <rect x="0" y="0" width="64" height="64" fill={club.primaryColor} />
            <rect x="0" y="14" width="64" height="10" fill={club.secondaryColor} />
            <rect x="0" y="36" width="64" height="10" fill={club.secondaryColor} />
          </>
        );
      case 'chevron':
        return (
          <>
            <rect x="0" y="0" width="64" height="64" fill={club.primaryColor} />
            <polygon points="0,16 32,38 64,16 64,28 32,50 0,28" fill={club.secondaryColor} />
          </>
        );
      case 'cross':
        return (
          <>
            <rect x="0" y="0" width="64" height="64" fill={club.primaryColor} />
            <rect x="26" y="0" width="12" height="64" fill={club.secondaryColor} />
            <rect x="0" y="24" width="64" height="12" fill={club.secondaryColor} />
          </>
        );
      default:
        return <rect x="0" y="0" width="64" height="64" fill={club.primaryColor} />;
    }
  };

  const renderEmblem = () => {
    switch (club.crestIcon) {
      case 'crown':
        return (
          <path
            d="M20 38L23 24L29 30L32 21L35 30L41 24L44 38H20Z"
            fill="#F8FAFC"
            stroke="#0F172A"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
        );
      case 'star':
        return (
          <path
            d="M32 19L35.6 27.2L44.5 28L37.8 33.9L39.8 42.6L32 38L24.2 42.6L26.2 33.9L19.5 28L28.4 27.2L32 19Z"
            fill="#F8FAFC"
            stroke="#0F172A"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
        );
      case 'eagle':
        return (
          <path
            d="M18 25C24 23 28 25 32 29C36 25 40 23 46 25L41 34L35 32L32 42L29 32L23 34L18 25Z"
            fill="#F8FAFC"
            stroke="#0F172A"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
        );
      case 'lion':
        return (
          <path
            d="M24 24L32 19L40 24L42 33L32 42L22 33L24 24ZM28 29H36L32 36L28 29Z"
            fill="#F8FAFC"
            stroke="#0F172A"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
        );
      case 'anchor':
        return (
          <path
            d="M32 20V41M26 25H38M22 34C22 39 27 42 32 42C37 42 42 39 42 34"
            fill="none"
            stroke="#F8FAFC"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
        );
      case 'flame':
        return (
          <path
            d="M32 19C36 25 40 29 40 34C40 39 36.5 43 32 43C27.5 43 24 39 24 34C24 30 27 27 29 24C30 26 31 27 32 19Z"
            fill="#F8FAFC"
            stroke="#0F172A"
            strokeWidth="1.6"
          />
        );
      default:
        return (
          <rect
            x="23"
            y="24"
            width="18"
            height="14"
            rx="3"
            fill="#0F172A"
            fillOpacity="0.82"
            stroke="#F8FAFC"
            strokeWidth="1.5"
          />
        );
    }
  };

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      className={`shrink-0 select-none ${className}`}
      aria-label={`${club.shortName} kulüp arması`}
    >
      <defs>
        <clipPath id={clipId}>
          <path d="M10 8H54V30C54 44 43 54 32 58C21 54 10 44 10 30V8Z" />
        </clipPath>
      </defs>
      <g clipPath={`url(#${clipId})`}>
        {renderPattern()}
        <rect x="0" y="0" width="64" height="64" fill="#000000" fillOpacity="0.16" />
        {renderEmblem()}
        <rect x="14" y="42" width="36" height="11" rx="2" fill="#0B0F17" fillOpacity="0.82" />
        <text
          x="32"
          y="50.5"
          textAnchor="middle"
          fill="#F8FAFC"
          fontSize="8.5"
          fontWeight="800"
          fontFamily="Barlow Condensed, sans-serif"
          letterSpacing="0.8"
        >
          {club.shortName}
        </text>
      </g>
      <path
        d="M10 8H54V30C54 44 43 54 32 58C21 54 10 44 10 30V8Z"
        fill="none"
        stroke="#E2E8F0"
        strokeOpacity="0.45"
        strokeWidth="2.4"
      />
    </svg>
  );
};
