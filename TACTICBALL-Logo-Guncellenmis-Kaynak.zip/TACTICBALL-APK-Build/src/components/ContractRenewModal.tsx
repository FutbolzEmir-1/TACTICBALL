import React, { useState } from 'react';
import { Player } from '../types/game';
import { formatWageK } from '../utils/formatters';
import { X } from 'lucide-react';

interface ContractRenewModalProps {
  player: Player;
  wageBudgetWeekly: number;
  currentClubWageTotal: number;
  onClose: () => void;
  onRenew: (playerId: string, newWage: number, newYears: number) => void;
}

export const ContractRenewModal: React.FC<ContractRenewModalProps> = ({
  player,
  wageBudgetWeekly,
  currentClubWageTotal,
  onClose,
  onRenew,
}) => {
  const expectedWage = Math.round(
    player.weeklyWage * (player.ovr >= 85 ? 1.15 : player.age >= 32 ? 0.95 : 1.08)
  );
  const [wage, setWage] = useState<number>(expectedWage);
  const [years, setYears] = useState<number>(Math.max(2, player.contractYearsLeft + 1));
  const [feedback, setFeedback] = useState<string>(
    `${player.name} mevcut sözleşmesini uzatmak için görüşmeye hazır.`
  );

  const handleSubmit = () => {
    const projectedTotal = currentClubWageTotal - player.weeklyWage + wage;
    if (projectedTotal > wageBudgetWeekly * 1.1) {
      setFeedback(
        `Maaş bütçesi limiti aşılıyor! (Yeni toplam: ${formatWageK(projectedTotal)} / Limit: ${formatWageK(wageBudgetWeekly)})`
      );
      return;
    }
    if (wage < Math.round(expectedWage * 0.92)) {
      setFeedback(
        `${player.name} ve menajeri en az ${formatWageK(Math.round(expectedWage * 0.95))} haftalık maaş talep ediyor.`
      );
      return;
    }
    onRenew(player.id, wage, years);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#121824] border border-slate-700 rounded-xl p-6 space-y-4 shadow-2xl">
        <div className="flex items-start justify-between pb-3 border-b border-slate-800">
          <div>
            <div className="text-xs text-emerald-400 font-medium">Sözleşme Yenileme</div>
            <h3 className="text-lg font-bold text-white">{player.name}</h3>
            <div className="text-xs text-slate-400">
              Mevcut: {formatWageK(player.weeklyWage)} · Kalan: {player.contractYearsLeft} Yıl
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-3 rounded-lg bg-[#0B0F17] border border-slate-800 text-xs text-slate-300">
          {feedback}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <label className="block">
            <span className="text-xs text-slate-400">Yeni Haftalık Maaş (€K)</span>
            <input
              type="number"
              step={2}
              min={10}
              value={wage}
              onChange={(e) => setWage(Number(e.target.value))}
              className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono text-white"
            />
          </label>
          <label className="block">
            <span className="text-xs text-slate-400">Yeni Süre (Yıl)</span>
            <select
              value={years}
              onChange={(e) => setYears(Number(e.target.value))}
              className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono text-white"
            >
              {[2, 3, 4, 5].map((y) => (
                <option key={y} value={y}>
                  {y} Yıl
                </option>
              ))}
            </select>
          </label>
        </div>

        <button
          onClick={handleSubmit}
          className="w-full py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm cursor-pointer"
        >
          Yeni Sözleşmeyi İmzala
        </button>
      </div>
    </div>
  );
};
