import React, { useState } from 'react';
import { FORMATION_SLOTS, pickBestLineup } from '../data/database2026_27';
import { evaluateTeamStrength } from '../engine/matchEngine';
import {
  CareerState,
  ClubTactics,
  Formation,
  Mentality,
  PassingStyle,
  Player,
  PlayerRole,
  PressingIntensity,
  TempoStyle,
  TrainingFocus,
} from '../types/game';
import {
  formatMoneyM,
  formatWageK,
  MENTALITY_LABELS,
  PASSING_LABELS,
  POSITION_LABEL,
  PRESSING_LABELS,
  ROLE_LABELS,
  ROLES_BY_POSITION,
  TEMPO_LABELS,
  TRAINING_LABELS,
} from '../utils/formatters';
import { Activity, AlertCircle, ArrowLeftRight, Sparkles, Wand2 } from 'lucide-react';

interface SquadTacticsViewProps {
  state: CareerState;
  onUpdateTactics: (tactics: ClubTactics) => void;
  onUpdateLineup: (startingXI: string[], bench: string[]) => void;
  onUpdatePlayerRole: (playerId: string, role: PlayerRole) => void;
  onUpdateTraining: (focus: TrainingFocus) => void;
  onToggleTransferList: (playerId: string) => void;
  onOpenRenewContract: (player: Player) => void;
}

const PITCH_COORDS: Record<Formation, { x: number; y: number }[]> = {
  '4-3-3': [
    { x: 50, y: 90 },
    { x: 16, y: 72 },
    { x: 38, y: 74 },
    { x: 62, y: 74 },
    { x: 84, y: 72 },
    { x: 28, y: 49 },
    { x: 50, y: 54 },
    { x: 72, y: 49 },
    { x: 20, y: 22 },
    { x: 50, y: 16 },
    { x: 80, y: 22 },
  ],
  '4-2-3-1': [
    { x: 50, y: 90 },
    { x: 16, y: 72 },
    { x: 38, y: 74 },
    { x: 62, y: 74 },
    { x: 84, y: 72 },
    { x: 36, y: 55 },
    { x: 64, y: 55 },
    { x: 50, y: 36 },
    { x: 20, y: 30 },
    { x: 50, y: 15 },
    { x: 80, y: 30 },
  ],
  '3-5-2': [
    { x: 50, y: 90 },
    { x: 26, y: 73 },
    { x: 50, y: 75 },
    { x: 74, y: 73 },
    { x: 14, y: 50 },
    { x: 36, y: 54 },
    { x: 50, y: 42 },
    { x: 64, y: 54 },
    { x: 86, y: 50 },
    { x: 36, y: 18 },
    { x: 64, y: 18 },
  ],
  '4-4-2': [
    { x: 50, y: 90 },
    { x: 16, y: 72 },
    { x: 38, y: 74 },
    { x: 62, y: 74 },
    { x: 84, y: 72 },
    { x: 16, y: 46 },
    { x: 38, y: 50 },
    { x: 62, y: 50 },
    { x: 84, y: 46 },
    { x: 36, y: 18 },
    { x: 64, y: 18 },
  ],
  '3-4-3': [
    { x: 50, y: 90 },
    { x: 26, y: 73 },
    { x: 50, y: 75 },
    { x: 74, y: 73 },
    { x: 16, y: 49 },
    { x: 39, y: 52 },
    { x: 61, y: 52 },
    { x: 84, y: 49 },
    { x: 22, y: 21 },
    { x: 50, y: 15 },
    { x: 78, y: 21 },
  ],
  '5-3-2': [
    { x: 50, y: 90 },
    { x: 14, y: 66 },
    { x: 32, y: 74 },
    { x: 50, y: 76 },
    { x: 68, y: 74 },
    { x: 86, y: 66 },
    { x: 30, y: 48 },
    { x: 50, y: 52 },
    { x: 70, y: 48 },
    { x: 37, y: 18 },
    { x: 63, y: 18 },
  ],
};

export const SquadTacticsView: React.FC<SquadTacticsViewProps> = ({
  state,
  onUpdateTactics,
  onUpdateLineup,
  onUpdatePlayerRole,
  onUpdateTraining,
  onToggleTransferList,
  onOpenRenewContract,
}) => {
  const club = state.clubs[state.userClubId];
  const squad = Object.values(state.players)
    .filter((p) => p.clubId === club.id)
    .sort((a, b) => b.ovr - a.ovr);

  const [selectedSlotIdx, setSelectedSlotIdx] = useState<number | null>(null);
  const [swapPlayerId, setSwapPlayerId] = useState<string | null>(null);

  const strength = evaluateTeamStrength(club, state.players, club.startingXI, club.tactics);
  const slots = FORMATION_SLOTS[club.tactics.formation];
  const coords = PITCH_COORDS[club.tactics.formation];

  const handleAutoPick = () => {
    const best = pickBestLineup(squad, club.tactics.formation);
    onUpdateLineup(best.startingXI, best.bench);
    setSwapPlayerId(null);
    setSelectedSlotIdx(null);
  };

  const handleSwapClick = (targetId: string, slotIdx?: number) => {
    if (slotIdx !== undefined) setSelectedSlotIdx(slotIdx);
    if (!swapPlayerId) {
      setSwapPlayerId(targetId);
      return;
    }
    if (swapPlayerId === targetId) {
      setSwapPlayerId(null);
      return;
    }

    const newXI = [...club.startingXI];
    const newBench = [...club.bench];

    const idxA_XI = newXI.indexOf(swapPlayerId);
    const idxB_XI = newXI.indexOf(targetId);
    const idxA_B = newBench.indexOf(swapPlayerId);
    const idxB_B = newBench.indexOf(targetId);

    if (idxA_XI !== -1 && idxB_XI !== -1) {
      [newXI[idxA_XI], newXI[idxB_XI]] = [newXI[idxB_XI], newXI[idxA_XI]];
    } else if (idxA_XI !== -1 && idxB_B !== -1) {
      newXI[idxA_XI] = targetId;
      newBench[idxB_B] = swapPlayerId;
    } else if (idxB_XI !== -1 && idxA_B !== -1) {
      newXI[idxB_XI] = swapPlayerId;
      newBench[idxA_B] = targetId;
    } else if (idxA_XI !== -1 && idxB_XI === -1 && idxB_B === -1) {
      newXI[idxA_XI] = targetId;
    } else if (idxB_XI !== -1 && idxA_XI === -1 && idxA_B === -1) {
      newXI[idxB_XI] = swapPlayerId;
    } else if (idxA_B !== -1 && idxB_B === -1 && idxB_XI === -1) {
      newBench[idxA_B] = targetId;
    } else if (idxB_B !== -1 && idxA_B === -1 && idxA_XI === -1) {
      newBench[idxB_B] = swapPlayerId;
    }

    onUpdateLineup(newXI, newBench);
    setSwapPlayerId(null);
  };

  const focusedStarter =
    selectedSlotIdx !== null ? state.players[club.startingXI[selectedSlotIdx]] : null;

  return (
    <div className="space-y-6">
      {/* Top Split: Tactical Pitch (5 cols) + Tactics & Training Controls (7 cols) */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Tactical Pitch */}
        <div className="xl:col-span-5 bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white">İlk 11 Sahası ({club.tactics.formation})</h2>
              <p className="text-xs text-slate-400">
                {swapPlayerId
                  ? `Değişecek oyuncu seçildi: ${state.players[swapPlayerId]?.name}`
                  : 'Yer değiştirmek için iki oyuncuya sırayla tıklayın'}
              </p>
            </div>
            <button
              onClick={handleAutoPick}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-emerald-400 flex items-center gap-1.5 cursor-pointer"
            >
              <Wand2 className="w-3.5 h-3.5" />
              Otomatik Kur
            </button>
          </div>

          {/* Football Pitch SVG Canvas */}
          <div className="relative w-full aspect-[4/5] rounded-xl overflow-hidden border border-emerald-500/30 bg-gradient-to-b from-[#0E3B26] via-[#0B301F] to-[#0E3B26]">
            {/* Pitch Markings */}
            <svg
              viewBox="0 0 100 120"
              className="absolute inset-0 w-full h-full pointer-events-none opacity-35"
              preserveAspectRatio="none"
            >
              <rect x="4" y="4" width="92" height="112" fill="none" stroke="#6EE7B7" strokeWidth="0.6" />
              <line x1="4" y1="60" x2="96" y2="60" stroke="#6EE7B7" strokeWidth="0.6" />
              <circle cx="50" cy="60" r="12" fill="none" stroke="#6EE7B7" strokeWidth="0.6" />
              <rect x="26" y="4" width="48" height="16" fill="none" stroke="#6EE7B7" strokeWidth="0.6" />
              <rect x="26" y="100" width="48" height="16" fill="none" stroke="#6EE7B7" strokeWidth="0.6" />
            </svg>

            {/* 11 Player Nodes */}
            {club.startingXI.map((pid, idx) => {
              const p = state.players[pid];
              const pt = coords[idx] ?? { x: 50, y: 50 };
              const slotPos = slots[idx];
              if (!p) return null;
              const isSelected = swapPlayerId === pid;
              const outOfPos = p.position !== slotPos;
              const unavailable = p.injuryWeeks > 0 || p.suspendedWeeks > 0;

              return (
                <button
                  key={`${pid}_${idx}`}
                  onClick={() => handleSwapClick(pid, idx)}
                  style={{ left: `${pt.x}%`, top: `${pt.y}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group cursor-pointer"
                >
                  <div
                    className={`w-9 h-9 rounded-full border-2 flex items-center justify-center font-mono text-xs font-bold shadow-md transition-transform group-hover:scale-110 ${
                      isSelected
                        ? 'bg-emerald-400 text-slate-950 border-white scale-110'
                        : unavailable
                        ? 'bg-red-900/90 text-red-200 border-red-400'
                        : outOfPos
                        ? 'bg-amber-900/90 text-amber-200 border-amber-400'
                        : 'bg-[#0B0F17]/95 text-white border-emerald-400'
                    }`}
                  >
                    {p.ovr}
                  </div>
                  <div className="mt-1 px-1.5 py-0.5 rounded bg-[#0B0F17]/90 text-[10px] font-medium text-slate-100 whitespace-nowrap max-w-[84px] truncate">
                    {p.name.split(' ').slice(-1)[0]}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Focused Player Role Selector */}
          {focusedStarter && (
            <div className="p-3.5 rounded-lg bg-[#0B0F17] border border-slate-800 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-xs font-semibold text-white truncate">
                  {focusedStarter.name} ({POSITION_LABEL[focusedStarter.position]})
                </div>
                <div className="text-[11px] text-slate-400">Saha İçi Oyuncu Rolü</div>
              </div>
              <select
                value={focusedStarter.role}
                onChange={(e) =>
                  onUpdatePlayerRole(focusedStarter.id, e.target.value as PlayerRole)
                }
                className="bg-[#121824] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
              >
                {ROLES_BY_POSITION[focusedStarter.position].map((role) => (
                  <option key={role} value={role}>
                    {ROLE_LABELS[role]}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Right 7 Cols: Tactics, Strength Ratings, Bench, Training */}
        <div className="xl:col-span-7 space-y-6">
          {/* Strength + Tactics Card */}
          <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/70">
              <div>
                <h2 className="text-sm font-semibold text-white">Taktiksel Sistem &amp; Güç Dengesi</h2>
                <p className="text-xs text-slate-400">
                  Diziliş, baskı ve pas anlayışı doğrudan maç simülasyon motorunu belirler.
                </p>
              </div>
              <div className="flex items-center gap-4 font-mono tabular-nums text-xs">
                <div>
                  <span className="text-slate-400">HÜC </span>
                  <strong className="text-emerald-400">{strength.attack.toFixed(0)}</strong>
                </div>
                <div>
                  <span className="text-slate-400">ORT </span>
                  <strong className="text-white">{strength.midfield.toFixed(0)}</strong>
                </div>
                <div>
                  <span className="text-slate-400">SAV </span>
                  <strong className="text-white">{strength.defense.toFixed(0)}</strong>
                </div>
                <div>
                  <span className="text-slate-400">GEN </span>
                  <strong className="text-emerald-400">{strength.overall.toFixed(1)}</strong>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              <label className="block">
                <span className="text-xs text-slate-400">Diziliş</span>
                <select
                  value={club.tactics.formation}
                  onChange={(e) => {
                    const nextForm = e.target.value as Formation;
                    onUpdateTactics({ ...club.tactics, formation: nextForm });
                  }}
                  className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
                >
                  {(['4-3-3', '4-2-3-1', '3-5-2', '4-4-2', '3-4-3', '5-3-2'] as Formation[]).map(
                    (f) => (
                      <option key={f} value={f}>
                        {f}
                      </option>
                    )
                  )}
                </select>
              </label>

              <label className="block">
                <span className="text-xs text-slate-400">Oyun Anlayışı</span>
                <select
                  value={club.tactics.mentality}
                  onChange={(e) =>
                    onUpdateTactics({ ...club.tactics, mentality: e.target.value as Mentality })
                  }
                  className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {(Object.keys(MENTALITY_LABELS) as Mentality[]).map((m) => (
                    <option key={m} value={m}>
                      {MENTALITY_LABELS[m]}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block">
                <span className="text-xs text-slate-400">Baskı Şiddeti</span>
                <select
                  value={club.tactics.pressing}
                  onChange={(e) =>
                    onUpdateTactics({
                      ...club.tactics,
                      pressing: e.target.value as PressingIntensity,
                    })
                  }
                  className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {(Object.keys(PRESSING_LABELS) as PressingIntensity[]).map((pr) => (
                    <option key={pr} value={pr}>
                      {PRESSING_LABELS[pr]}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block">
                <span className="text-xs text-slate-400">Pas Tarzı</span>
                <select
                  value={club.tactics.passing}
                  onChange={(e) =>
                    onUpdateTactics({ ...club.tactics, passing: e.target.value as PassingStyle })
                  }
                  className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {(Object.keys(PASSING_LABELS) as PassingStyle[]).map((pa) => (
                    <option key={pa} value={pa}>
                      {PASSING_LABELS[pa]}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block">
                <span className="text-xs text-slate-400">Oyun Temposu</span>
                <select
                  value={club.tactics.tempo}
                  onChange={(e) =>
                    onUpdateTactics({ ...club.tactics, tempo: e.target.value as TempoStyle })
                  }
                  className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {(Object.keys(TEMPO_LABELS) as TempoStyle[]).map((t) => (
                    <option key={t} value={t}>
                      {TEMPO_LABELS[t]}
                    </option>
                  ))}
                </select>
              </label>
            </div>
          </div>

          {/* Weekly Training Focus */}
          <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-3.5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                Haftalık Antrenman Programı
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                Antrenman Tesisi Sv. {club.facilities.training}/5
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {(Object.keys(TRAINING_LABELS) as TrainingFocus[]).map((focus) => {
                const active = club.trainingFocus === focus;
                const info = TRAINING_LABELS[focus];
                return (
                  <button
                    key={focus}
                    onClick={() => onUpdateTraining(focus)}
                    className={`text-left p-3 rounded-lg border transition-colors cursor-pointer ${
                      active
                        ? 'bg-emerald-500/15 border-emerald-500/70'
                        : 'bg-[#0B0F17] border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div
                      className={`text-xs font-semibold ${
                        active ? 'text-emerald-400' : 'text-white'
                      }`}
                    >
                      {info.title}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-snug">{info.desc}</p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Full Squad Data Grid */}
      <div className="bg-[#121824] border border-slate-800/80 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Tam Kadro &amp; Oyuncu Durumları ({squad.length} Futbolcu)
            </h3>
            <p className="text-xs text-slate-400">
              Yedek veya kadro dışı bir oyuncuyu İlk 11 ile değiştirmek için &ldquo;Değiştir&rdquo;
              butonunu kullanabilirsiniz.
            </p>
          </div>
          {swapPlayerId && (
            <button
              onClick={() => setSwapPlayerId(null)}
              className="text-xs text-amber-400 hover:text-amber-300 cursor-pointer"
            >
              Değişim Seçimini İptal Et ({state.players[swapPlayerId]?.name})
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800/80 text-[11px] text-slate-400 bg-[#0B0F17]">
                <th className="py-2.5 px-4 font-medium">Kadro</th>
                <th className="py-2.5 px-3 font-medium">Mevki</th>
                <th className="py-2.5 px-3 font-medium">Oyuncu</th>
                <th className="py-2.5 px-3 font-medium text-right">Yaş</th>
                <th className="py-2.5 px-3 font-medium text-right">OVR / POT</th>
                <th className="py-2.5 px-3 font-medium">Kondisyon</th>
                <th className="py-2.5 px-3 font-medium text-right">Değer</th>
                <th className="py-2.5 px-3 font-medium text-right">Maaş</th>
                <th className="py-2.5 px-3 font-medium text-right">Sözleşme</th>
                <th className="py-2.5 px-3 font-medium text-right">Sezon (G/A)</th>
                <th className="py-2.5 px-4 font-medium text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs">
              {squad.map((p) => {
                const inXI = club.startingXI.includes(p.id);
                const inBench = club.bench.includes(p.id);
                const isSwapTarget = swapPlayerId === p.id;
                return (
                  <tr
                    key={p.id}
                    className={`hover:bg-slate-800/30 transition-colors ${
                      isSwapTarget ? 'bg-emerald-500/10' : ''
                    }`}
                  >
                    <td className="py-2.5 px-4 font-mono text-[11px]">
                      {inXI ? (
                        <span className="text-emerald-400 font-semibold">İLK 11</span>
                      ) : inBench ? (
                        <span className="text-slate-300">YEDEK</span>
                      ) : (
                        <span className="text-slate-500">KADRO</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-300">
                      {POSITION_LABEL[p.position]}
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="font-medium text-white flex items-center gap-1.5">
                        <span>{p.name}</span>
                        {p.injuryWeeks > 0 && (
                          <span className="text-[11px] text-red-400 flex items-center gap-0.5">
                            <AlertCircle className="w-3 h-3" />
                            Sakat ({p.injuryWeeks}h)
                          </span>
                        )}
                        {p.suspendedWeeks > 0 && (
                          <span className="text-[11px] text-amber-400">
                            Cezalı ({p.suspendedWeeks}h)
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {p.nationality} · {ROLE_LABELS[p.role]}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {p.age}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      <span className="font-bold text-emerald-400">{p.ovr}</span>
                      <span className="text-slate-500"> / {p.pot}</span>
                    </td>
                    <td className="py-2.5 px-3 w-32">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${
                              p.stamina >= 75
                                ? 'bg-emerald-500'
                                : p.stamina >= 55
                                ? 'bg-amber-500'
                                : 'bg-red-500'
                            }`}
                            style={{ width: `${p.stamina}%` }}
                          />
                        </div>
                        <span className="font-mono tabular-nums text-[11px] text-slate-300 w-8 text-right">
                          %{p.stamina}
                        </span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">
                      {formatMoneyM(p.marketValue)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {formatWageK(p.weeklyWage)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      <span
                        className={
                          p.contractYearsLeft <= 1 ? 'text-amber-400 font-semibold' : 'text-slate-300'
                        }
                      >
                        {p.contractYearsLeft} Yıl
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {p.stats.goals}G / {p.stats.assists}A
                    </td>
                    <td className="py-2.5 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          onClick={() => handleSwapClick(p.id)}
                          className={`px-2 py-1 rounded text-[11px] font-medium cursor-pointer ${
                            isSwapTarget
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                          }`}
                        >
                          <ArrowLeftRight className="w-3 h-3 inline mr-1" />
                          {swapPlayerId ? 'Buraya Koy' : 'Değiştir'}
                        </button>
                        <button
                          onClick={() => onOpenRenewContract(p)}
                          className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-200 cursor-pointer"
                        >
                          Sözleşme
                        </button>
                        <button
                          onClick={() => onToggleTransferList(p.id)}
                          className={`px-2 py-1 rounded text-[11px] cursor-pointer ${
                            p.transferListed
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-400'
                          }`}
                        >
                          <Sparkles className="w-3 h-3 inline mr-0.5" />
                          {p.transferListed ? 'Listede' : 'Satılık'}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
