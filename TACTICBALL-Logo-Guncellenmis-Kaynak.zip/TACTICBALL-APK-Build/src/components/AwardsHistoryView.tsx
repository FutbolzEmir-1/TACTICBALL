import React from 'react';
import { CareerState } from '../types/game';
import { formatMoneyM } from '../utils/formatters';
import { ClubCrest } from './ClubCrest';
import { ArrowRight, Award, History, Repeat } from 'lucide-react';

interface AwardsHistoryViewProps {
  state: CareerState;
  onStartNextSeason: () => void;
}

export const AwardsHistoryView: React.FC<AwardsHistoryViewProps> = ({
  state,
  onStartNextSeason,
}) => {
  return (
    <div className="space-y-6">
      {/* Season End Awards Banner */}
      {state.phase === 'SEASON_END' && (
        <div className="bg-[#121824] border border-emerald-500/40 rounded-xl p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-emerald-400">
                {state.seasonLabel} Sezon Sonu Ödül Töreni
              </div>
              <h2
                className="text-2xl font-bold text-white mt-0.5"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Yılın En İyileri &amp; Şampiyonluk Raporu
              </h2>
            </div>

            <button
              onClick={onStartNextSeason}
              className="px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm flex items-center gap-2 cursor-pointer"
            >
              <span>Yeni Sezona Geç ({2026 + state.seasonIndex + 1}-{2026 + state.seasonIndex + 2})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {state.latestAwards.map((aw) => {
              const club = state.clubs[aw.clubId];
              return (
                <div
                  key={aw.title}
                  className="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex items-center gap-3.5"
                >
                  {club && <ClubCrest club={club} size={42} />}
                  <div className="min-w-0">
                    <div className="text-[11px] font-semibold text-emerald-400">{aw.title}</div>
                    <div className="text-sm font-bold text-white truncate">{aw.winnerName}</div>
                    <div className="text-xs text-slate-400 truncate">{aw.clubName}</div>
                    <div className="text-[11px] font-mono text-slate-300 mt-1">{aw.metricLabel}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Career Past Seasons History */}
      <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <History className="w-4 h-4 text-emerald-400" />
          Kariyer &amp; Sezon Geçmişi
        </h3>

        {state.history.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500 bg-[#0B0F17] border border-slate-800/70 rounded-lg">
            {state.seasonLabel} sezonu devam ediyor. 18. hafta tamamlandığında sezon ödülleri ve
            şampiyonluk geçmişi burada kayıt altına alınacaktır.
          </div>
        ) : (
          <div className="space-y-3">
            {state.history.map((h) => (
              <div
                key={h.seasonLabel}
                className="bg-[#0B0F17] border border-slate-800/80 rounded-lg p-4 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <Award className="w-4 h-4 text-emerald-400" />
                    {h.seasonLabel} · {h.clubName}
                  </div>
                  <div className="text-xs font-mono text-emerald-400">
                    {h.leagueName} {h.leaguePosition}. Sıra ({h.points} Puan)
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-slate-300">
                  <div>Kupa: {h.cupResult}</div>
                  <div>Avrupa: {h.europeResult}</div>
                  <div>Şampiyonlar Kupası: {h.championsCupWinner}</div>
                  <div>Avrupa Kalkanı: {h.europaShieldWinner}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Global Transfer Feed (User + Rival AI Transfers) */}
      <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <Repeat className="w-4 h-4 text-emerald-400" />
          Ligler &amp; Avrupa Transfer Akışı ({state.transfers.length})
        </h3>

        {state.transfers.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500 bg-[#0B0F17] border border-slate-800/70 rounded-lg">
            Henüz tamamlanan resmi transfer bulunmuyor. Transfer döneminde kulüpler aktif olarak
            oyuncu alıp satacaktır.
          </div>
        ) : (
          <div className="overflow-x-auto border border-slate-800/70 rounded-lg bg-[#0B0F17]">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] text-slate-400">
                  <th className="py-2 px-3">Hafta</th>
                  <th className="py-2 px-3">Futbolcu</th>
                  <th className="py-2 px-3">Eski Kulüp</th>
                  <th className="py-2 px-3">Yeni Kulüp</th>
                  <th className="py-2 px-3 text-right">Bonservis</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {state.transfers.slice(0, 35).map((tr) => (
                  <tr key={tr.id}>
                    <td className="py-2 px-3 font-mono text-slate-400">
                      {tr.seasonLabel} · {tr.week}. Hf
                    </td>
                    <td className="py-2 px-3 font-medium text-white">
                      {tr.playerName}{' '}
                      <span className="font-mono text-emerald-400">({tr.playerOvr})</span>
                    </td>
                    <td className="py-2 px-3 text-slate-400">{tr.fromClubName}</td>
                    <td className="py-2 px-3 text-slate-200 font-medium">{tr.toClubName}</td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums font-semibold text-emerald-400">
                      {formatMoneyM(tr.fee)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
