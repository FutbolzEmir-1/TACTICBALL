import React, { useMemo, useState } from 'react';
import { getLeagueStandings } from '../engine/careerEngine';
import { CareerState, LeagueId } from '../types/game';
import { ClubCrest } from './ClubCrest';
import { Award, Globe, Trophy } from 'lucide-react';

interface CompetitionsViewProps {
  state: CareerState;
}

export const CompetitionsView: React.FC<CompetitionsViewProps> = ({ state }) => {
  const userLeague = state.clubs[state.userClubId].leagueId;
  const [selectedLeague, setSelectedLeague] = useState<LeagueId>(userLeague);
  const [subTab, setSubTab] = useState<'STANDINGS' | 'FIXTURES' | 'CUPS' | 'LEADERS'>('STANDINGS');
  const [fixtureWeek, setFixtureWeek] = useState<number>(state.week);

  const standings = useMemo(
    () => getLeagueStandings(selectedLeague, state.clubs, state.fixtures),
    [selectedLeague, state.clubs, state.fixtures]
  );

  const leagueFixtures = useMemo(
    () =>
      state.fixtures.filter(
        (f) =>
          f.competition === 'LEAGUE' && f.leagueId === selectedLeague && f.week === fixtureWeek
      ),
    [state.fixtures, selectedLeague, fixtureWeek]
  );

  const cupFixtures = useMemo(
    () =>
      state.fixtures.filter(
        (f) =>
          (f.competition === 'CUP' && f.leagueId === selectedLeague) ||
          f.competition === 'CHAMPIONS_CUP' ||
          f.competition === 'EUROPA_SHIELD'
      ),
    [state.fixtures, selectedLeague]
  );

  const topScorers = useMemo(
    () =>
      Object.values(state.players)
        .filter((p) => state.clubs[p.clubId]?.leagueId === selectedLeague && p.stats.goals > 0)
        .sort((a, b) => b.stats.goals - a.stats.goals || b.stats.assists - a.stats.assists)
        .slice(0, 12),
    [state.players, state.clubs, selectedLeague]
  );

  const topAssisters = useMemo(
    () =>
      Object.values(state.players)
        .filter((p) => state.clubs[p.clubId]?.leagueId === selectedLeague && p.stats.assists > 0)
        .sort((a, b) => b.stats.assists - a.stats.assists || b.stats.goals - a.stats.goals)
        .slice(0, 12),
    [state.players, state.clubs, selectedLeague]
  );

  return (
    <div className="space-y-6">
      {/* League Switcher + Sub Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#121824] border border-slate-800/80 rounded-xl">
          {Object.values(state.leagues).map((l) => (
            <button
              key={l.id}
              onClick={() => setSelectedLeague(l.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                selectedLeague === l.id
                  ? 'bg-emerald-500 text-slate-950'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              {l.name}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1 p-1 bg-[#121824] border border-slate-800/80 rounded-xl">
          {[
            { id: 'STANDINGS', label: 'Puan Durumu' },
            { id: 'FIXTURES', label: 'Fikstür' },
            { id: 'CUPS', label: 'Kupa & Avrupa' },
            { id: 'LEADERS', label: 'Gol / Asist Krallığı' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setSubTab(t.id as typeof subTab)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                subTab === t.id
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* STANDINGS */}
      {subTab === 'STANDINGS' && (
        <div className="bg-[#121824] border border-slate-800/80 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-800/80 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <Trophy className="w-4 h-4 text-emerald-400" />
              {state.leagues[selectedLeague].name} Puan Durumu ({state.seasonLabel})
            </h2>
            <span className="text-xs text-slate-400">
              1-3. Sıra: Şampiyonlar Kupası · 4-6. Sıra: Avrupa Kalkanı
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800/80 text-[11px] text-slate-400 bg-[#0B0F17]">
                  <th className="py-2.5 px-4 font-medium w-12">#</th>
                  <th className="py-2.5 px-3 font-medium">Kulüp</th>
                  <th className="py-2.5 px-3 font-medium text-right">O</th>
                  <th className="py-2.5 px-3 font-medium text-right">G</th>
                  <th className="py-2.5 px-3 font-medium text-right">B</th>
                  <th className="py-2.5 px-3 font-medium text-right">M</th>
                  <th className="py-2.5 px-3 font-medium text-right">A</th>
                  <th className="py-2.5 px-3 font-medium text-right">Y</th>
                  <th className="py-2.5 px-3 font-medium text-right">AV</th>
                  <th className="py-2.5 px-3 font-medium text-right">P</th>
                  <th className="py-2.5 px-4 font-medium text-right">Form</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-xs">
                {standings.map((row, idx) => {
                  const club = state.clubs[row.clubId];
                  const isUser = row.clubId === state.userClubId;
                  return (
                    <tr
                      key={row.clubId}
                      className={isUser ? 'bg-emerald-500/10' : 'hover:bg-slate-800/30'}
                    >
                      <td className="py-2.5 px-4 font-mono tabular-nums font-bold text-slate-300">
                        <span
                          className={
                            idx === 0
                              ? 'text-emerald-400'
                              : idx < 3
                              ? 'text-sky-400'
                              : idx >= standings.length - 2
                              ? 'text-red-400'
                              : 'text-slate-400'
                          }
                        >
                          {idx + 1}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-2.5">
                          <ClubCrest club={club} size={24} />
                          <span className={`font-medium ${isUser ? 'text-emerald-300 font-semibold' : 'text-white'}`}>
                            {club.name}
                          </span>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{row.played}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{row.won}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{row.drawn}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{row.lost}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{row.gf}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{row.ga}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                        {row.gd > 0 ? `+${row.gd}` : row.gd}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-white">
                        {row.points}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono text-[11px]">
                        <div className="inline-flex items-center gap-1">
                          {row.form.map((f, i) => (
                            <span
                              key={i}
                              className={`w-4 h-4 rounded flex items-center justify-center font-bold ${
                                f === 'G'
                                  ? 'bg-emerald-500/20 text-emerald-400'
                                  : f === 'B'
                                  ? 'bg-slate-700 text-slate-300'
                                  : 'bg-red-500/20 text-red-400'
                              }`}
                            >
                              {f}
                            </span>
                          ))}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* FIXTURES */}
      {subTab === 'FIXTURES' && (
        <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-sm font-semibold text-white">
              {state.leagues[selectedLeague].name} · {fixtureWeek}. Hafta Maçları
            </h2>
            <select
              value={fixtureWeek}
              onChange={(e) => setFixtureWeek(Number(e.target.value))}
              className="bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-white"
            >
              {Array.from({ length: 18 }, (_, i) => i + 1).map((w) => (
                <option key={w} value={w}>
                  {w}. Hafta
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {leagueFixtures.map((fx) => {
              const h = state.clubs[fx.homeClubId];
              const a = state.clubs[fx.awayClubId];
              return (
                <div
                  key={fx.id}
                  className="bg-[#0B0F17] border border-slate-800/80 rounded-lg p-3.5 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <ClubCrest club={h} size={24} />
                    <span className="text-white font-medium truncate">{h.name}</span>
                  </div>
                  <div className="font-mono tabular-nums font-bold text-sm text-emerald-400 px-3 shrink-0">
                    {fx.played ? `${fx.homeGoals} - ${fx.awayGoals}` : 'vs'}
                  </div>
                  <div className="flex items-center justify-end gap-2 min-w-0 flex-1 text-right">
                    <span className="text-white font-medium truncate">{a.name}</span>
                    <ClubCrest club={a} size={24} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* CUPS & EUROPE */}
      {subTab === 'CUPS' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {(['CUP', 'CHAMPIONS_CUP', 'EUROPA_SHIELD'] as const).map((comp) => {
            const list = cupFixtures.filter((f) => f.competition === comp);
            const title =
              comp === 'CUP'
                ? `${state.leagues[selectedLeague].name} Ulusal Kupası`
                : comp === 'CHAMPIONS_CUP'
                ? 'Avrupa Şampiyonlar Kupası'
                : 'Avrupa Kalkanı';
            return (
              <div
                key={comp}
                className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-3"
              >
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Globe className="w-4 h-4 text-emerald-400" />
                  {title}
                </h3>
                <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                  {list.map((fx) => {
                    const h = state.clubs[fx.homeClubId];
                    const a = state.clubs[fx.awayClubId];
                    return (
                      <div
                        key={fx.id}
                        className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-3 text-xs space-y-1.5"
                      >
                        <div className="flex justify-between text-[11px] text-slate-400">
                          <span>{fx.roundName}</span>
                          <span className="font-mono">{fx.week}. Hafta</span>
                        </div>
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-slate-200 truncate flex-1">{h?.shortName}</span>
                          <span className="font-mono font-bold text-emerald-400">
                            {fx.played ? `${fx.homeGoals} - ${fx.awayGoals}` : 'vs'}
                          </span>
                          <span className="text-slate-200 truncate flex-1 text-right">
                            {a?.shortName}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* LEADERS */}
      {subTab === 'LEADERS' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-400" />
              Gol Krallığı ({state.leagues[selectedLeague].name})
            </h3>
            {topScorers.length === 0 ? (
              <div className="text-xs text-slate-500 py-6 text-center">Henüz gol kaydedilmedi.</div>
            ) : (
              <div className="divide-y divide-slate-800/60 border border-slate-800/70 rounded-lg bg-[#0B0F17]">
                {topScorers.map((p, idx) => (
                  <div key={p.id} className="px-3.5 py-2.5 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono text-slate-500 w-5">{idx + 1}.</span>
                      <div>
                        <div className="font-medium text-white">{p.name}</div>
                        <div className="text-[11px] text-slate-400">{state.clubs[p.clubId]?.name}</div>
                      </div>
                    </div>
                    <div className="font-mono tabular-nums font-bold text-emerald-400">
                      {p.stats.goals} Gol
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-sky-400" />
              Asist Krallığı ({state.leagues[selectedLeague].name})
            </h3>
            {topAssisters.length === 0 ? (
              <div className="text-xs text-slate-500 py-6 text-center">Henüz asist kaydedilmedi.</div>
            ) : (
              <div className="divide-y divide-slate-800/60 border border-slate-800/70 rounded-lg bg-[#0B0F17]">
                {topAssisters.map((p, idx) => (
                  <div key={p.id} className="px-3.5 py-2.5 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono text-slate-500 w-5">{idx + 1}.</span>
                      <div>
                        <div className="font-medium text-white">{p.name}</div>
                        <div className="text-[11px] text-slate-400">{state.clubs[p.clubId]?.name}</div>
                      </div>
                    </div>
                    <div className="font-mono tabular-nums font-bold text-sky-400">
                      {p.stats.assists} Asist
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
