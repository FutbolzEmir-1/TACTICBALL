import React, { useEffect, useState } from 'react';
import {
  createLiveMatchState,
  LiveMatchState,
  performLiveSubstitution,
  stepLiveMatchMinute,
} from '../engine/matchEngine';
import { Club, MatchFixture, Mentality, Player, PressingIntensity } from '../types/game';
import { MENTALITY_LABELS, POSITION_LABEL, PRESSING_LABELS } from '../utils/formatters';
import { ClubCrest } from './ClubCrest';
import { FastForward, Pause, Play, RefreshCw, ShieldAlert } from 'lucide-react';

interface MatchCenterModalProps {
  fixture: MatchFixture;
  userClubId: string;
  clubs: Record<string, Club>;
  players: Record<string, Player>;
  onFinishMatch: (finalState: LiveMatchState) => void;
}

export const MatchCenterModal: React.FC<MatchCenterModalProps> = ({
  fixture,
  userClubId,
  clubs,
  players,
  onFinishMatch,
}) => {
  const [live, setLive] = useState<LiveMatchState>(() =>
    createLiveMatchState(fixture, clubs, players)
  );
  const [speed, setSpeed] = useState<0 | 1 | 2 | 4>(2);
  const [selectedOutId, setSelectedOutId] = useState<string | null>(null);

  const isUserHome = fixture.homeClubId === userClubId;
  const homeClub = clubs[fixture.homeClubId];
  const awayClub = clubs[fixture.awayClubId];

  useEffect(() => {
    if (live.finished || speed === 0) return;
    const intervalMs = speed === 1 ? 360 : speed === 2 ? 170 : 65;
    const timer = window.setInterval(() => {
      setLive((prev) => {
        if (prev.finished) return prev;
        let next = stepLiveMatchMinute(prev, clubs, players, Boolean(fixture.isKnockout));

        // Let AI opponent make smart tactical substitutions at min 62 and 77
        if (next.minute === 62 || next.minute === 77) {
          const aiSide: 'HOME' | 'AWAY' = isUserHome ? 'AWAY' : 'HOME';
          const aiXI = aiSide === 'HOME' ? next.homeXI : next.awayXI;
          const aiBench = aiSide === 'HOME' ? next.homeBench : next.awayBench;
          const aiReds = aiSide === 'HOME' ? next.homeRedIds : next.awayRedIds;
          const aiClubId = aiSide === 'HOME' ? next.homeClubId : next.awayClubId;

          const outId = aiXI.find((id) => !aiReds.includes(id) && players[id]?.position !== 'GK');
          const inId = aiBench.find((id) => players[id]?.position !== 'GK');
          if (outId && inId) {
            next = performLiveSubstitution(next, aiSide, outId, inId);
            next = {
              ...next,
              events: [
                ...next.events,
                {
                  minute: next.minute,
                  type: 'SUB',
                  clubId: aiClubId,
                  playerId: inId,
                  playerName: players[inId]?.name ?? '',
                  assistPlayerId: outId,
                  assistPlayerName: players[outId]?.name ?? '',
                  detail: `${players[inId]?.name} oyuna girdi (${players[outId]?.name} çıktı).`,
                },
              ],
            };
          }
        }
        return next;
      });
    }, intervalMs);

    return () => window.clearInterval(timer);
  }, [speed, live.finished, clubs, players, fixture.isKnockout, isUserHome]);

  const handleInstantFinish = () => {
    setSpeed(0);
    setLive((prev) => {
      let cur = prev;
      while (!cur.finished) {
        cur = stepLiveMatchMinute(cur, clubs, players, Boolean(fixture.isKnockout));
        if (cur.minute === 62 || cur.minute === 77) {
          const aiSide: 'HOME' | 'AWAY' = isUserHome ? 'AWAY' : 'HOME';
          const aiXI = aiSide === 'HOME' ? cur.homeXI : cur.awayXI;
          const aiBench = aiSide === 'HOME' ? cur.homeBench : cur.awayBench;
          const aiReds = aiSide === 'HOME' ? cur.homeRedIds : cur.awayRedIds;
          const outId = aiXI.find((id) => !aiReds.includes(id) && players[id]?.position !== 'GK');
          const inId = aiBench.find((id) => players[id]?.position !== 'GK');
          if (outId && inId) {
            cur = performLiveSubstitution(cur, aiSide, outId, inId);
          }
        }
      }
      return cur;
    });
  };

  const userTactics = isUserHome ? live.homeTactics : live.awayTactics;
  const userXI = isUserHome ? live.homeXI : live.awayXI;
  const userBench = isUserHome ? live.homeBench : live.awayBench;
  const userSubsUsed = isUserHome ? live.homeSubsUsed : live.awaySubsUsed;
  const userReds = isUserHome ? live.homeRedIds : live.awayRedIds;

  const updateUserTactic = (patch: Partial<typeof userTactics>) => {
    setLive((prev) => ({
      ...prev,
      homeTactics: isUserHome ? { ...prev.homeTactics, ...patch } : prev.homeTactics,
      awayTactics: !isUserHome ? { ...prev.awayTactics, ...patch } : prev.awayTactics,
    }));
  };

  const handleUserSub = (inPlayerId: string) => {
    if (!selectedOutId || live.finished || userSubsUsed >= 5) return;
    const outP = players[selectedOutId];
    const inP = players[inPlayerId];
    setLive((prev) => {
      const updated = performLiveSubstitution(
        prev,
        isUserHome ? 'HOME' : 'AWAY',
        selectedOutId,
        inPlayerId
      );
      return {
        ...updated,
        events: [
          ...updated.events,
          {
            minute: updated.minute,
            type: 'SUB',
            clubId: userClubId,
            playerId: inPlayerId,
            playerName: inP?.name ?? '',
            assistPlayerId: selectedOutId,
            assistPlayerName: outP?.name ?? '',
            detail: `Oyuncu Değişikliği: ${inP?.name} oyuna girdi (${outP?.name} çıktı).`,
          },
        ],
      };
    });
    setSelectedOutId(null);
  };

  const competitionTitle =
    fixture.competition === 'LEAGUE'
      ? `${fixture.week}. Hafta Lig Maçı`
      : fixture.competition === 'CUP'
      ? `Ulusal Kupa · ${fixture.roundName}`
      : fixture.competition === 'CHAMPIONS_CUP'
      ? `Avrupa Şampiyonlar Kupası · ${fixture.roundName}`
      : `Avrupa Kalkanı · ${fixture.roundName}`;

  const awayPossession = 100 - live.stats.homePossession;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-6xl bg-[#121824] border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
        {/* Top Scoreboard Bar */}
        <div className="bg-[#0B0F17] border-b border-slate-800/80 px-6 py-5">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
            <span>{competitionTitle}</span>
            <span className="font-mono tabular-nums text-emerald-400 font-semibold">
              {live.finished ? 'MAÇ SONUCU' : `${live.minute}. DAKİKA`}
            </span>
          </div>

          <div className="grid grid-cols-11 items-center gap-4">
            <div className="col-span-4 flex items-center justify-end gap-3 text-right">
              <div className="min-w-0">
                <div className="font-bold text-base md:text-xl text-white truncate">
                  {homeClub.name}
                </div>
                <div className="text-xs text-slate-400 font-mono tabular-nums">
                  xG {live.stats.homeXG.toFixed(2)}
                </div>
              </div>
              <ClubCrest club={homeClub} size={46} />
            </div>

            <div className="col-span-3 flex flex-col items-center justify-center">
              <div
                className="text-4xl md:text-5xl font-extrabold font-mono tabular-nums text-white tracking-tight"
                style={{ fontFamily: 'var(--font-mono)' }}
              >
                {live.homeGoals} - {live.awayGoals}
              </div>
              {live.penaltyWinnerId && (
                <div className="text-[11px] text-amber-400 font-medium mt-1">
                  Penaltılarla Kazanan: {clubs[live.penaltyWinnerId]?.shortName}
                </div>
              )}
            </div>

            <div className="col-span-4 flex items-center gap-3">
              <ClubCrest club={awayClub} size={46} />
              <div className="min-w-0">
                <div className="font-bold text-base md:text-xl text-white truncate">
                  {awayClub.name}
                </div>
                <div className="text-xs text-slate-400 font-mono tabular-nums">
                  xG {live.stats.awayXG.toFixed(2)}
                </div>
              </div>
            </div>
          </div>

          {/* Speed & Control Bar */}
          <div className="mt-5 flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800/70">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setSpeed(speed === 0 ? 1 : 0)}
                disabled={live.finished}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-medium text-white flex items-center gap-1.5 cursor-pointer"
              >
                {speed === 0 ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                {speed === 0 ? 'Devam Et' : 'Duraklat'}
              </button>
              {([1, 2, 4] as const).map((sp) => (
                <button
                  key={sp}
                  onClick={() => setSpeed(sp)}
                  disabled={live.finished}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold cursor-pointer ${
                    speed === sp
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {sp}x
                </button>
              ))}
              <button
                onClick={handleInstantFinish}
                disabled={live.finished}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-medium text-slate-200 flex items-center gap-1.5 cursor-pointer"
              >
                <FastForward className="w-3.5 h-3.5" />
                Maçı Bitir
              </button>
            </div>

            {live.finished && (
              <button
                onClick={() => onFinishMatch(live)}
                className="px-5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-colors cursor-pointer"
              >
                Sonucu Onayla ve Haftayı İlerle
              </button>
            )}
          </div>
        </div>

        {/* Body Grid: Stats + Events | Tactical & Subs Console */}
        <div className="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-800/80">
          {/* Left 7 Cols: Match Stats & Live Commentary */}
          <div className="lg:col-span-7 p-5 space-y-5">
            {/* Key Stats */}
            <div className="grid grid-cols-3 gap-3 bg-[#0B0F17] border border-slate-800/70 rounded-lg p-3.5 text-center">
              <div>
                <div className="text-[11px] text-slate-400">Topla Oynama</div>
                <div className="text-sm font-mono tabular-nums font-bold text-white mt-1">
                  %{live.stats.homePossession} — %{awayPossession}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-400">Toplam Şut</div>
                <div className="text-sm font-mono tabular-nums font-bold text-white mt-1">
                  {live.stats.homeShots} — {live.stats.awayShots}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-400">İsabetli Şut</div>
                <div className="text-sm font-mono tabular-nums font-bold text-white mt-1">
                  {live.stats.homeShotsOnTarget} — {live.stats.awayShotsOnTarget}
                </div>
              </div>
            </div>

            {/* Live Timeline */}
            <div>
              <div className="text-xs font-semibold text-slate-400 mb-2">
                Canlı Maç Anlatımı &amp; Olaylar
              </div>
              <div className="h-72 overflow-y-auto bg-[#0B0F17] border border-slate-800/70 rounded-lg divide-y divide-slate-800/60">
                {live.events.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-500">
                    Maç henüz başladı, takımlar birbirini tartıyor...
                  </div>
                ) : (
                  [...live.events].reverse().map((ev, i) => {
                    const isGoal = ev.type === 'GOAL';
                    const isRed = ev.type === 'RED' || ev.type === 'INJURY';
                    const isYellow = ev.type === 'YELLOW';
                    return (
                      <div
                        key={`${ev.minute}_${i}`}
                        className={`px-3.5 py-2.5 flex items-start gap-3 text-xs ${
                          isGoal ? 'bg-emerald-500/10' : isRed ? 'bg-red-500/10' : ''
                        }`}
                      >
                        <span className="font-mono tabular-nums font-bold text-slate-400 w-8 shrink-0">
                          {ev.minute}&apos;
                        </span>
                        <span
                          className={`font-semibold shrink-0 w-10 ${
                            ev.clubId === userClubId ? 'text-emerald-400' : 'text-slate-300'
                          }`}
                        >
                          {clubs[ev.clubId]?.shortName}
                        </span>
                        <span
                          className={`flex-1 ${
                            isGoal
                              ? 'text-emerald-200 font-semibold'
                              : isRed
                              ? 'text-red-300'
                              : isYellow
                              ? 'text-amber-300'
                              : 'text-slate-300'
                          }`}
                        >
                          {ev.detail}
                        </span>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Right 5 Cols: Live Tactical Controls & 5 Substitutions */}
          <div className="lg:col-span-5 p-5 space-y-5">
            <div>
              <div className="text-xs font-semibold text-slate-400 mb-2">
                Canlı Saha Kenarı Talimatları
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <label className="block">
                  <span className="text-[11px] text-slate-400">Oyun Anlayışı</span>
                  <select
                    value={userTactics.mentality}
                    disabled={live.finished}
                    onChange={(e) => updateUserTactic({ mentality: e.target.value as Mentality })}
                    className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  >
                    {(Object.keys(MENTALITY_LABELS) as Mentality[]).map((m) => (
                      <option key={m} value={m}>
                        {MENTALITY_LABELS[m]}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="block">
                  <span className="text-[11px] text-slate-400">Baskı Şiddeti</span>
                  <select
                    value={userTactics.pressing}
                    disabled={live.finished}
                    onChange={(e) =>
                      updateUserTactic({ pressing: e.target.value as PressingIntensity })
                    }
                    className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  >
                    {(Object.keys(PRESSING_LABELS) as PressingIntensity[]).map((pr) => (
                      <option key={pr} value={pr}>
                        {PRESSING_LABELS[pr]}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
            </div>

            {/* Substitutions */}
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-slate-400">
                  Oyuncu Değişikliği ({userSubsUsed}/5)
                </span>
                {selectedOutId && (
                  <span className="text-emerald-400">
                    Çıkacak: {players[selectedOutId]?.name} — Yedek seçin
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                {/* Active XI */}
                <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg max-h-56 overflow-y-auto divide-y divide-slate-800/60">
                  {userXI.map((pid) => {
                    const p = players[pid];
                    if (!p) return null;
                    const isRed = userReds.includes(pid);
                    const selected = selectedOutId === pid;
                    return (
                      <button
                        key={pid}
                        disabled={live.finished || userSubsUsed >= 5 || isRed}
                        onClick={() => setSelectedOutId(selected ? null : pid)}
                        className={`w-full px-2.5 py-1.5 text-left text-[11px] flex items-center justify-between gap-1 cursor-pointer ${
                          selected
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'hover:bg-slate-800/60 text-slate-200'
                        } disabled:opacity-40`}
                      >
                        <span className="truncate flex items-center gap-1">
                          <span className="font-mono text-slate-400 w-7">
                            {POSITION_LABEL[p.position]}
                          </span>
                          <span className="truncate">{p.name}</span>
                          {isRed && <ShieldAlert className="w-3 h-3 text-red-400 shrink-0" />}
                        </span>
                        <span className="font-mono tabular-nums text-emerald-400 shrink-0">
                          {(live.playerRatings[pid] ?? 6.5).toFixed(1)}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Bench */}
                <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg max-h-56 overflow-y-auto divide-y divide-slate-800/60">
                  {userBench.length === 0 ? (
                    <div className="p-3 text-[11px] text-slate-500">Yedek kalmadı.</div>
                  ) : (
                    userBench.map((pid) => {
                      const p = players[pid];
                      if (!p) return null;
                      return (
                        <button
                          key={pid}
                          disabled={!selectedOutId || live.finished || userSubsUsed >= 5}
                          onClick={() => handleUserSub(pid)}
                          className="w-full px-2.5 py-1.5 text-left text-[11px] flex items-center justify-between gap-1 hover:bg-emerald-500/15 text-slate-200 disabled:opacity-45 cursor-pointer"
                        >
                          <span className="truncate flex items-center gap-1">
                            <RefreshCw className="w-3 h-3 text-slate-500 shrink-0" />
                            <span className="font-mono text-slate-400 w-7">
                              {POSITION_LABEL[p.position]}
                            </span>
                            <span className="truncate">{p.name}</span>
                          </span>
                          <span className="font-mono tabular-nums text-slate-300 shrink-0">
                            {p.ovr}
                          </span>
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
