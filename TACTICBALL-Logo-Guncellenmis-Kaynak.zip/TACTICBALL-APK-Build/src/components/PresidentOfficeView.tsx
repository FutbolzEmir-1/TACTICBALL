import React, { useState } from 'react';
import { CareerState, ClubFacilities, SponsorContract } from '../types/game';
import { formatMoneyM, formatWageK } from '../utils/formatters';
import { Building2, Coins, Landmark, Ticket, Wrench } from 'lucide-react';

interface PresidentOfficeViewProps {
  state: CareerState;
  onUpdateTicketPrice: (price: number) => void;
  onAdjustTransferBudget: (newBudget: number) => void;
  onPayDebt: (amount: number) => void;
  onTakeLoan: (amount: number) => void;
  onUpgradeFacility: (key: keyof ClubFacilities, cost: number) => void;
  onChangeSponsor: (slot: SponsorContract['slot'], option: Omit<SponsorContract, 'id'>) => void;
}

const SPONSOR_OFFERS: Record<
  SponsorContract['slot'],
  { name: string; weeklyMult: number; titleBonus: number; years: number; label: string }[]
> = {
  SHIRT: [
    { name: 'Global Energy Corp', weeklyMult: 1.12, titleBonus: 3, years: 3, label: 'Garanti Yüksek Gelir' },
    { name: 'AeroJet Airlines', weeklyMult: 0.96, titleBonus: 9, years: 2, label: 'Yüksek Şampiyonluk Primi' },
  ],
  STADIUM: [
    { name: 'Metropolitan Arena Group', weeklyMult: 1.15, titleBonus: 0, years: 4, label: '4 Yıllık İsim Hakkı' },
    { name: 'Titan Tech Stadium', weeklyMult: 1.05, titleBonus: 2.5, years: 2, label: 'Kısa Vadeli Esnek Paket' },
  ],
  SLEEVE: [
    { name: 'FinTech Pay', weeklyMult: 1.18, titleBonus: 1, years: 2, label: 'Dijital Ödeme Partneri' },
    { name: 'Apex Motors', weeklyMult: 1.04, titleBonus: 2.5, years: 2, label: 'Performans Odaklı' },
  ],
};

export const PresidentOfficeView: React.FC<PresidentOfficeViewProps> = ({
  state,
  onUpdateTicketPrice,
  onAdjustTransferBudget,
  onPayDebt,
  onTakeLoan,
  onUpgradeFacility,
  onChangeSponsor,
}) => {
  const club = state.clubs[state.userClubId];
  const squad = Object.values(state.players).filter((p) => p.clubId === club.id);
  const weeklyWageM = squad.reduce((s, p) => s + p.weeklyWage, 0) / 1000;
  const sponsorWeeklyM = club.sponsors.reduce((s, sp) => s + sp.weeklyIncome, 0);
  const tvWeeklyM = state.leagues[club.leagueId].tvWeeklyBonus * 0.45;
  const debtInterestM = club.debt * club.weeklyDebtInterestRate;

  const estAttendanceRatio = Math.min(
    0.99,
    Math.max(
      0.42,
      Math.max(0.45, Math.min(1.05, 1.15 - club.ticketPrice / 135)) *
        (0.6 + (club.fanSupport / 100) * 0.4)
    )
  );
  const estMatchTicketM = (club.stadiumCapacity * estAttendanceRatio * club.ticketPrice) / 1_000_000;

  const [debtPayInput, setDebtPayInput] = useState<number>(5);

  const facilityItems: { key: keyof ClubFacilities; label: string; effect: string }[] = [
    { key: 'stadiumLevel', label: 'Stadyum Tribün Kapasitesi', effect: '+6.000 yeni koltuk kapasitesi' },
    { key: 'training', label: 'Antrenman Tesisleri', effect: 'Genç oyuncu gelişim hızı artar' },
    { key: 'academy', label: 'Altyapı Akademisi', effect: 'Her sezon daha yüksek potansiyelli gençler' },
    { key: 'medical', label: 'Sağlık & Rehabilitasyon', effect: 'Sakatlık riski düşer, kondisyon hızlı döner' },
  ];

  return (
    <div className="space-y-6">
      {/* Top 4 Financial Pillars */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400">Kulüp Kasası (Kullanılabilir Nakit)</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-white mt-1">
            {formatMoneyM(club.cash)}
          </div>
          <div className="text-xs text-slate-400 mt-1">Tüm harcamalar buradan düşer</div>
        </div>
        <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400">Haftalık Gelir (Sponsor + TV)</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-emerald-400 mt-1">
            +{formatMoneyM(sponsorWeeklyM + tvWeeklyM)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            İç saha maçı bilet tahmini: +{formatMoneyM(estMatchTicketM)}
          </div>
        </div>
        <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400">Haftalık Gider (Maaş + Faiz)</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-red-400 mt-1">
            -{formatMoneyM(weeklyWageM + debtInterestM)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Maaş: {formatWageK(weeklyWageM * 1000)} · Faiz: {formatMoneyM(debtInterestM)}
          </div>
        </div>
        <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400">Toplam Kulüp Borcu</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-amber-400 mt-1">
            {formatMoneyM(club.debt)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Haftalık faiz oranı: %{(club.weeklyDebtInterestRate * 100).toFixed(2)}
          </div>
        </div>
      </div>

      {/* Middle Split: Ticket & Budget Allocation | Debt & Loans */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Ticket Pricing & Transfer Budget */}
        <div className="lg:col-span-6 bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-5">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Ticket className="w-4 h-4 text-emerald-400" />
            Stadyum Bilet Politikası &amp; Bütçe Tahsisi
          </h3>

          <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-4 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Ortalama Bilet Fiyatı</span>
              <span className="font-mono font-bold text-white text-sm">€{club.ticketPrice}</span>
            </div>
            <input
              type="range"
              min={10}
              max={110}
              step={2}
              value={club.ticketPrice}
              onChange={(e) => onUpdateTicketPrice(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-slate-400 font-mono tabular-nums">
              <span>Tahmini Doluluk: %{Math.round(estAttendanceRatio * 100)}</span>
              <span>İç Saha Geliri: ~{formatMoneyM(estMatchTicketM)}</span>
            </div>
          </div>

          <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-4 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">
                Kasa İçinden Transfer Bütçesi Limiti
              </span>
              <span className="font-mono font-bold text-emerald-400 text-sm">
                {formatMoneyM(club.transferBudget)}
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={Math.max(1, Math.floor(club.cash))}
              step={1}
              value={Math.min(club.transferBudget, Math.max(0, club.cash))}
              onChange={(e) => onAdjustTransferBudget(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-400">
              Transfer bütçesi hiçbir zaman kulüp kasasındaki mevcut nakit miktarını aşamaz.
            </p>
          </div>
        </div>

        {/* Debt Repayment & Bank Credit */}
        <div className="lg:col-span-6 bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-5">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Landmark className="w-4 h-4 text-amber-400" />
            Borç Yapılandırma &amp; Banka Kredisi
          </h3>

          <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-4 space-y-3">
            <div className="text-xs text-slate-300 font-medium">Erken Borç Ödemesi Yap</div>
            <div className="flex items-center gap-2.5">
              <input
                type="number"
                min={1}
                max={Math.max(1, Math.floor(Math.min(club.cash, club.debt)))}
                value={debtPayInput}
                onChange={(e) => setDebtPayInput(Number(e.target.value))}
                className="w-28 bg-[#121824] border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white"
              />
              <button
                disabled={club.debt <= 0 || club.cash < debtPayInput || debtPayInput <= 0}
                onClick={() => onPayDebt(debtPayInput)}
                className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-semibold text-xs cursor-pointer"
              >
                Kasadan Borç Kapat (€{debtPayInput}M)
              </button>
            </div>
            <p className="text-[11px] text-slate-400">
              Borcu azaltmak haftalık faiz yükünü düşürür ve yönetim güvenini artırır.
            </p>
          </div>

          <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-xs font-semibold text-white">Acil Kulüp Kredisi Çek</div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                +€15M nakit sağlar ancak borcu €18M artırır ve kurul güvenini düşürür.
              </div>
            </div>
            <button
              onClick={() => onTakeLoan(15)}
              className="px-3.5 py-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-semibold cursor-pointer"
            >
              €15M Kredi Kullan
            </button>
          </div>
        </div>
      </div>

      {/* Facilities & Stadium Expansion */}
      <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-400" />
            Stadyum &amp; Kulüp Tesisleri ({club.stadiumName} · {club.stadiumCapacity.toLocaleString('tr-TR')} Kapasite)
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {facilityItems.map((item) => {
            const level = club.facilities[item.key];
            const isMax = level >= 5;
            const upgradeCost = Number((level * 8.5 + (item.key === 'stadiumLevel' ? 12 : 4)).toFixed(1));
            return (
              <div
                key={item.key}
                className="bg-[#0B0F17] border border-slate-800/80 rounded-lg p-4 flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">{item.label}</span>
                    <span className="font-mono text-emerald-400">Sv.{level}/5</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1.5">{item.effect}</p>
                </div>

                <button
                  disabled={isMax || club.cash < upgradeCost}
                  onClick={() => onUpgradeFacility(item.key, upgradeCost)}
                  className="w-full py-2 rounded-lg bg-slate-800 hover:bg-emerald-500 hover:text-slate-950 disabled:opacity-40 text-xs font-semibold text-slate-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  {isMax ? 'Maksimum Seviye' : `Geliştir (${formatMoneyM(upgradeCost)})`}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sponsorship Contracts + Cash Flow Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Coins className="w-4 h-4 text-emerald-400" />
            Sponsorluk Anlaşmaları
          </h3>
          <div className="space-y-3">
            {club.sponsors.map((sp) => (
              <div
                key={sp.id}
                className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-3.5 space-y-2.5"
              >
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400">
                      {sp.slot === 'SHIRT'
                        ? 'Forma Göğüs'
                        : sp.slot === 'STADIUM'
                        ? 'Stadyum İsmi'
                        : 'Forma Kol'}
                      :{' '}
                    </span>
                    <strong className="text-white">{sp.sponsorName}</strong>
                  </div>
                  <span className="font-mono text-emerald-400">
                    +{formatMoneyM(sp.weeklyIncome)}/hf
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {SPONSOR_OFFERS[sp.slot].map((opt) => {
                    const nextWeekly = Number((sp.weeklyIncome * opt.weeklyMult).toFixed(2));
                    return (
                      <button
                        key={opt.name}
                        disabled={sp.sponsorName === opt.name}
                        onClick={() =>
                          onChangeSponsor(sp.slot, {
                            slot: sp.slot,
                            sponsorName: opt.name,
                            weeklyIncome: nextWeekly,
                            titleBonus: opt.titleBonus,
                            yearsRemaining: opt.years,
                          })
                        }
                        className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-[11px] text-slate-200 cursor-pointer"
                      >
                        {opt.name} ({opt.label} · {formatMoneyM(nextWeekly)}/hf)
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cash Flow Ledger */}
        <div className="lg:col-span-6 bg-[#121824] border border-slate-800/80 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-white">Haftalık Gelir / Gider Defteri</h3>
          <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/60 border border-slate-800/70 rounded-lg bg-[#0B0F17]">
            {state.cashFlowLog.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500">
                İlk hafta maçları tamamlandığında kulüp nakit hareketleri burada listelenecek.
              </div>
            ) : (
              [...state.cashFlowLog].reverse().map((entry, idx) => (
                <div
                  key={`${entry.week}_${idx}`}
                  className="px-3.5 py-2.5 flex items-center justify-between text-xs gap-3"
                >
                  <div className="min-w-0">
                    <div className="text-slate-200 truncate">{entry.label}</div>
                    <div className="text-[11px] text-slate-500 font-mono">
                      {entry.week}. Hafta · {entry.category}
                    </div>
                  </div>
                  <span
                    className={`font-mono tabular-nums font-semibold shrink-0 ${
                      entry.amount >= 0 ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {entry.amount >= 0 ? '+' : ''}
                    {formatMoneyM(entry.amount)}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
