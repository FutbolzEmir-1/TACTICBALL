import React, { useMemo, useState } from 'react';
import { isTransferWindowOpen } from '../engine/careerEngine';
import {
  CareerState,
  IncomingOffer,
  LeagueId,
  Player,
  Position,
} from '../types/game';
import { formatMoneyM, formatWageK, POSITION_LABEL } from '../utils/formatters';
import { ClubCrest } from './ClubCrest';
import { Check, Filter, Handshake, Search, X } from 'lucide-react';

interface TransfersViewProps {
  state: CareerState;
  onCompletePurchase: (
    playerId: string,
    fee: number,
    weeklyWage: number,
    contractYears: number
  ) => void;
  onRespondIncomingOffer: (offer: IncomingOffer, action: 'ACCEPT' | 'REJECT') => void;
}

export const TransfersView: React.FC<TransfersViewProps> = ({
  state,
  onCompletePurchase,
  onRespondIncomingOffer,
}) => {
  const userClub = state.clubs[state.userClubId];
  const windowOpen = isTransferWindowOpen(state.week);

  const [search, setSearch] = useState('');
  const [leagueFilter, setLeagueFilter] = useState<'ALL' | LeagueId>('ALL');
  const [posFilter, setPosFilter] = useState<'ALL' | Position>('ALL');
  const [maxPrice, setMaxPrice] = useState<number>(200);
  const [minOvr, setMinOvr] = useState<number>(70);

  // Negotiation Modal State
  const [targetPlayer, setTargetPlayer] = useState<Player | null>(null);
  const [stage, setStage] = useState<'CLUB' | 'PLAYER' | 'DONE' | 'FAILED'>('CLUB');
  const [feeOffer, setFeeOffer] = useState<number>(0);
  const [sellOn, setSellOn] = useState<number>(0);
  const [clubMsg, setClubMsg] = useState<string>('');
  const [attemptsLeft, setAttemptsLeft] = useState<number>(3);

  const [wageOffer, setWageOffer] = useState<number>(0);
  const [yearsOffer, setYearsOffer] = useState<number>(4);
  const [rolePromise, setRolePromise] = useState<'KEY' | 'STARTER' | 'ROTATION'>('STARTER');
  const [playerMsg, setPlayerMsg] = useState<string>('');

  const marketPlayers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return Object.values(state.players)
      .filter((p) => {
        if (p.clubId === userClub.id) return false;
        const c = state.clubs[p.clubId];
        if (!c) return false;
        if (leagueFilter !== 'ALL' && c.leagueId !== leagueFilter) return false;
        if (posFilter !== 'ALL' && p.position !== posFilter) return false;
        if (p.ovr < minOvr) return false;
        if (p.marketValue > maxPrice) return false;
        if (q && !p.name.toLowerCase().includes(q) && !c.name.toLowerCase().includes(q)) {
          return false;
        }
        return true;
      })
      .sort((a, b) => b.ovr - a.ovr || b.marketValue - a.marketValue)
      .slice(0, 60);
  }, [state.players, state.clubs, userClub.id, leagueFilter, posFilter, minOvr, maxPrice, search]);

  const openNegotiation = (p: Player) => {
    setTargetPlayer(p);
    setStage('CLUB');
    setFeeOffer(Number(p.marketValue.toFixed(1)));
    setSellOn(0);
    setAttemptsLeft(3);
    setClubMsg(`${state.clubs[p.clubId]?.name} yönetimi teklifinizi bekliyor.`);
    setWageOffer(Math.round(p.weeklyWage * 1.15));
    setYearsOffer(4);
    setRolePromise(p.ovr >= 82 ? 'KEY' : 'STARTER');
    setPlayerMsg('');
  };

  const handleSubmitClubOffer = () => {
    if (!targetPlayer) return;
    if (feeOffer > userClub.transferBudget || feeOffer > userClub.cash) {
      setClubMsg(
        `Yetersiz bütçe! Kullanılabilir transfer bütçeniz ${formatMoneyM(userClub.transferBudget)}.`
      );
      return;
    }

    const seller = state.clubs[targetPlayer.clubId];
    const agePremium = targetPlayer.age <= 22 && targetPlayer.pot > targetPlayer.ovr + 4 ? 1.28 : 1.05;
    const contractDiscount = targetPlayer.contractYearsLeft <= 1 ? 0.8 : 1.0;
    const desiredFee = Number(
      (targetPlayer.marketValue * agePremium * contractDiscount * (1 - sellOn * 0.005)).toFixed(1)
    );

    if (feeOffer >= desiredFee * 0.96) {
      setClubMsg(`${seller.name} €${feeOffer.toFixed(1)}M bonservis teklifini kabul etti!`);
      setStage('PLAYER');
      setPlayerMsg(`${targetPlayer.name} ve menajeri maaş görüşmesi için masada.`);
      return;
    }

    if (attemptsLeft <= 1 || feeOffer < desiredFee * 0.65) {
      setClubMsg(
        `${seller.name} bu teklifi yetersiz buldu ve görüşmeden çekildi (İstenen değer ~€${desiredFee.toFixed(1)}M).`
      );
      setStage('FAILED');
      return;
    }

    const counter = Number(((desiredFee + feeOffer) / 2).toFixed(1));
    setAttemptsLeft((n) => n - 1);
    setFeeOffer(counter);
    setClubMsg(
      `${seller.name} karşı teklif sundu: €${counter.toFixed(1)}M bonservis ile anlaşabiliriz.`
    );
  };

  const handleSubmitPlayerOffer = () => {
    if (!targetPlayer) return;
    const minAcceptableWage = Math.round(
      targetPlayer.weeklyWage *
        (rolePromise === 'KEY' ? 1.05 : rolePromise === 'STARTER' ? 1.15 : 1.32)
    );
    const clubSquadWages = Object.values(state.players)
      .filter((p) => p.clubId === userClub.id)
      .reduce((s, p) => s + p.weeklyWage, 0);

    if (clubSquadWages + wageOffer > userClub.wageBudgetWeekly * 1.1) {
      setPlayerMsg(
        `Kulüp maaş bütçesi limiti aşılıyor! Mevcut yük: ${formatWageK(clubSquadWages)} / Limit: ${formatWageK(userClub.wageBudgetWeekly)}.`
      );
      return;
    }

    if (wageOffer >= minAcceptableWage) {
      onCompletePurchase(targetPlayer.id, feeOffer, wageOffer, yearsOffer);
      setStage('DONE');
      setPlayerMsg(`${targetPlayer.name} resmi sözleşmeyi imzaladı ve kadroya katıldı!`);
    } else {
      setPlayerMsg(
        `Oyuncu ve menajeri bu rol için en az ${formatWageK(minAcceptableWage)} haftalık maaş talep ediyor.`
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Transfer Window Status Banner */}
      <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold">
            <span className={windowOpen ? 'text-emerald-400' : 'text-amber-400'}>
              {windowOpen
                ? 'Transfer Dönemi Açık (Anında Resmi İmza)'
                : 'Transfer Dönemi Kapalı (Yaz: 1-3. Hf · Kış: 9-10. Hf)'}
            </span>
          </div>
          <h2 className="text-lg font-bold text-white mt-0.5">
            Transfer Pazarı &amp; Pazarlık Masası
          </h2>
        </div>

        <div className="flex items-center gap-6 font-mono tabular-nums text-xs">
          <div>
            <div className="text-slate-400">Transfer Bütçesi</div>
            <div className="text-base font-bold text-emerald-400">
              {formatMoneyM(userClub.transferBudget)}
            </div>
          </div>
          <div>
            <div className="text-slate-400">Kulüp Kasası</div>
            <div className="text-base font-bold text-white">{formatMoneyM(userClub.cash)}</div>
          </div>
          <div>
            <div className="text-slate-400">Maaş Bütçesi</div>
            <div className="text-base font-bold text-slate-200">
              {formatWageK(userClub.wageBudgetWeekly)}
            </div>
          </div>
        </div>
      </div>

      {/* Incoming Offers Section */}
      {state.incomingOffers.length > 0 && (
        <div className="bg-[#121824] border border-emerald-500/30 rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-white">
            Oyuncularınıza Gelen Resmi Teklifler ({state.incomingOffers.length})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {state.incomingOffers.map((offer) => {
              const p = state.players[offer.playerId];
              const buyer = state.clubs[offer.fromClubId];
              if (!p || !buyer) return null;
              return (
                <div
                  key={offer.id}
                  className="bg-[#0B0F17] border border-slate-800 rounded-lg p-3.5 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <ClubCrest club={buyer} size={36} />
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">
                        {p.name} ({p.ovr} OVR)
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        Teklif: {buyer.name} ·{' '}
                        <span className="text-emerald-400 font-mono font-semibold">
                          {formatMoneyM(offer.fee)}
                        </span>
                        {offer.sellOnPercent > 0 ? ` + %${offer.sellOnPercent} Pay` : ''}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => onRespondIncomingOffer(offer, 'ACCEPT')}
                      className="px-2.5 py-1.5 rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-semibold cursor-pointer"
                    >
                      Sat
                    </button>
                    <button
                      onClick={() => onRespondIncomingOffer(offer, 'REJECT')}
                      className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer"
                    >
                      Reddet
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Search & Filter Controls */}
      <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-4 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="2026-27 futbolcu veya kulüp ara (ör. Yamal, Osimhen, Arda)..."
            className="w-full pl-9 pr-3 py-2 bg-[#0B0F17] border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={leagueFilter}
            onChange={(e) => setLeagueFilter(e.target.value as 'ALL' | LeagueId)}
            className="bg-[#0B0F17] border border-slate-700 rounded-lg px-2.5 py-2 text-xs text-white"
          >
            <option value="ALL">Tüm Ligler</option>
            {Object.values(state.leagues).map((l) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </select>

          <select
            value={posFilter}
            onChange={(e) => setPosFilter(e.target.value as 'ALL' | Position)}
            className="bg-[#0B0F17] border border-slate-700 rounded-lg px-2.5 py-2 text-xs text-white"
          >
            <option value="ALL">Tüm Mevkiler</option>
            <option value="GK">Kaleci</option>
            <option value="DEF">Defans</option>
            <option value="MID">Orta Saha</option>
            <option value="FWD">Forvet</option>
          </select>

          <select
            value={minOvr}
            onChange={(e) => setMinOvr(Number(e.target.value))}
            className="bg-[#0B0F17] border border-slate-700 rounded-lg px-2.5 py-2 text-xs text-white font-mono"
          >
            <option value={65}>Min 65 OVR</option>
            <option value={75}>Min 75 OVR</option>
            <option value={80}>Min 80 OVR</option>
            <option value={85}>Min 85 OVR</option>
          </select>

          <select
            value={maxPrice}
            onChange={(e) => setMaxPrice(Number(e.target.value))}
            className="bg-[#0B0F17] border border-slate-700 rounded-lg px-2.5 py-2 text-xs text-white font-mono"
          >
            <option value={200}>Tüm Değerler</option>
            <option value={80}>Max €80M</option>
            <option value={40}>Max €40M</option>
            <option value={20}>Max €20M</option>
            <option value={10}>Max €10M</option>
          </select>
        </div>
      </div>

      {/* Market Table */}
      <div className="bg-[#121824] border border-slate-800/80 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800/80 text-[11px] text-slate-400 bg-[#0B0F17]">
                <th className="py-2.5 px-4 font-medium">Futbolcu</th>
                <th className="py-2.5 px-3 font-medium">Kulüp</th>
                <th className="py-2.5 px-3 font-medium">Mevki</th>
                <th className="py-2.5 px-3 font-medium text-right">Yaş</th>
                <th className="py-2.5 px-3 font-medium text-right">OVR / POT</th>
                <th className="py-2.5 px-3 font-medium text-right">Piyasa Değeri</th>
                <th className="py-2.5 px-3 font-medium text-right">Haftalık Maaş</th>
                <th className="py-2.5 px-3 font-medium text-right">Sözleşme</th>
                <th className="py-2.5 px-4 font-medium text-right">Pazarlık</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs">
              {marketPlayers.map((p) => {
                const c = state.clubs[p.clubId];
                return (
                  <tr key={p.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 px-4">
                      <div className="font-medium text-white">{p.name}</div>
                      <div className="text-[11px] text-slate-400">{p.nationality}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-2">
                        {c && <ClubCrest club={c} size={22} />}
                        <span className="text-slate-200">{c?.name}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-300">
                      {POSITION_LABEL[p.position]}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {p.age}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      <span className="font-bold text-emerald-400">{p.ovr}</span>
                      <span className="text-slate-500"> / {p.pot}</span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold text-white">
                      {formatMoneyM(p.marketValue)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {formatWageK(p.weeklyWage)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400">
                      {p.contractYearsLeft} Yıl
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      <button
                        disabled={!windowOpen}
                        onClick={() => openNegotiation(p)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 disabled:opacity-35 font-semibold text-[11px] transition-colors inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Handshake className="w-3.5 h-3.5" />
                        Teklif Yap
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Two-Stage Transfer Negotiation Modal */}
      {targetPlayer && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#121824] border border-slate-700 rounded-xl p-6 space-y-5 shadow-2xl">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800">
              <div>
                <div className="text-xs text-emerald-400 font-medium">
                  {stage === 'CLUB'
                    ? '1. Aşama: Kulüp Bonservis Pazarlığı'
                    : stage === 'PLAYER'
                    ? '2. Aşama: Oyuncu Maaş & Sözleşme Görüşmesi'
                    : 'Transfer Sonucu'}
                </div>
                <h3 className="text-lg font-bold text-white mt-0.5">
                  {targetPlayer.name} ({targetPlayer.ovr} OVR · {targetPlayer.age} Yaş)
                </h3>
                <div className="text-xs text-slate-400">
                  {state.clubs[targetPlayer.clubId]?.name} · Piyasa Değeri:{' '}
                  {formatMoneyM(targetPlayer.marketValue)}
                </div>
              </div>
              <button
                onClick={() => setTargetPlayer(null)}
                className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {stage === 'CLUB' && (
              <div className="space-y-4">
                <div className="p-3 rounded-lg bg-[#0B0F17] border border-slate-800 text-xs text-slate-200">
                  {clubMsg}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <label className="block">
                    <span className="text-xs text-slate-400">Bonservis Teklifi (€M)</span>
                    <input
                      type="number"
                      step="0.5"
                      min="0.5"
                      value={feeOffer}
                      onChange={(e) => setFeeOffer(Number(e.target.value))}
                      className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono text-white"
                    />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-400">Sonraki Satıştan Pay (%)</span>
                    <select
                      value={sellOn}
                      onChange={(e) => setSellOn(Number(e.target.value))}
                      className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono text-white"
                    >
                      <option value={0}>%0</option>
                      <option value={10}>%10</option>
                      <option value={15}>%15</option>
                      <option value={20}>%20</option>
                    </select>
                  </label>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Kalan Pazarlık Hakkı: {attemptsLeft}</span>
                  <span>Bütçeniz: {formatMoneyM(userClub.transferBudget)}</span>
                </div>

                <button
                  onClick={handleSubmitClubOffer}
                  className="w-full py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm cursor-pointer"
                >
                  Kulübe Teklifi İlet
                </button>
              </div>
            )}

            {stage === 'PLAYER' && (
              <div className="space-y-4">
                <div className="p-3 rounded-lg bg-[#0B0F17] border border-emerald-500/30 text-xs text-emerald-200">
                  {playerMsg}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <label className="block">
                    <span className="text-xs text-slate-400">Haftalık Maaş (€K)</span>
                    <input
                      type="number"
                      step="5"
                      min="10"
                      value={wageOffer}
                      onChange={(e) => setWageOffer(Number(e.target.value))}
                      className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono text-white"
                    />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-400">Sözleşme Süresi</span>
                    <select
                      value={yearsOffer}
                      onChange={(e) => setYearsOffer(Number(e.target.value))}
                      className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono text-white"
                    >
                      {[1, 2, 3, 4, 5].map((y) => (
                        <option key={y} value={y}>
                          {y} Yıl
                        </option>
                      ))}
                    </select>
                  </label>
                </div>

                <label className="block">
                  <span className="text-xs text-slate-400">Kadro Rolü Sözü</span>
                  <select
                    value={rolePromise}
                    onChange={(e) => setRolePromise(e.target.value as 'KEY' | 'STARTER' | 'ROTATION')}
                    className="mt-1 w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                  >
                    <option value="KEY">Kilit Yıldız Oyuncu</option>
                    <option value="STARTER">Düzenli İlk 11</option>
                    <option value="ROTATION">Rotasyon Oyuncusu</option>
                  </select>
                </label>

                <button
                  onClick={handleSubmitPlayerOffer}
                  className="w-full py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm cursor-pointer"
                >
                  Sözleşmeyi İmzala ({formatMoneyM(feeOffer)} + {formatWageK(wageOffer)})
                </button>
              </div>
            )}

            {(stage === 'DONE' || stage === 'FAILED') && (
              <div className="space-y-4">
                <div
                  className={`p-4 rounded-lg border text-xs flex items-center gap-2.5 ${
                    stage === 'DONE'
                      ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-200'
                      : 'bg-red-500/15 border-red-500/40 text-red-200'
                  }`}
                >
                  {stage === 'DONE' && <Check className="w-4 h-4 shrink-0" />}
                  <span>{stage === 'DONE' ? playerMsg : clubMsg}</span>
                </div>
                <button
                  onClick={() => setTargetPlayer(null)}
                  className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-sm font-semibold cursor-pointer"
                >
                  Kapat
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
