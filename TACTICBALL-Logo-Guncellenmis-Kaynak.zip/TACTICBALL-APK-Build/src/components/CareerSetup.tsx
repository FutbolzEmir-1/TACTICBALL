import React, { useMemo, useState } from 'react';
import { buildInitialDatabase, LEAGUES_DATA } from '../data/database2026_27';
import { LeagueId } from '../types/game';
import { formatMoneyM } from '../utils/formatters';
import { ClubCrest } from './ClubCrest';
import { ArrowRight, RotateCcw, ShieldCheck, Trophy } from 'lucide-react';

interface CareerSetupProps {
  hasSavedCareer: boolean;
  savedClubName?: string;
  savedSeasonLabel?: string;
  savedWeek?: number;
  onContinueSaved: () => void;
  onStartCareer: (clubId: string, managerName: string) => void;
}

export const CareerSetup: React.FC<CareerSetupProps> = ({
  hasSavedCareer,
  savedClubName,
  savedSeasonLabel,
  savedWeek,
  onContinueSaved,
  onStartCareer,
}) => {
  const initialDb = useMemo(() => buildInitialDatabase(), []);
  const [selectedLeague, setSelectedLeague] = useState<LeagueId>('super_lig');
  const [selectedClubId, setSelectedClubId] = useState<string>('sl_aslanlar');
  const [managerName, setManagerName] = useState<string>('Emir Bozkurt');

  const leagueClubs = useMemo(
    () =>
      Object.values(initialDb.clubs)
        .filter((c) => c.leagueId === selectedLeague)
        .sort((a, b) => b.reputation - a.reputation),
    [initialDb.clubs, selectedLeague]
  );

  const selectedClub = initialDb.clubs[selectedClubId] ?? leagueClubs[0];
  const clubStars = useMemo(() => {
    if (!selectedClub) return [];
    return Object.values(initialDb.players)
      .filter((p) => p.clubId === selectedClub.id)
      .sort((a, b) => b.ovr - a.ovr)
      .slice(0, 5);
  }, [initialDb.players, selectedClub]);

  const handleSelectLeague = (lid: LeagueId) => {
    setSelectedLeague(lid);
    const first = Object.values(initialDb.clubs)
      .filter((c) => c.leagueId === lid)
      .sort((a, b) => b.reputation - a.reputation)[0];
    if (first) setSelectedClubId(first.id);
  };

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100">
      {/* Hero Banner */}
      <div className="relative border-b border-slate-800/80 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-950/50 via-[#0B0F17] to-slate-950" />
        <img
          src="/src/assets/images/stadium_night_hero_1794678599171.jpg"
          alt="Gece ışıklandırılmış Avrupa futbol stadyumu"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-35"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F17] via-[#0B0F17]/70 to-[#0B0F17]/50" />

        <div className="relative max-w-7xl mx-auto px-6 py-10 md:py-14 flex flex-col lg:flex-row lg:items-end justify-between gap-8">
          <div className="max-w-3xl">
            <div className="flex items-center gap-4 mb-5">
              <img src="/tacticball-icon.png" alt="TACTICBALL logosu" className="w-20 h-20 md:w-24 md:h-24 rounded-2xl border border-amber-400/70 shadow-[0_0_28px_rgba(234,179,8,0.22)]" />
              <div>
                <div className="text-xs font-semibold tracking-[0.28em] text-amber-300">MANAGER · PRESIDENT · LEGEND</div>
                <div className="text-[11px] text-slate-300 mt-1">KULÜBÜNÜ YÖNET, TARİH YAZ!</div>
              </div>
            </div>
            <div className="flex items-center gap-2.5 text-xs font-medium text-amber-300 tracking-wide mb-3">
              <span>2026–2027 Sezonu</span>
              <span aria-hidden="true">·</span>
              <span>Teknik Direktör &amp; Kulüp Başkanı Kariyeri</span>
            </div>
            <h1
              className="text-4xl md:text-6xl font-extrabold tracking-tight text-white uppercase leading-none"
              style={{ fontFamily: 'var(--font-display)', textWrap: 'balance' }}
            >
              TACTICBALL
            </h1>
            <p className="mt-3 text-sm md:text-base text-slate-300 leading-relaxed max-w-xl">
              Hem saha kenarındaki teknik direktör hem de yönetim kurulundaki kulüp başkanı olun.
              Gerçekçi 2026-2027 kadroları, sınırlı bütçe disiplini, taktiksel maç motoru ve
              kıran kırana transfer pazarlıklarıyla kulübünüzü zirveye taşıyın.
            </p>
          </div>

          {hasSavedCareer && (
            <div className="bg-[#121824]/95 border border-emerald-500/40 rounded-xl p-4 flex items-center justify-between gap-5 shrink-0">
              <div>
                <div className="text-xs text-emerald-400 font-medium">Kayıtlı Kariyer Bulundu</div>
                <div className="text-base font-semibold text-white mt-0.5">{savedClubName}</div>
                <div className="text-xs text-slate-400 font-mono tabular-nums mt-0.5">
                  {savedSeasonLabel} · {savedWeek}. Hafta
                </div>
              </div>
              <button
                onClick={onContinueSaved}
                className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-sm rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                Kariyere Devam Et
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Selection Workspace */}
      <div className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: League Tabs + Club Grid (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-[#121824] border border-slate-800/80 rounded-xl">
            {(Object.keys(LEAGUES_DATA) as LeagueId[]).map((lid) => {
              const l = LEAGUES_DATA[lid];
              const active = selectedLeague === lid;
              return (
                <button
                  key={lid}
                  onClick={() => handleSelectLeague(lid)}
                  className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-emerald-500 text-slate-950'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {l.name}
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {leagueClubs.map((club) => {
              const selected = club.id === selectedClub?.id;
              return (
                <button
                  key={club.id}
                  onClick={() => setSelectedClubId(club.id)}
                  className={`text-left p-4 rounded-xl border transition-all flex items-center gap-3.5 cursor-pointer ${
                    selected
                      ? 'bg-[#172030] border-emerald-500/70'
                      : 'bg-[#121824] border-slate-800/80 hover:border-slate-700 hover:bg-[#151C2A]'
                  }`}
                >
                  <ClubCrest club={club} size={44} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-sm text-white truncate">{club.name}</span>
                      <span className="font-mono tabular-nums text-xs font-semibold text-emerald-400 shrink-0">
                        {club.reputation} GÜÇ
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400 font-mono tabular-nums mt-1">
                      <span>Bütçe: {formatMoneyM(club.transferBudget)}</span>
                      <span aria-hidden="true">·</span>
                      <span>Borç: {formatMoneyM(club.debt)}</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Club Dossier & Start Form (5 cols) */}
        {selectedClub && (
          <div className="lg:col-span-5 bg-[#121824] border border-slate-800/80 rounded-xl p-6 space-y-6">
            <div className="flex items-center gap-4 pb-5 border-b border-slate-800/80">
              <ClubCrest club={selectedClub} size={58} />
              <div className="min-w-0">
                <div className="text-xs text-slate-400">
                  {LEAGUES_DATA[selectedClub.leagueId].name} · {selectedClub.stadiumName}
                </div>
                <h2
                  className="text-2xl font-bold text-white tracking-tight truncate"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  {selectedClub.name}
                </h2>
                <div className="text-xs text-emerald-400 font-mono tabular-nums mt-0.5">
                  Kapasite: {selectedClub.stadiumCapacity.toLocaleString('tr-TR')} Seyirci · Bilet: €
                  {selectedClub.ticketPrice}
                </div>
              </div>
            </div>

            {/* Financial & Target Grid */}
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-3">
                <div className="text-xs text-slate-400">Kulüp Kasası</div>
                <div className="text-lg font-semibold font-mono tabular-nums text-white mt-0.5">
                  {formatMoneyM(selectedClub.cash)}
                </div>
              </div>
              <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-3">
                <div className="text-xs text-slate-400">Transfer Bütçesi</div>
                <div className="text-lg font-semibold font-mono tabular-nums text-emerald-400 mt-0.5">
                  {formatMoneyM(selectedClub.transferBudget)}
                </div>
              </div>
              <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-3">
                <div className="text-xs text-slate-400">Toplam Kulüp Borcu</div>
                <div className="text-lg font-semibold font-mono tabular-nums text-amber-400 mt-0.5">
                  {formatMoneyM(selectedClub.debt)}
                </div>
              </div>
              <div className="bg-[#0B0F17] border border-slate-800/70 rounded-lg p-3">
                <div className="text-xs text-slate-400">Yönetim Lig Hedefi</div>
                <div className="text-lg font-semibold font-mono tabular-nums text-white mt-0.5">
                  İlk {selectedClub.objectives.minLeaguePos}
                </div>
              </div>
            </div>

            {/* Top 5 2026-27 Stars */}
            <div>
              <div className="text-xs font-semibold text-slate-400 mb-2.5 flex items-center justify-between">
                <span>2026–2027 Kadro Yıldızları</span>
                <span className="font-mono tabular-nums">Yaş / OVR / Değer</span>
              </div>
              <div className="divide-y divide-slate-800/60 border border-slate-800/70 rounded-lg bg-[#0B0F17]">
                {clubStars.map((p) => (
                  <div
                    key={p.id}
                    className="px-3.5 py-2.5 flex items-center justify-between text-xs gap-2"
                  >
                    <div className="min-w-0">
                      <span className="font-medium text-slate-100 truncate block">{p.name}</span>
                      <span className="text-slate-400">{p.nationality}</span>
                    </div>
                    <div className="font-mono tabular-nums text-right shrink-0 flex items-center gap-3">
                      <span className="text-slate-400">{p.age}y</span>
                      <span className="font-bold text-emerald-400">{p.ovr}</span>
                      <span className="text-slate-200 w-14 text-right">{formatMoneyM(p.marketValue)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Manager / President Name + Start Button */}
            <div className="space-y-3 pt-2">
              <label className="block">
                <span className="text-xs font-medium text-slate-300">
                  Başkan &amp; Teknik Direktör Adınız
                </span>
                <input
                  type="text"
                  value={managerName}
                  onChange={(e) => setManagerName(e.target.value)}
                  maxLength={32}
                  placeholder="Adınız Soyadınız"
                  className="mt-1.5 w-full px-3.5 py-2.5 bg-[#0B0F17] border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-emerald-500"
                />
              </label>

              <button
                onClick={() => onStartCareer(selectedClub.id, managerName)}
                className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{selectedClub.name} ile Kariyeri Başlat</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-[11px] text-slate-400 flex items-center gap-1.5">
                <Trophy className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>
                  Sınırsız bütçe yoktur: Kulüp kasası, borç faizleri ve UEFA mali kuralları gerçekçi
                  şekilde uygulanır.
                </span>
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
