import React from 'react';
import { getLeagueStandings, isTransferWindowOpen } from '../engine/careerEngine';
import { evaluateTeamStrength } from '../engine/matchEngine';
import { CareerState, MatchFixture, PressOption } from '../types/game';
import { formatMoneyM, formatWageK } from '../utils/formatters';
import { ClubCrest } from './ClubCrest';
import {
  AlertTriangle,
  Banknote,
  Calendar,
  MessageSquare,
  Play,
  Shield,
  TrendingUp,
  Users,
} from 'lucide-react';

interface DashboardViewProps {
  state: CareerState;
  nextUserMatch: MatchFixture | null;
  onPlayMatch: (fixture: MatchFixture) => void;
  onAdvanceWeek: () => void;
  onAnswerPress: (option: PressOption) => void;
  onNavigate: (tab: 'SQUAD' | 'TRANSFERS' | 'PRESIDENT' | 'COMPETITIONS' | 'AWARDS') => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  state,
  nextUserMatch,
  onPlayMatch,
  onAdvanceWeek,
  onAnswerPress,
  onNavigate,
}) => {
  const club = state.clubs[state.userClubId];
  const league = state.leagues[club.leagueId];
  const standings = getLeagueStandings(club.leagueId, state.clubs, state.fixtures);
  const rank = standings.findIndex((r) => r.clubId === club.id) + 1;

  const squad = Object.values(state.players).filter((p) => p.clubId === club.id);
  const weeklyWageTotal = squad.reduce((s, p) => s + p.weeklyWage, 0);
  const injuredCount = squad.filter((p) => p.injuryWeeks > 0).length;
  const suspendedCount = squad.filter((p) => p.suspendedWeeks > 0).length;
  const windowOpen = isTransferWindowOpen(state.week);

  const oppClub = nextUserMatch
    ? state.clubs[
        nextUserMatch.homeClubId === club.id ? nextUserMatch.awayClubId : nextUserMatch.homeClubId
      ]
    : null;

  const userStr = evaluateTeamStrength(club, state.players, club.startingXI, club.tactics);
  const oppStr = oppClub
    ? evaluateTeamStrength(oppClub, state.players, oppClub.startingXI, oppClub.tactics)
    : null;

  return (
    <div className="space-y-6">
      {/* Top Hero Row: Next Match Focal Anchor (8 cols) + Board & Fan Pulse (4 cols) */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-stretch">
        {/* Next Match Card */}
        <div className="xl:col-span-8 bg-[#121824] border border-slate-800/80 rounded-xl p-6 flex flex-col justify-between">
          {state.phase === 'SEASON_END' ? (
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <div className="text-xs font-medium text-emerald-400">
                  {state.seasonLabel} Sezonu Tamamlandı
                </div>
                <h2
                  className="text-3xl font-bold text-white mt-1"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Sezon Sonu Ödülleri &amp; Yeni Sezon Hazır
                </h2>
                <p className="text-sm text-slate-300 mt-2 max-w-xl">
                  Lig {rank}. sırada tamamlandı. Sezon ödüllerini inceleyip 2027-2028 sezonuna
                  geçebilirsiniz.
                </p>
              </div>
              <button
                onClick={() => onNavigate('AWARDS')}
                className="px-5 py-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm whitespace-nowrap shrink-0 cursor-pointer"
              >
                Ödülleri Gör ve Yeni Sezona Geç
              </button>
            </div>
          ) : nextUserMatch && oppClub ? (
            <>
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 pb-4 border-b border-slate-800/70">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-emerald-400" />
                  <span>
                    {nextUserMatch.competition === 'LEAGUE'
                      ? `${league.name} · ${nextUserMatch.week}. Hafta`
                      : nextUserMatch.competition === 'CUP'
                      ? `Ulusal Kupa · ${nextUserMatch.roundName}`
                      : nextUserMatch.competition === 'CHAMPIONS_CUP'
                      ? `Avrupa Şampiyonlar Kupası · ${nextUserMatch.roundName}`
                      : `Avrupa Kalkanı · ${nextUserMatch.roundName}`}
                  </span>
                </div>
                <span className="font-mono tabular-nums text-slate-300">
                  {nextUserMatch.homeClubId === club.id
                    ? `İç Saha · ${club.stadiumName}`
                    : `Deplasman · ${oppClub.stadiumName}`}
                </span>
              </div>

              <div className="py-6 grid grid-cols-1 md:grid-cols-11 items-center gap-4">
                <div className="md:col-span-4 flex items-center gap-3.5">
                  <ClubCrest club={state.clubs[nextUserMatch.homeClubId]} size={56} />
                  <div className="min-w-0">
                    <div className="text-xs text-slate-400">Ev Sahibi</div>
                    <div className="text-lg font-bold text-white truncate">
                      {state.clubs[nextUserMatch.homeClubId].name}
                    </div>
                    <div className="text-xs font-mono tabular-nums text-emerald-400">
                      Güç:{' '}
                      {(nextUserMatch.homeClubId === club.id
                        ? userStr.overall
                        : oppStr?.overall ?? 75
                      ).toFixed(1)}
                    </div>
                  </div>
                </div>

                <div className="md:col-span-3 text-center">
                  <div
                    className="text-2xl font-extrabold text-slate-400 tracking-widest"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    VS
                  </div>
                  <div className="text-xs text-slate-400 font-mono mt-1">
                    Diziliş: {club.tactics.formation}
                  </div>
                </div>

                <div className="md:col-span-4 flex items-center md:justify-end gap-3.5 md:text-right">
                  <div className="min-w-0 order-2 md:order-1">
                    <div className="text-xs text-slate-400">Deplasman</div>
                    <div className="text-lg font-bold text-white truncate">
                      {state.clubs[nextUserMatch.awayClubId].name}
                    </div>
                    <div className="text-xs font-mono tabular-nums text-slate-300">
                      Güç:{' '}
                      {(nextUserMatch.awayClubId === club.id
                        ? userStr.overall
                        : oppStr?.overall ?? 75
                      ).toFixed(1)}
                    </div>
                  </div>
                  <ClubCrest
                    club={state.clubs[nextUserMatch.awayClubId]}
                    size={56}
                    className="order-1 md:order-2"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800/70 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-slate-400 flex flex-wrap items-center gap-3">
                  <span>
                    İlk 11 Ort. Kondisyon:{' '}
                    <strong className="text-white font-mono tabular-nums">
                      %
                      {Math.round(
                        club.startingXI.reduce(
                          (s, id) => s + (state.players[id]?.stamina ?? 80),
                          0
                        ) / Math.max(1, club.startingXI.length)
                      )}
                    </strong>
                  </span>
                  {(injuredCount > 0 || suspendedCount > 0) && (
                    <span className="text-amber-400 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      {injuredCount} Sakat · {suspendedCount} Cezalı
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2.5">
                  <button
                    onClick={() => onNavigate('SQUAD')}
                    className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    İlk 11 &amp; Taktik
                  </button>
                  <button
                    onClick={() => onPlayMatch(nextUserMatch)}
                    className="px-5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    Maça Çık
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <div className="text-xs text-slate-400">{state.week}. Hafta</div>
                <h2 className="text-2xl font-bold text-white mt-1">
                  Bu hafta takımınızın resmi maçı bulunmuyor
                </h2>
                <p className="text-sm text-slate-400 mt-1">
                  Diğer takımlar kupa ve Avrupa maçlarını oynarken antrenman ve transferlere
                  odaklanabilirsiniz.
                </p>
              </div>
              <button
                onClick={onAdvanceWeek}
                className="px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm whitespace-nowrap shrink-0 cursor-pointer"
              >
                Haftayı İlerle
              </button>
            </div>
          )}
        </div>

        {/* Right 4 Cols: Board & Fan Pulse */}
        <div className="xl:col-span-4 bg-[#121824] border border-slate-800/80 rounded-xl p-6 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                Yönetim &amp; Taraftar Nabzı
              </h3>
              <span className="text-xs font-mono tabular-nums text-slate-400">
                Lig Sırası: {rank}.
              </span>
            </div>

            <div className="mt-4 space-y-3.5">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Yönetim Kurulu Güveni</span>
                  <span className="font-mono tabular-nums font-semibold text-white">
                    %{club.boardTrust} ({club.boardTrust >= 65 ? 'İstikrarlı' : club.boardTrust >= 40 ? 'Dikkat' : 'Risk'})
                  </span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all ${
                      club.boardTrust >= 65
                        ? 'bg-emerald-500'
                        : club.boardTrust >= 40
                        ? 'bg-amber-500'
                        : 'bg-red-500'
                    }`}
                    style={{ width: `${club.boardTrust}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Taraftar Desteği</span>
                  <span className="font-mono tabular-nums font-semibold text-white">
                    %{club.fanSupport} ({club.fanSupport >= 65 ? 'Coşkulu' : club.fanSupport >= 40 ? 'Nötr' : 'Tepkili'})
                  </span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all ${
                      club.fanSupport >= 65
                        ? 'bg-emerald-500'
                        : club.fanSupport >= 40
                        ? 'bg-amber-500'
                        : 'bg-red-500'
                    }`}
                    style={{ width: `${club.fanSupport}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/70 text-xs space-y-1.5">
            <div className="text-slate-400 font-medium">Sezon Hedefleri</div>
            <div className="flex justify-between text-slate-200">
              <span>Lig Hedefi:</span>
              <span className="font-mono font-semibold">İlk {club.objectives.minLeaguePos}</span>
            </div>
            <div className="flex justify-between text-slate-200">
              <span>Ulusal Kupa:</span>
              <span className="font-semibold">{club.objectives.cupTarget}</span>
            </div>
            <div className="flex justify-between text-slate-200">
              <span>Avrupa:</span>
              <span className="font-semibold">{club.objectives.europeTarget}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4-Column KPI Financial Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>Kulüp Kasası (Nakit)</span>
            <Banknote className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-white mt-1.5">
            {formatMoneyM(club.cash)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Transfer Bütçesi: <span className="text-emerald-400 font-mono">{formatMoneyM(club.transferBudget)}</span>
          </div>
        </div>

        <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>Haftalık Maaş Yükü</span>
            <Users className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-white mt-1.5">
            {formatWageK(weeklyWageTotal)}
          </div>
          <div className="text-xs text-slate-400 font-mono tabular-nums mt-1">
            Bütçe Limiti: {formatWageK(club.wageBudgetWeekly)}
          </div>
        </div>

        <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>Kulüp Borcu</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-amber-400 mt-1.5">
            {formatMoneyM(club.debt)}
          </div>
          <div className="text-xs text-slate-400 font-mono tabular-nums mt-1">
            Haftalık Faiz: {formatMoneyM(club.debt * club.weeklyDebtInterestRate)}
          </div>
        </div>

        <div className="bg-[#121824] border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400">Transfer Penceresi &amp; Teklifler</div>
          <div className="text-lg font-bold text-white mt-1.5">
            {windowOpen ? 'Transfer Dönemi Açık' : 'Transfer Dönemi Kapalı'}
          </div>
          <button
            onClick={() => onNavigate('TRANSFERS')}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-medium mt-1.5 cursor-pointer"
          >
            {state.incomingOffers.length > 0
              ? `${state.incomingOffers.length} Gelen Teklifi İncele →`
              : 'Transfer Pazarını Aç →'}
          </button>
        </div>
      </div>

      {/* Bottom Split: Press Conference (6 cols) + Fan Reactions & News (6 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Press Conference */}
        <div className="lg:col-span-6 bg-[#121824] border border-slate-800/80 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/70 pb-3">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              Basın Toplantısı
            </h3>
            {state.pressQuestion && (
              <span className="text-xs text-slate-400">{state.pressQuestion.context}</span>
            )}
          </div>

          {state.pressQuestion ? (
            <>
              <div className="text-xs text-slate-400">{state.pressQuestion.journalist}</div>
              <p className="text-sm text-slate-100 leading-relaxed font-medium">
                &ldquo;{state.pressQuestion.question}&rdquo;
              </p>

              {state.pressQuestion.answered ? (
                <div className="p-3.5 rounded-lg bg-[#0B0F17] border border-emerald-500/30 text-xs text-emerald-300">
                  {
                    state.pressQuestion.options.find(
                      (o) => o.id === state.pressQuestion?.chosenOptionId
                    )?.reactionQuote
                  }
                </div>
              ) : (
                <div className="space-y-2 pt-1">
                  {state.pressQuestion.options.map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => onAnswerPress(opt)}
                      className="w-full text-left p-3 rounded-lg bg-[#0B0F17] hover:bg-slate-800/80 border border-slate-800 hover:border-emerald-500/50 transition-colors cursor-pointer"
                    >
                      <div className="text-[11px] font-semibold text-emerald-400 mb-0.5">
                        {opt.tone === 'OZGUVENLI'
                          ? 'Özgüvenli Yanıt'
                          : opt.tone === 'GERCEKCI'
                          ? 'Gerçekçi & Dengeli'
                          : 'Sert & Otoriter'}
                      </div>
                      <div className="text-xs text-slate-200">{opt.label}</div>
                    </button>
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="text-xs text-slate-500 py-6 text-center">
              Bu hafta için yeni basın sorusu bulunmuyor.
            </div>
          )}
        </div>

        {/* Fan Reactions & News */}
        <div className="lg:col-span-6 bg-[#121824] border border-slate-800/80 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/70 pb-3">
            <h3 className="text-sm font-semibold text-white">Taraftar Tepkileri &amp; Kulüp Haberleri</h3>
            <span className="text-xs text-slate-400 font-mono tabular-nums">
              {state.week}. Hafta
            </span>
          </div>

          <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
            {state.fanReactions.slice(0, 3).map((fr) => (
              <div
                key={fr.id}
                className="p-3 rounded-lg bg-[#0B0F17] border border-slate-800/70 text-xs space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">
                    {fr.author} <span className="text-slate-500 font-normal">{fr.handle}</span>
                  </span>
                  <span
                    className={
                      fr.sentiment === 'POSITIVE'
                        ? 'text-emerald-400'
                        : fr.sentiment === 'NEGATIVE'
                        ? 'text-red-400'
                        : 'text-slate-400'
                    }
                  >
                    {fr.sentiment === 'POSITIVE'
                      ? 'Olumlu'
                      : fr.sentiment === 'NEGATIVE'
                      ? 'Tepkili'
                      : 'Nötr'}
                  </span>
                </div>
                <p className="text-slate-300 leading-relaxed">{fr.message}</p>
              </div>
            ))}

            {state.news.slice(0, 4).map((n) => (
              <div key={n.id} className="pt-2.5 border-t border-slate-800/60 text-xs">
                <div className="flex items-center justify-between text-slate-400 mb-0.5">
                  <span className="font-semibold text-slate-200">{n.title}</span>
                  <span className="font-mono shrink-0 ml-2">{n.week}. Hf</span>
                </div>
                <p className="text-slate-400">{n.summary}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
