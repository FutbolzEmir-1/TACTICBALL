export type LeagueId =
  | 'super_lig'
  | 'premier_league'
  | 'la_liga'
  | 'bundesliga'
  | 'serie_a';

export type Position = 'GK' | 'DEF' | 'MID' | 'FWD';

export type PlayerRole =
  | 'GK_SWEEPER'
  | 'GK_CLASSIC'
  | 'DEF_STOPPER'
  | 'DEF_BALL'
  | 'DEF_WINGBACK'
  | 'MID_ANCHOR'
  | 'MID_B2B'
  | 'MID_MAESTRO'
  | 'MID_CAM'
  | 'FWD_INSIDE'
  | 'FWD_WINGER'
  | 'FWD_COMPLETE'
  | 'FWD_POACHER';

export type Formation = '4-3-3' | '4-2-3-1' | '3-5-2' | '4-4-2' | '3-4-3' | '5-3-2';

export type Mentality = 'DEFENSIVE' | 'BALANCED' | 'ATTACKING' | 'ALL_OUT';
export type PressingIntensity = 'LOW' | 'MEDIUM' | 'GEGENPRESS';
export type PassingStyle = 'SHORT' | 'MIXED' | 'DIRECT';
export type TempoStyle = 'SLOW' | 'NORMAL' | 'HIGH';

export type TrainingFocus =
  | 'BALANCED'
  | 'FITNESS'
  | 'ATTACK'
  | 'DEFENSE'
  | 'TACTICAL'
  | 'RECOVERY';

export type CrestPattern =
  | 'stripes'
  | 'halves'
  | 'sash'
  | 'cross'
  | 'chevron'
  | 'hoops'
  | 'solid';

export type CrestIcon =
  | 'lion'
  | 'eagle'
  | 'crown'
  | 'star'
  | 'anchor'
  | 'shield'
  | 'castle'
  | 'flame';

export type CompetitionType = 'LEAGUE' | 'CUP' | 'CHAMPIONS_CUP' | 'EUROPA_SHIELD';

export interface PlayerAttributes {
  pace: number;
  shooting: number;
  passing: number;
  dribbling: number;
  defending: number;
  physical: number;
}

export interface PlayerSeasonStats {
  apps: number;
  goals: number;
  assists: number;
  cleanSheets: number;
  yellowCards: number;
  redCards: number;
  ratingSum: number;
}

export interface Player {
  id: string;
  name: string;
  age: number; // Exact 2026-27 season age
  nationality: string;
  position: Position;
  secondaryPosition?: Position;
  ovr: number;
  pot: number;
  marketValue: number; // € Millions (e.g. 85.0)
  weeklyWage: number; // € Thousands (e.g. 180 = €180K/week)
  contractYearsLeft: number; // 1-5 years
  stamina: number; // 0-100
  morale: number; // 0-100
  form: number; // 1-10
  injuryWeeks: number; // 0 = healthy
  injuryName?: string;
  suspendedWeeks: number;
  yellowAccumulator: number;
  role: PlayerRole;
  attributes: PlayerAttributes;
  stats: PlayerSeasonStats;
  transferListed: boolean;
  clubId: string;
}

export interface SponsorContract {
  id: string;
  slot: 'SHIRT' | 'STADIUM' | 'SLEEVE';
  sponsorName: string;
  weeklyIncome: number; // €M/week
  titleBonus: number; // €M on league/european title
  yearsRemaining: number;
}

export interface ClubFacilities {
  training: number; // 1-5
  academy: number; // 1-5
  medical: number; // 1-5
  stadiumLevel: number; // 1-5
}

export interface ClubTactics {
  formation: Formation;
  mentality: Mentality;
  pressing: PressingIntensity;
  passing: PassingStyle;
  tempo: TempoStyle;
}

export interface ClubObjectives {
  minLeaguePos: number;
  cupTarget: string;
  europeTarget: string;
  keepPositiveCash: boolean;
}

export interface CashFlowEntry {
  week: number;
  category: 'BILET' | 'SPONSOR' | 'MAAS' | 'TRANSFER' | 'FAIZ' | 'TESIS' | 'ODUL';
  label: string;
  amount: number; // €M (+ income, - expense)
}

export interface Club {
  id: string;
  name: string;
  shortName: string;
  leagueId: LeagueId;
  primaryColor: string;
  secondaryColor: string;
  crestPattern: CrestPattern;
  crestIcon: CrestIcon;
  reputation: number; // 50-99
  stadiumName: string;
  stadiumCapacity: number;
  ticketPrice: number; // €
  cash: number; // €M
  transferBudget: number; // €M
  wageBudgetWeekly: number; // €K
  debt: number; // €M
  weeklyDebtInterestRate: number; // e.g. 0.004 per week
  sponsors: SponsorContract[];
  facilities: ClubFacilities;
  boardTrust: number; // 0-100
  fanSupport: number; // 0-100
  objectives: ClubObjectives;
  tactics: ClubTactics;
  startingXI: string[]; // 11 player IDs
  bench: string[]; // up to 7 player IDs
  trainingFocus: TrainingFocus;
  lastMatchRatings?: Record<string, number>;
}

export interface LeagueInfo {
  id: LeagueId;
  name: string;
  country: string;
  tvWeeklyBonus: number; // €M per matchweek
  championPrize: number; // €M
  reputationWeight: number;
}

export interface MatchEvent {
  minute: number;
  type: 'GOAL' | 'YELLOW' | 'RED' | 'INJURY' | 'SUB' | 'BIG_CHANCE';
  clubId: string;
  playerId: string;
  playerName: string;
  assistPlayerId?: string;
  assistPlayerName?: string;
  detail: string;
}

export interface MatchStats {
  homePossession: number;
  homeShots: number;
  awayShots: number;
  homeShotsOnTarget: number;
  awayShotsOnTarget: number;
  homeXG: number;
  awayXG: number;
}

export interface MatchFixture {
  id: string;
  competition: CompetitionType;
  leagueId?: LeagueId;
  week: number;
  roundName?: string;
  isKnockout?: boolean;
  homeClubId: string;
  awayClubId: string;
  played: boolean;
  homeGoals?: number;
  awayGoals?: number;
  penaltyWinnerId?: string;
  events: MatchEvent[];
  stats?: MatchStats;
  playerRatings?: Record<string, number>;
  manOfTheMatchId?: string;
}

export interface LeagueStandingRow {
  clubId: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  gf: number;
  ga: number;
  gd: number;
  points: number;
  form: ('G' | 'B' | 'M')[];
}

export interface TransferRecord {
  id: string;
  week: number;
  seasonLabel: string;
  playerId: string;
  playerName: string;
  playerOvr: number;
  fromClubId: string;
  fromClubName: string;
  toClubId: string;
  toClubName: string;
  fee: number; // €M
}

export interface IncomingOffer {
  id: string;
  playerId: string;
  fromClubId: string;
  fee: number; // €M
  sellOnPercent: number;
  expiresWeek: number;
}

export interface PressOption {
  id: string;
  tone: 'OZGUVENLI' | 'GERCEKCI' | 'SERT';
  label: string;
  moraleDelta: number;
  fanDelta: number;
  boardDelta: number;
  reactionQuote: string;
}

export interface PressQuestion {
  id: string;
  context: string;
  journalist: string;
  question: string;
  options: PressOption[];
  answered: boolean;
  chosenOptionId?: string;
}

export interface FanReaction {
  id: string;
  week: number;
  author: string;
  handle: string;
  sentiment: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
  message: string;
}

export interface NewsItem {
  id: string;
  week: number;
  category: 'TRANSFER' | 'MAC' | 'FINANS' | 'YONETIM' | 'ODUL';
  title: string;
  summary: string;
}

export interface SeasonAward {
  title: string;
  winnerName: string;
  clubName: string;
  clubId: string;
  metricLabel: string;
}

export interface SeasonHistoryEntry {
  seasonLabel: string;
  clubId: string;
  clubName: string;
  leaguePosition: number;
  leagueName: string;
  cupResult: string;
  europeResult: string;
  points: number;
  awards: SeasonAward[];
  leagueChampions: Record<LeagueId, string>;
  championsCupWinner: string;
  europaShieldWinner: string;
}

export interface CareerState {
  managerName: string;
  presidentModeNote: string;
  userClubId: string;
  seasonIndex: number; // 0 = 2026-2027
  seasonLabel: string; // e.g. "2026-2027"
  week: number; // 1..20 (18 league weeks + postseason/awards)
  maxLeagueWeeks: number; // 18
  phase: 'REGULAR' | 'SEASON_END';
  leagues: Record<LeagueId, LeagueInfo>;
  clubs: Record<string, Club>;
  players: Record<string, Player>;
  fixtures: MatchFixture[];
  transfers: TransferRecord[];
  incomingOffers: IncomingOffer[];
  cashFlowLog: CashFlowEntry[];
  pressQuestion: PressQuestion | null;
  fanReactions: FanReaction[];
  news: NewsItem[];
  history: SeasonHistoryEntry[];
  latestAwards: SeasonAward[];
}
