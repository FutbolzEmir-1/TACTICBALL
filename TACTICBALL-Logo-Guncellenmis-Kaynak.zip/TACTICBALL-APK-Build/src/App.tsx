import { useEffect, useMemo, useState } from 'react';
import { AwardsHistoryView } from './components/AwardsHistoryView';
import { CareerSetup } from './components/CareerSetup';
import { ClubCrest } from './components/ClubCrest';
import { CompetitionsView } from './components/CompetitionsView';
import { ContractRenewModal } from './components/ContractRenewModal';
import { DashboardView } from './components/DashboardView';
import { MatchCenterModal } from './components/MatchCenterModal';
import { PresidentOfficeView } from './components/PresidentOfficeView';
import { SquadTacticsView } from './components/SquadTacticsView';
import { TransfersView } from './components/TransfersView';
import { pickBestLineup } from './data/database2026_27';
import {
  advanceWeekAfterMatches,
  createNewCareer,
  startNextSeason,
} from './engine/careerEngine';
import { applyMatchResultToDatabase, LiveMatchState } from './engine/matchEngine';
import {
  CareerState,
  ClubFacilities,
  ClubTactics,
  IncomingOffer,
  MatchFixture,
  Player,
  PlayerRole,
  PressOption,
  SponsorContract,
  TrainingFocus,
} from './types/game';
import { formatMoneyM } from './utils/formatters';
import {
  Award,
  Briefcase,
  Handshake,
  LayoutDashboard,
  LogOut,
  Menu,
  Play,
  Trophy,
  Users,
  X,
} from 'lucide-react';

const STORAGE_KEY = 'tacticball_career_save_v1';

type ActiveTab =
  | 'DASHBOARD'
  | 'SQUAD'
  | 'TRANSFERS'
  | 'PRESIDENT'
  | 'COMPETITIONS'
  | 'AWARDS';

const TAB_TITLES: Record<ActiveTab, string> = {
  DASHBOARD: 'Genel Bakış',
  SQUAD: 'Kadro & Taktik',
  TRANSFERS: 'Transfer & Sözleşme',
  PRESIDENT: 'Kulüp Başkanlığı',
  COMPETITIONS: 'Turnuvalar',
  AWARDS: 'Ödüller & Geçmiş',
};

export default function App() {
  const [savedCareer, setSavedCareer] = useState<CareerState | null>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw) as CareerState;
    } catch {
      return null;
    }
  });

  const [career, setCareer] = useState<CareerState | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('DASHBOARD');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeMatch, setActiveMatch] = useState<MatchFixture | null>(null);
  const [renewPlayer, setRenewPlayer] = useState<Player | null>(null);

  useEffect(() => {
    if (!career) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(career));
      setSavedCareer(career);
    } catch {
      // Ignore storage quota errors gracefully
    }
  }, [career]);

  const userClub = career ? career.clubs[career.userClubId] : null;

  const nextUserMatch = useMemo(() => {
    if (!career || career.phase === 'SEASON_END') return null;
    return (
      career.fixtures.find(
        (f) =>
          f.week === career.week &&
          !f.played &&
          (f.homeClubId === career.userClubId || f.awayClubId === career.userClubId)
      ) ?? null
    );
  }, [career]);

  const handleStartNewCareer = (clubId: string, managerName: string) => {
    const fresh = createNewCareer(clubId, managerName);
    setCareer(fresh);
    setActiveTab('DASHBOARD');
  };

  const handleContinueSaved = () => {
    if (savedCareer) {
      setCareer(savedCareer);
      setActiveTab('DASHBOARD');
    }
  };

  if (!career || !userClub) {
    return (
      <CareerSetup
        hasSavedCareer={Boolean(savedCareer)}
        savedClubName={savedCareer ? savedCareer.clubs[savedCareer.userClubId]?.name : undefined}
        savedSeasonLabel={savedCareer?.seasonLabel}
        savedWeek={savedCareer?.week}
        onContinueSaved={handleContinueSaved}
        onStartCareer={handleStartNewCareer}
      />
    );
  }

  // Match Completion Handler
  const handleFinishLiveMatch = (finalState: LiveMatchState) => {
    if (!activeMatch) return;
    const applied = applyMatchResultToDatabase(
      activeMatch,
      finalState,
      career.clubs,
      career.players
    );
    const updatedFixtures = career.fixtures.map((f) =>
      f.id === activeMatch.id ? applied.updatedFixture : f
    );

    const intermediate: CareerState = {
      ...career,
      clubs: applied.updatedClubs,
      players: applied.updatedPlayers,
      fixtures: updatedFixtures,
    };

    // Check if user has a second match in the same week (e.g., League + Cup/Europe)
    const remainingUserMatchThisWeek = intermediate.fixtures.find(
      (f) =>
        f.week === intermediate.week &&
        !f.played &&
        (f.homeClubId === intermediate.userClubId || f.awayClubId === intermediate.userClubId)
    );

    setActiveMatch(null);
    if (remainingUserMatchThisWeek) {
      setCareer(intermediate);
    } else {
      setCareer(advanceWeekAfterMatches(intermediate, [activeMatch.id]));
    }
  };

  const handleAdvanceWeekOnly = () => {
    if (career.phase === 'SEASON_END') {
      setActiveTab('AWARDS');
      return;
    }
    if (nextUserMatch) {
      setActiveMatch(nextUserMatch);
      return;
    }
    setCareer(advanceWeekAfterMatches(career, []));
  };

  const handleAnswerPress = (option: PressOption) => {
    if (!career.pressQuestion || career.pressQuestion.answered) return;
    const updatedPlayers = { ...career.players };
    Object.values(updatedPlayers).forEach((p) => {
      if (p.clubId === userClub.id) {
        updatedPlayers[p.id] = {
          ...p,
          morale: Math.max(25, Math.min(99, p.morale + option.moraleDelta)),
        };
      }
    });

    setCareer({
      ...career,
      players: updatedPlayers,
      clubs: {
        ...career.clubs,
        [userClub.id]: {
          ...userClub,
          fanSupport: Math.max(15, Math.min(99, userClub.fanSupport + option.fanDelta)),
          boardTrust: Math.max(10, Math.min(99, userClub.boardTrust + option.boardDelta)),
        },
      },
      pressQuestion: {
        ...career.pressQuestion,
        answered: true,
        chosenOptionId: option.id,
      },
    });
  };

  // Squad & Tactics handlers
  const handleUpdateTactics = (tactics: ClubTactics) => {
    setCareer({
      ...career,
      clubs: { ...career.clubs, [userClub.id]: { ...userClub, tactics } },
    });
  };

  const handleUpdateLineup = (startingXI: string[], bench: string[]) => {
    setCareer({
      ...career,
      clubs: { ...career.clubs, [userClub.id]: { ...userClub, startingXI, bench } },
    });
  };

  const handleUpdatePlayerRole = (playerId: string, role: PlayerRole) => {
    const p = career.players[playerId];
    if (!p) return;
    setCareer({
      ...career,
      players: { ...career.players, [playerId]: { ...p, role } },
    });
  };

  const handleUpdateTraining = (trainingFocus: TrainingFocus) => {
    setCareer({
      ...career,
      clubs: { ...career.clubs, [userClub.id]: { ...userClub, trainingFocus } },
    });
  };

  const handleToggleTransferList = (playerId: string) => {
    const p = career.players[playerId];
    if (!p) return;
    setCareer({
      ...career,
      players: { ...career.players, [playerId]: { ...p, transferListed: !p.transferListed } },
    });
  };

  const handleRenewContract = (playerId: string, newWage: number, newYears: number) => {
    const p = career.players[playerId];
    if (!p) return;
    setCareer({
      ...career,
      players: {
        ...career.players,
        [playerId]: {
          ...p,
          weeklyWage: newWage,
          contractYearsLeft: newYears,
          morale: Math.min(99, p.morale + 5),
        },
      },
    });
  };

  // Transfer Handlers
  const handleCompletePurchase = (
    playerId: string,
    fee: number,
    weeklyWage: number,
    contractYears: number
  ) => {
    const target = career.players[playerId];
    if (!target) return;
    const seller = career.clubs[target.clubId];

    const updatedPlayers = {
      ...career.players,
      [playerId]: {
        ...target,
        clubId: userClub.id,
        weeklyWage,
        contractYearsLeft: contractYears,
        transferListed: false,
        morale: 84,
      },
    };

    const userSquad = Object.values(updatedPlayers).filter((p) => p.clubId === userClub.id);
    const sellerSquad = seller
      ? Object.values(updatedPlayers).filter((p) => p.clubId === seller.id)
      : [];

    const nextUserCash = Number(Math.max(0, userClub.cash - fee).toFixed(2));
    const nextUserTB = Number(Math.max(0, userClub.transferBudget - fee).toFixed(2));

    const updatedClubs = {
      ...career.clubs,
      [userClub.id]: {
        ...userClub,
        cash: nextUserCash,
        transferBudget: Math.min(nextUserTB, nextUserCash),
        bench:
          userClub.bench.length < 7 ? [...userClub.bench, playerId] : userClub.bench,
      },
    };

    if (seller) {
      const sLine = pickBestLineup(sellerSquad, seller.tactics.formation);
      updatedClubs[seller.id] = {
        ...seller,
        cash: Number((seller.cash + fee).toFixed(2)),
        transferBudget: Number((seller.transferBudget + fee * 0.7).toFixed(2)),
        startingXI: sLine.startingXI,
        bench: sLine.bench,
      };
    }

    if (userSquad.length > 0 && updatedClubs[userClub.id].startingXI.length < 11) {
      const uLine = pickBestLineup(userSquad, userClub.tactics.formation);
      updatedClubs[userClub.id].startingXI = uLine.startingXI;
      updatedClubs[userClub.id].bench = uLine.bench;
    }

    setCareer({
      ...career,
      clubs: updatedClubs,
      players: updatedPlayers,
      transfers: [
        {
          id: `tr_u_${Date.now()}`,
          week: career.week,
          seasonLabel: career.seasonLabel,
          playerId,
          playerName: target.name,
          playerOvr: target.ovr,
          fromClubId: seller?.id ?? '',
          fromClubName: seller?.name ?? 'Serbest',
          toClubId: userClub.id,
          toClubName: userClub.name,
          fee,
        },
        ...career.transfers,
      ],
      cashFlowLog: [
        ...career.cashFlowLog,
        {
          week: career.week,
          category: 'TRANSFER',
          label: `Transfer Bonservis: ${target.name}`,
          amount: -fee,
        },
      ],
      news: [
        {
          id: `news_u_tr_${Date.now()}`,
          week: career.week,
          category: 'TRANSFER' as const,
          title: `${userClub.name} İmzaladı: ${target.name}`,
          summary: `${userClub.name}, ${target.name} transferini €${fee.toFixed(1)}M bonservisle tamamladı.`,
        },
        ...career.news,
      ].slice(0, 35),
    });
  };

  const handleRespondIncomingOffer = (offer: IncomingOffer, action: 'ACCEPT' | 'REJECT') => {
    if (action === 'REJECT') {
      setCareer({
        ...career,
        incomingOffers: career.incomingOffers.filter((o) => o.id !== offer.id),
      });
      return;
    }

    const p = career.players[offer.playerId];
    const buyer = career.clubs[offer.fromClubId];
    if (!p || !buyer) return;

    const updatedPlayers = {
      ...career.players,
      [p.id]: {
        ...p,
        clubId: buyer.id,
        transferListed: false,
        contractYearsLeft: 4,
      },
    };

    const userSquad = Object.values(updatedPlayers).filter((pl) => pl.clubId === userClub.id);
    const uLine = pickBestLineup(userSquad, userClub.tactics.formation);
    const buyerSquad = Object.values(updatedPlayers).filter((pl) => pl.clubId === buyer.id);
    const bLine = pickBestLineup(buyerSquad, buyer.tactics.formation);

    const nextUserCash = Number((userClub.cash + offer.fee).toFixed(2));

    setCareer({
      ...career,
      players: updatedPlayers,
      clubs: {
        ...career.clubs,
        [userClub.id]: {
          ...userClub,
          cash: nextUserCash,
          transferBudget: Number((userClub.transferBudget + offer.fee * 0.75).toFixed(2)),
          startingXI: uLine.startingXI,
          bench: uLine.bench,
          fanSupport: Math.max(
            20,
            Math.min(99, userClub.fanSupport + (p.ovr >= 83 ? -5 : 1))
          ),
        },
        [buyer.id]: {
          ...buyer,
          cash: Number(Math.max(0, buyer.cash - offer.fee).toFixed(2)),
          transferBudget: Number(Math.max(0, buyer.transferBudget - offer.fee).toFixed(2)),
          startingXI: bLine.startingXI,
          bench: bLine.bench,
        },
      },
      incomingOffers: career.incomingOffers.filter(
        (o) => o.id !== offer.id && o.playerId !== p.id
      ),
      transfers: [
        {
          id: `tr_sell_${Date.now()}`,
          week: career.week,
          seasonLabel: career.seasonLabel,
          playerId: p.id,
          playerName: p.name,
          playerOvr: p.ovr,
          fromClubId: userClub.id,
          fromClubName: userClub.name,
          toClubId: buyer.id,
          toClubName: buyer.name,
          fee: offer.fee,
        },
        ...career.transfers,
      ],
      cashFlowLog: [
        ...career.cashFlowLog,
        {
          week: career.week,
          category: 'TRANSFER',
          label: `Oyuncu Satışı: ${p.name} → ${buyer.shortName}`,
          amount: offer.fee,
        },
      ],
    });
  };

  // President Office Handlers
  const handleUpdateTicketPrice = (ticketPrice: number) => {
    const fanDelta = ticketPrice > userClub.ticketPrice + 10 ? -2 : ticketPrice < 25 ? 1 : 0;
    setCareer({
      ...career,
      clubs: {
        ...career.clubs,
        [userClub.id]: {
          ...userClub,
          ticketPrice,
          fanSupport: Math.max(15, Math.min(99, userClub.fanSupport + fanDelta)),
        },
      },
    });
  };

  const handleAdjustTransferBudget = (newBudget: number) => {
    const clamped = Math.min(userClub.cash, Math.max(0, newBudget));
    setCareer({
      ...career,
      clubs: { ...career.clubs, [userClub.id]: { ...userClub, transferBudget: clamped } },
    });
  };

  const handlePayDebt = (amount: number) => {
    const pay = Math.min(amount, userClub.cash, userClub.debt);
    if (pay <= 0) return;
    const nextCash = Number((userClub.cash - pay).toFixed(2));
    setCareer({
      ...career,
      clubs: {
        ...career.clubs,
        [userClub.id]: {
          ...userClub,
          cash: nextCash,
          transferBudget: Math.min(userClub.transferBudget, nextCash),
          debt: Number((userClub.debt - pay).toFixed(2)),
          boardTrust: Math.min(99, userClub.boardTrust + 3),
        },
      },
      cashFlowLog: [
        ...career.cashFlowLog,
        {
          week: career.week,
          category: 'FAIZ',
          label: 'Erken Ana Para Borç Ödemesi',
          amount: -pay,
        },
      ],
    });
  };

  const handleTakeLoan = (amount: number) => {
    setCareer({
      ...career,
      clubs: {
        ...career.clubs,
        [userClub.id]: {
          ...userClub,
          cash: Number((userClub.cash + amount).toFixed(2)),
          debt: Number((userClub.debt + amount * 1.2).toFixed(2)),
          boardTrust: Math.max(10, userClub.boardTrust - 4),
        },
      },
      cashFlowLog: [
        ...career.cashFlowLog,
        {
          week: career.week,
          category: 'FAIZ',
          label: 'Acil Banka Kredisi Kullanımı',
          amount,
        },
      ],
    });
  };

  const handleUpgradeFacility = (key: keyof ClubFacilities, cost: number) => {
    if (userClub.cash < cost || userClub.facilities[key] >= 5) return;
    const nextCash = Number((userClub.cash - cost).toFixed(2));
    const nextFacilities = {
      ...userClub.facilities,
      [key]: userClub.facilities[key] + 1,
    };
    setCareer({
      ...career,
      clubs: {
        ...career.clubs,
        [userClub.id]: {
          ...userClub,
          cash: nextCash,
          transferBudget: Math.min(userClub.transferBudget, nextCash),
          facilities: nextFacilities,
          stadiumCapacity:
            key === 'stadiumLevel' ? userClub.stadiumCapacity + 6000 : userClub.stadiumCapacity,
          fanSupport: Math.min(99, userClub.fanSupport + 2),
        },
      },
      cashFlowLog: [
        ...career.cashFlowLog,
        {
          week: career.week,
          category: 'TESIS',
          label: `Tesis Yatırımı (${key})`,
          amount: -cost,
        },
      ],
    });
  };

  const handleChangeSponsor = (
    slot: SponsorContract['slot'],
    option: Omit<SponsorContract, 'id'>
  ) => {
    setCareer({
      ...career,
      clubs: {
        ...career.clubs,
        [userClub.id]: {
          ...userClub,
          sponsors: userClub.sponsors.map((sp) =>
            sp.slot === slot ? { ...option, id: sp.id } : sp
          ),
        },
      },
    });
  };

  const handleStartNextSeason = () => {
    setCareer(startNextSeason(career));
    setActiveTab('DASHBOARD');
  };

  const navItems: { id: ActiveTab; label: string; icon: typeof LayoutDashboard; badge?: number }[] = [
    { id: 'DASHBOARD', label: 'Genel Bakış', icon: LayoutDashboard },
    { id: 'SQUAD', label: 'Kadro & Taktik', icon: Users },
    {
      id: 'TRANSFERS',
      label: 'Transfer & Sözleşme',
      icon: Handshake,
      badge: career.incomingOffers.length || undefined,
    },
    { id: 'PRESIDENT', label: 'Kulüp Başkanlığı', icon: Briefcase },
    { id: 'COMPETITIONS', label: 'Turnuvalar', icon: Trophy },
    { id: 'AWARDS', label: 'Ödüller & Geçmiş', icon: Award },
  ];

  const userSquadWages = Object.values(career.players)
    .filter((p) => p.clubId === userClub.id)
    .reduce((s, p) => s + p.weeklyWage, 0);

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex">
      {/* Desktop Sidebar (240px) */}
      <aside className="hidden lg:flex w-60 shrink-0 flex-col justify-between bg-[#0E141F] border-r border-slate-800/80 p-4 sticky top-0 h-screen">
        <div className="space-y-6">
          {/* Brand */}
          <div className="px-2 pt-1">
            <div
              className="text-2xl font-extrabold tracking-tight text-white uppercase"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              TACTİCBALL
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Başkan &amp; Teknik Direktör
            </div>
          </div>

          {/* Club Identity Box */}
          <div className="p-3 rounded-xl bg-[#121824] border border-slate-800/80 flex items-center gap-3">
            <ClubCrest club={userClub} size={38} />
            <div className="min-w-0">
              <div className="text-xs font-bold text-white truncate">{userClub.name}</div>
              <div className="text-[11px] text-slate-400 truncate">{career.managerName}</div>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full px-3 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                    active
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4" />
                    <span className="whitespace-nowrap">{item.label}</span>
                  </span>
                  {item.badge !== undefined && (
                    <span className="font-mono text-[11px] font-bold text-emerald-400">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        <button
          onClick={() => setCareer(null)}
          className="px-3 py-2 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-slate-800/60 flex items-center gap-2 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Kulüp Seçimine Dön</span>
        </button>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden bg-black/70" onClick={() => setMobileMenuOpen(false)}>
          <aside
            className="w-64 h-full bg-[#0E141F] border-r border-slate-800 p-4 flex flex-col justify-between"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <span
                  className="text-xl font-extrabold text-white uppercase"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  TACTİCBALL
                </span>
                <button onClick={() => setMobileMenuOpen(false)} className="p-1 text-slate-400">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <nav className="space-y-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const active = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full px-3 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-2.5 ${
                        active ? 'bg-emerald-500/15 text-emerald-400' : 'text-slate-300'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
            <button
              onClick={() => setCareer(null)}
              className="px-3 py-2 text-xs text-slate-400 flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Kulüp Seçimine Dön</span>
            </button>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Bar Contract: Breadcrumb — Context — 1 Primary Action */}
        <header className="sticky top-0 z-30 bg-[#0B0F17]/95 backdrop-blur border-b border-slate-800/80 px-5 md:px-8 py-3.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-1.5 rounded-lg bg-slate-800 text-slate-200"
              aria-label="Menü"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="text-xs md:text-sm text-slate-400 truncate">
              <span className="text-white font-semibold">{userClub.name}</span>
              <span className="mx-2">/</span>
              <span>{TAB_TITLES[activeTab]}</span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-4 text-xs font-mono tabular-nums text-slate-300 shrink-0">
            <span>{career.seasonLabel}</span>
            <span aria-hidden="true">·</span>
            <span>
              {career.phase === 'SEASON_END' ? 'Sezon Sonu' : `${career.week}. Hafta`}
            </span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-semibold">
              Kasa: {formatMoneyM(userClub.cash)}
            </span>
          </div>

          <button
            onClick={handleAdvanceWeekOnly}
            className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>
              {career.phase === 'SEASON_END'
                ? 'Ödülleri Gör'
                : nextUserMatch
                ? 'Maça Çık'
                : 'Haftayı İlerle'}
            </span>
          </button>
        </header>

        {/* Active View */}
        <main className="flex-1 p-5 md:p-8 max-w-[1440px] w-full mx-auto">
          {activeTab === 'DASHBOARD' && (
            <DashboardView
              state={career}
              nextUserMatch={nextUserMatch}
              onPlayMatch={(fx) => setActiveMatch(fx)}
              onAdvanceWeek={handleAdvanceWeekOnly}
              onAnswerPress={handleAnswerPress}
              onNavigate={(t) => setActiveTab(t)}
            />
          )}

          {activeTab === 'SQUAD' && (
            <SquadTacticsView
              state={career}
              onUpdateTactics={handleUpdateTactics}
              onUpdateLineup={handleUpdateLineup}
              onUpdatePlayerRole={handleUpdatePlayerRole}
              onUpdateTraining={handleUpdateTraining}
              onToggleTransferList={handleToggleTransferList}
              onOpenRenewContract={(p) => setRenewPlayer(p)}
            />
          )}

          {activeTab === 'TRANSFERS' && (
            <TransfersView
              state={career}
              onCompletePurchase={handleCompletePurchase}
              onRespondIncomingOffer={handleRespondIncomingOffer}
            />
          )}

          {activeTab === 'PRESIDENT' && (
            <PresidentOfficeView
              state={career}
              onUpdateTicketPrice={handleUpdateTicketPrice}
              onAdjustTransferBudget={handleAdjustTransferBudget}
              onPayDebt={handlePayDebt}
              onTakeLoan={handleTakeLoan}
              onUpgradeFacility={handleUpgradeFacility}
              onChangeSponsor={handleChangeSponsor}
            />
          )}

          {activeTab === 'COMPETITIONS' && <CompetitionsView state={career} />}

          {activeTab === 'AWARDS' && (
            <AwardsHistoryView state={career} onStartNextSeason={handleStartNextSeason} />
          )}
        </main>
      </div>

      {/* Live Match Center Modal */}
      {activeMatch && (
        <MatchCenterModal
          fixture={activeMatch}
          userClubId={career.userClubId}
          clubs={career.clubs}
          players={career.players}
          onFinishMatch={handleFinishLiveMatch}
        />
      )}

      {/* Contract Renewal Modal */}
      {renewPlayer && (
        <ContractRenewModal
          player={renewPlayer}
          wageBudgetWeekly={userClub.wageBudgetWeekly}
          currentClubWageTotal={userSquadWages}
          onClose={() => setRenewPlayer(null)}
          onRenew={handleRenewContract}
        />
      )}
    </div>
  );
}
