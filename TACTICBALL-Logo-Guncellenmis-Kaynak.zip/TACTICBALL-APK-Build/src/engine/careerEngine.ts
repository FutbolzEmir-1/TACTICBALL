import {
  buildInitialDatabase,
  LEAGUES_DATA,
  pickBestLineup,
} from '../data/database2026_27';
import {
  CareerState,
  CashFlowEntry,
  Club,
  FanReaction,
  IncomingOffer,
  LeagueId,
  LeagueStandingRow,
  MatchFixture,
  NewsItem,
  Player,
  Position,
  PressQuestion,
  SeasonAward,
  TransferRecord,
} from '../types/game';
import { applyMatchResultToDatabase, quickSimulateMatch } from './matchEngine';

function generateRoundRobinFixtures(
  clubIds: string[],
  leagueId: LeagueId,
  seasonIndex: number
): MatchFixture[] {
  const n = clubIds.length; // 10
  const teams = [...clubIds];
  const fixtures: MatchFixture[] = [];
  const rounds = n - 1; // 9

  for (let r = 0; r < rounds; r++) {
    for (let i = 0; i < n / 2; i++) {
      const t1 = teams[i];
      const t2 = teams[n - 1 - i];
      const flip = (r + i) % 2 === 1;
      const home1 = flip ? t2 : t1;
      const away1 = flip ? t1 : t2;

      // First half: weeks 1..9
      fixtures.push({
        id: `fx_s${seasonIndex}_${leagueId}_w${r + 1}_${i}`,
        competition: 'LEAGUE',
        leagueId,
        week: r + 1,
        homeClubId: home1,
        awayClubId: away1,
        played: false,
        events: [],
      });

      // Return leg: weeks 10..18
      fixtures.push({
        id: `fx_s${seasonIndex}_${leagueId}_w${r + 10}_${i}`,
        competition: 'LEAGUE',
        leagueId,
        week: r + 10,
        homeClubId: away1,
        awayClubId: home1,
        played: false,
        events: [],
      });
    }
    const last = teams.pop()!;
    teams.splice(1, 0, last);
  }
  return fixtures;
}

function generateInitialKnockoutCups(
  clubs: Record<string, Club>,
  seasonIndex: number
): MatchFixture[] {
  const fixtures: MatchFixture[] = [];

  // Domestic Cups: Top 8 clubs per league enter Quarterfinals in Week 6
  (Object.keys(LEAGUES_DATA) as LeagueId[]).forEach((lid) => {
    const lClubs = Object.values(clubs)
      .filter((c) => c.leagueId === lid)
      .sort((a, b) => b.reputation - a.reputation);

    // Pick 8 clubs (shuffled slightly for variety)
    const entrants = lClubs.slice(0, 8);
    for (let i = 0; i < 4; i++) {
      fixtures.push({
        id: `fx_s${seasonIndex}_cup_${lid}_qf_${i}`,
        competition: 'CUP',
        leagueId: lid,
        week: 6,
        roundName: 'Çeyrek Final',
        isKnockout: true,
        homeClubId: entrants[i].id,
        awayClubId: entrants[7 - i].id,
        played: false,
        events: [],
      });
    }
  });

  // European Champions Cup (16 elite clubs across 5 leagues) — Round of 16 in Week 4
  const allRanked = Object.values(clubs).sort((a, b) => b.reputation - a.reputation);
  const ccTeams = allRanked.slice(0, 16);
  for (let i = 0; i < 8; i++) {
    fixtures.push({
      id: `fx_s${seasonIndex}_cc_r16_${i}`,
      competition: 'CHAMPIONS_CUP',
      week: 4,
      roundName: 'Son 16 Turu',
      isKnockout: true,
      homeClubId: ccTeams[i].id,
      awayClubId: ccTeams[15 - i].id,
      played: false,
      events: [],
    });
  }

  // Europa Shield (next 16 clubs across 5 leagues) — Round of 16 in Week 4
  const esTeams = allRanked.slice(16, 32);
  for (let i = 0; i < 8; i++) {
    fixtures.push({
      id: `fx_s${seasonIndex}_es_r16_${i}`,
      competition: 'EUROPA_SHIELD',
      week: 4,
      roundName: 'Son 16 Turu',
      isKnockout: true,
      homeClubId: esTeams[i].id,
      awayClubId: esTeams[15 - i].id,
      played: false,
      events: [],
    });
  }

  return fixtures;
}

export function createNewCareer(userClubId: string, managerName: string): CareerState {
  const { clubs, players } = buildInitialDatabase();
  const seasonIndex = 0;
  const seasonLabel = '2026-2027';

  let fixtures: MatchFixture[] = [];
  (Object.keys(LEAGUES_DATA) as LeagueId[]).forEach((lid) => {
    const ids = Object.values(clubs)
      .filter((c) => c.leagueId === lid)
      .map((c) => c.id);
    fixtures = fixtures.concat(generateRoundRobinFixtures(ids, lid, seasonIndex));
  });
  fixtures = fixtures.concat(generateInitialKnockoutCups(clubs, seasonIndex));

  const userClub = clubs[userClubId];

  return {
    managerName: managerName.trim() || 'Teknik Direktör',
    presidentModeNote: 'Hem Teknik Direktör hem Kulüp Başkanı',
    userClubId,
    seasonIndex,
    seasonLabel,
    week: 1,
    maxLeagueWeeks: 18,
    phase: 'REGULAR',
    leagues: LEAGUES_DATA,
    clubs,
    players,
    fixtures,
    transfers: [],
    incomingOffers: [],
    cashFlowLog: [],
    pressQuestion: {
      id: 'press_init',
      context: 'Sezon Açılışı',
      journalist: 'Spor Analiz Masası',
      question: `${userClub.name} camiasında hem başkanlık hem teknik direktörlük koltuğuna oturdunuz. 2026-2027 sezonu için ilk mesajınız nedir?`,
      answered: false,
      options: [
        {
          id: 'opt_1',
          tone: 'OZGUVENLI',
          label: 'Hedefimiz net: Sahada kupalar, kasada sürdürülebilir güç.',
          moraleDelta: 4,
          fanDelta: 4,
          boardDelta: 3,
          reactionQuote: 'Başkan ve hocamızdan iddialı bir açılış konuşması geldi!',
        },
        {
          id: 'opt_2',
          tone: 'GERCEKCI',
          label: 'Mali disiplini koruyarak adım adım zirveye yürüyeceğiz.',
          moraleDelta: 2,
          fanDelta: 2,
          boardDelta: 5,
          reactionQuote: 'Yönetim kurulu mali gerçekçilik vurgusundan memnun.',
        },
        {
          id: 'opt_3',
          tone: 'SERT',
          label: 'Kimsenin yeri garanti değil, formayı hak eden giyecek.',
          moraleDelta: -1,
          fanDelta: 3,
          boardDelta: 2,
          reactionQuote: 'Tesislerde rekabet şimdiden üst seviyeye çıktı.',
        },
      ],
    },
    fanReactions: [
      {
        id: 'fan_init_1',
        week: 1,
        author: 'Tribün Sesi',
        handle: '@tribun_analiz',
        sentiment: 'POSITIVE',
        message: `${userClub.name} için yeni dönem başladı! 2026-27 kadrosuyla ligde iddialıyız.`,
      },
    ],
    news: [
      {
        id: 'news_init_1',
        week: 1,
        category: 'YONETIM',
        title: `${userClub.name} kulübünde yeni yönetim dönemi`,
        summary: `${managerName.trim() || 'Yeni Başkan'}, ${userClub.name} kulübünde tüm sportif ve mali yetkileri devraldı.`,
      },
      {
        id: 'news_init_2',
        week: 1,
        category: 'TRANSFER',
        title: '2026-2027 Yaz Transfer Dönemi Açıldı',
        summary: 'Avrupa ve Süper Lig kulüpleri 3. hafta sonuna kadar transfer görüşmeleri yürütebilecek.',
      },
    ],
    history: [],
    latestAwards: [],
  };
}

export function getLeagueStandings(
  leagueId: LeagueId,
  clubs: Record<string, Club>,
  fixtures: MatchFixture[]
): LeagueStandingRow[] {
  const rows: Record<string, LeagueStandingRow> = {};
  Object.values(clubs)
    .filter((c) => c.leagueId === leagueId)
    .forEach((c) => {
      rows[c.id] = {
        clubId: c.id,
        played: 0,
        won: 0,
        drawn: 0,
        lost: 0,
        gf: 0,
        ga: 0,
        gd: 0,
        points: 0,
        form: [],
      };
    });

  const leagueMatches = fixtures
    .filter((f) => f.competition === 'LEAGUE' && f.leagueId === leagueId && f.played)
    .sort((a, b) => a.week - b.week);

  for (const m of leagueMatches) {
    const h = rows[m.homeClubId];
    const a = rows[m.awayClubId];
    if (!h || !a) continue;
    const hg = m.homeGoals ?? 0;
    const ag = m.awayGoals ?? 0;

    h.played += 1;
    a.played += 1;
    h.gf += hg;
    h.ga += ag;
    a.gf += ag;
    a.ga += hg;
    h.gd = h.gf - h.ga;
    a.gd = a.gf - a.ga;

    if (hg > ag) {
      h.won += 1;
      h.points += 3;
      h.form.push('G');
      a.lost += 1;
      a.form.push('M');
    } else if (hg < ag) {
      a.won += 1;
      a.points += 3;
      a.form.push('G');
      h.lost += 1;
      h.form.push('M');
    } else {
      h.drawn += 1;
      a.drawn += 1;
      h.points += 1;
      a.points += 1;
      h.form.push('B');
      a.form.push('B');
    }
  }

  return Object.values(rows)
    .map((r) => ({ ...r, form: r.form.slice(-5) }))
    .sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      if (b.gd !== a.gd) return b.gd - a.gd;
      return b.gf - a.gf;
    });
}

export function isTransferWindowOpen(week: number): boolean {
  return (week >= 1 && week <= 3) || (week >= 9 && week <= 10);
}

function advanceKnockoutRounds(
  fixtures: MatchFixture[],
  currentWeek: number,
  seasonIndex: number
): MatchFixture[] {
  const created: MatchFixture[] = [];

  const getWinners = (comp: MatchFixture['competition'], week: number, leagueId?: LeagueId) =>
    fixtures
      .filter(
        (f) =>
          f.competition === comp &&
          f.week === week &&
          f.played &&
          (!leagueId || f.leagueId === leagueId)
      )
      .map((f) => {
        if ((f.homeGoals ?? 0) > (f.awayGoals ?? 0)) return f.homeClubId;
        if ((f.awayGoals ?? 0) > (f.homeGoals ?? 0)) return f.awayClubId;
        return f.penaltyWinnerId || f.homeClubId;
      });

  // Week 4 -> Week 8 (Champions Cup & Europa Shield Quarterfinals)
  if (currentWeek === 4) {
    (['CHAMPIONS_CUP', 'EUROPA_SHIELD'] as const).forEach((comp) => {
      const winners = getWinners(comp, 4);
      for (let i = 0; i + 1 < winners.length; i += 2) {
        created.push({
          id: `fx_s${seasonIndex}_${comp}_qf_${i}`,
          competition: comp,
          week: 8,
          roundName: 'Çeyrek Final',
          isKnockout: true,
          homeClubId: winners[i],
          awayClubId: winners[i + 1],
          played: false,
          events: [],
        });
      }
    });
  }

  // Week 8 -> Week 12 (European Semifinals)
  if (currentWeek === 8) {
    (['CHAMPIONS_CUP', 'EUROPA_SHIELD'] as const).forEach((comp) => {
      const winners = getWinners(comp, 8);
      for (let i = 0; i + 1 < winners.length; i += 2) {
        created.push({
          id: `fx_s${seasonIndex}_${comp}_sf_${i}`,
          competition: comp,
          week: 12,
          roundName: 'Yarı Final',
          isKnockout: true,
          homeClubId: winners[i],
          awayClubId: winners[i + 1],
          played: false,
          events: [],
        });
      }
    });
  }

  // Week 12 -> Week 16 (European Finals)
  if (currentWeek === 12) {
    (['CHAMPIONS_CUP', 'EUROPA_SHIELD'] as const).forEach((comp) => {
      const winners = getWinners(comp, 12);
      if (winners.length >= 2) {
        created.push({
          id: `fx_s${seasonIndex}_${comp}_final`,
          competition: comp,
          week: 16,
          roundName: 'Final',
          isKnockout: true,
          homeClubId: winners[0],
          awayClubId: winners[1],
          played: false,
          events: [],
        });
      }
    });
  }

  // Domestic Cups: Week 6 QF -> Week 11 SF -> Week 17 Final
  if (currentWeek === 6) {
    (Object.keys(LEAGUES_DATA) as LeagueId[]).forEach((lid) => {
      const winners = getWinners('CUP', 6, lid);
      for (let i = 0; i + 1 < winners.length; i += 2) {
        created.push({
          id: `fx_s${seasonIndex}_cup_${lid}_sf_${i}`,
          competition: 'CUP',
          leagueId: lid,
          week: 11,
          roundName: 'Yarı Final',
          isKnockout: true,
          homeClubId: winners[i],
          awayClubId: winners[i + 1],
          played: false,
          events: [],
        });
      }
    });
  }

  if (currentWeek === 11) {
    (Object.keys(LEAGUES_DATA) as LeagueId[]).forEach((lid) => {
      const winners = getWinners('CUP', 11, lid);
      if (winners.length >= 2) {
        created.push({
          id: `fx_s${seasonIndex}_cup_${lid}_final`,
          competition: 'CUP',
          leagueId: lid,
          week: 17,
          roundName: 'Kupa Finali',
          isKnockout: true,
          homeClubId: winners[0],
          awayClubId: winners[1],
          played: false,
          events: [],
        });
      }
    });
  }

  return created;
}

function runAiTransfersAndOffers(
  clubs: Record<string, Club>,
  players: Record<string, Player>,
  userClubId: string,
  week: number,
  seasonLabel: string
): {
  clubs: Record<string, Club>;
  players: Record<string, Player>;
  newTransfers: TransferRecord[];
  newOffers: IncomingOffer[];
  newNews: NewsItem[];
} {
  const nextClubs = { ...clubs };
  const nextPlayers = { ...players };
  const newTransfers: TransferRecord[] = [];
  const newOffers: IncomingOffer[] = [];
  const newNews: NewsItem[] = [];

  if (!isTransferWindowOpen(week)) {
    return { clubs: nextClubs, players: nextPlayers, newTransfers, newOffers, newNews };
  }

  // AI-to-AI realistic transfers (3 to 5 per transfer week)
  const aiClubs = Object.values(nextClubs).filter((c) => c.id !== userClubId && c.transferBudget >= 8);
  const shuffledBuyers = [...aiClubs].sort(() => Math.random() - 0.5).slice(0, 5);

  for (const buyer of shuffledBuyers) {
    const squad = Object.values(nextPlayers).filter((p) => p.clubId === buyer.id);
    if (squad.length >= 22) continue;

    // Find weakest position
    const posCounts: Record<Position, number> = { GK: 0, DEF: 0, MID: 0, FWD: 0 };
    squad.forEach((p) => (posCounts[p.position] += 1));
    const targetPos: Position =
      posCounts.FWD < 4 ? 'FWD' : posCounts.MID < 6 ? 'MID' : posCounts.DEF < 6 ? 'DEF' : 'MID';

    const maxSpend = Math.min(buyer.transferBudget * 0.65, Math.max(0, buyer.cash * 0.75));
    if (maxSpend < 6) continue;

    const candidates = Object.values(nextPlayers).filter(
      (p) =>
        p.clubId !== buyer.id &&
        p.clubId !== userClubId &&
        p.position === targetPos &&
        p.ovr >= buyer.reputation - 11 &&
        p.ovr <= buyer.reputation - 1 &&
        p.marketValue <= maxSpend &&
        p.marketValue >= 4
    );
    if (candidates.length === 0) continue;

    const target = candidates[Math.floor(Math.random() * Math.min(10, candidates.length))];
    const seller = nextClubs[target.clubId];
    const sellerSquadSize = Object.values(nextPlayers).filter((p) => p.clubId === seller.id).length;
    if (!seller || sellerSquadSize <= 15) continue;

    const fee = Number((target.marketValue * (1.02 + Math.random() * 0.16)).toFixed(1));
    if (buyer.transferBudget < fee || buyer.cash < fee) continue;

    // Execute AI transfer
    nextClubs[buyer.id] = {
      ...buyer,
      cash: Number((buyer.cash - fee).toFixed(1)),
      transferBudget: Number((buyer.transferBudget - fee).toFixed(1)),
    };
    nextClubs[seller.id] = {
      ...seller,
      cash: Number((seller.cash + fee).toFixed(1)),
      transferBudget: Number((seller.transferBudget + fee * 0.7).toFixed(1)),
    };
    nextPlayers[target.id] = {
      ...target,
      clubId: buyer.id,
      weeklyWage: Math.round(target.weeklyWage * 1.15),
      contractYearsLeft: 4,
      transferListed: false,
    };

    // Refresh both lineups
    const bLine = pickBestLineup(
      Object.values(nextPlayers).filter((p) => p.clubId === buyer.id),
      buyer.tactics.formation
    );
    const sLine = pickBestLineup(
      Object.values(nextPlayers).filter((p) => p.clubId === seller.id),
      seller.tactics.formation
    );
    nextClubs[buyer.id].startingXI = bLine.startingXI;
    nextClubs[buyer.id].bench = bLine.bench;
    nextClubs[seller.id].startingXI = sLine.startingXI;
    nextClubs[seller.id].bench = sLine.bench;

    newTransfers.push({
      id: `tr_${week}_${target.id}`,
      week,
      seasonLabel,
      playerId: target.id,
      playerName: target.name,
      playerOvr: target.ovr,
      fromClubId: seller.id,
      fromClubName: seller.name,
      toClubId: buyer.id,
      toClubName: buyer.name,
      fee,
    });

    newNews.push({
      id: `news_tr_${week}_${target.id}`,
      week,
      category: 'TRANSFER',
      title: `Resmi Transfer: ${target.name} → ${buyer.name}`,
      summary: `${buyer.name}, ${seller.name} kadrosundaki ${target.name} için €${fee}M bonservis ödedi.`,
    });
  }

  // Generate 1-2 incoming transfer offers for user's players
  const userPlayers = Object.values(nextPlayers).filter((p) => p.clubId === userClubId);
  const candidatesForSale = userPlayers
    .filter((p) => p.transferListed || (p.ovr >= 76 && Math.random() < 0.28))
    .sort((a, b) => (b.transferListed ? 1 : 0) - (a.transferListed ? 1 : 0) || b.ovr - a.ovr)
    .slice(0, 2);

  for (const target of candidatesForSale) {
    const interested = Object.values(nextClubs).filter(
      (c) =>
        c.id !== userClubId &&
        c.transferBudget >= target.marketValue * 0.9 &&
        c.reputation >= target.ovr - 10
    );
    if (interested.length === 0) continue;
    const bidder = interested[Math.floor(Math.random() * interested.length)];
    const offerFee = Number(
      (target.marketValue * (target.transferListed ? 0.96 : 1.12 + Math.random() * 0.15)).toFixed(1)
    );
    newOffers.push({
      id: `offer_${week}_${target.id}_${bidder.id}`,
      playerId: target.id,
      fromClubId: bidder.id,
      fee: offerFee,
      sellOnPercent: Math.random() < 0.4 ? 10 : 0,
      expiresWeek: week + 1,
    });
  }

  return { clubs: nextClubs, players: nextPlayers, newTransfers, newOffers, newNews };
}

function generateWeeklyPressAndFans(
  userClub: Club,
  userFixturesThisWeek: MatchFixture[],
  clubs: Record<string, Club>,
  week: number
): { press: PressQuestion | null; fans: FanReaction[] } {
  const mainMatch = userFixturesThisWeek[0];
  if (!mainMatch || !mainMatch.played) {
    return { press: null, fans: [] };
  }

  const isHome = mainMatch.homeClubId === userClub.id;
  const opp = clubs[isHome ? mainMatch.awayClubId : mainMatch.homeClubId];
  const ug = isHome ? mainMatch.homeGoals ?? 0 : mainMatch.awayGoals ?? 0;
  const og = isHome ? mainMatch.awayGoals ?? 0 : mainMatch.homeGoals ?? 0;
  const won = ug > og || mainMatch.penaltyWinnerId === userClub.id;
  const lost = !won && ug < og;

  const fans: FanReaction[] = [];
  if (won) {
    fans.push({
      id: `fan_w${week}_1`,
      week,
      author: 'Taraftar Forumu',
      handle: `@${userClub.shortName.toLowerCase()}_tribun`,
      sentiment: 'POSITIVE',
      message: `${opp.name} karşısında ${ug}-${og}'lık galibiyet! Taktik planımız sahada kusursuz işledi.`,
    });
  } else if (lost) {
    fans.push({
      id: `fan_w${week}_1`,
      week,
      author: 'Kale Arkası',
      handle: `@${userClub.shortName.toLowerCase()}_sesi`,
      sentiment: 'NEGATIVE',
      message: `${opp.name} karşısında ${ug}-${og} kaybetmek kabul edilemez. Hem taktik hem kadro kalitesi sorgulanmalı!`,
    });
  } else {
    fans.push({
      id: `fan_w${week}_1`,
      week,
      author: 'Maç Analiz',
      handle: `@futbol_nabzi`,
      sentiment: 'NEUTRAL',
      message: `${opp.name} deplasmanı/sahasında ${ug}-${og} beraberlik. Bir sonraki hafta mutlaka 3 puan lazım.`,
    });
  }

  if (userClub.ticketPrice > 68 && userClub.leagueId === 'super_lig') {
    fans.push({
      id: `fan_w${week}_ticket`,
      week,
      author: 'Taraftar Derneği',
      handle: '@bilet_fiyatlari',
      sentiment: 'NEGATIVE',
      message: `€${userClub.ticketPrice} bilet fiyatları tribünleri zorluyor. Başkanın taraftarı dinlemesi gerekiyor!`,
    });
  }

  const press: PressQuestion = {
    id: `press_w${week}`,
    context: `${opp.name} Maçı Sonrası`,
    journalist: 'Spor Basın Birliği',
    question: won
      ? `${opp.name} karşısında alınan ${ug}-${og} galibiyet sonrası hem başkan hem hoca olarak şampiyonluk ve mali tablo hakkında ne söylemek istersiniz?`
      : lost
      ? `${opp.name} mağlubiyeti taraftarları üzdü. Kulübün bütçe dengesi ve saha içi performans hakkında eleştirilere yanıtınız nedir?`
      : `${ug}-${og} biten mücadelede puanlar paylaşıldı. Önümüzdeki haftalar için rotasyon veya transfer düşünüyor musunuz?`,
    answered: false,
    options: [
      {
        id: 'opt_conf',
        tone: 'OZGUVENLI',
        label: won
          ? 'Bu takım doğru yolda; hedeflerimizden asla sapmayacağız.'
          : 'Kısa bir tökezleme yaşadık ama kalitemizle hızla döneceğiz.',
        moraleDelta: 3,
        fanDelta: 3,
        boardDelta: 2,
        reactionQuote: 'Soyunma odası kararlı duruştan güç aldı.',
      },
      {
        id: 'opt_real',
        tone: 'GERCEKCI',
        label: 'Hatalarımızı analiz edip bütçemiz dahilinde en doğru adımları atacağız.',
        moraleDelta: 1,
        fanDelta: 2,
        boardDelta: 4,
        reactionQuote: 'Yönetim ve medya soğukkanlı açıklamayı olumlu karşıladı.',
      },
      {
        id: 'opt_hard',
        tone: 'SERT',
        label: 'Sahada daha fazla mücadele şart; formayı hak etmeyen yedek bekler.',
        moraleDelta: won ? 2 : -3,
        fanDelta: 2,
        boardDelta: 1,
        reactionQuote: 'Oyunculara verilen sert mesaj gündeme oturdu.',
      },
    ],
  };

  return { press, fans };
}

export function computeSeasonAwards(state: CareerState): SeasonAward[] {
  const allPlayers = Object.values(state.players);
  const eligible = allPlayers.filter((p) => p.stats.apps >= 5);

  const avgRating = (p: Player) => (p.stats.apps > 0 ? p.stats.ratingSum / p.stats.apps : 0);

  const bestPlayer = [...eligible].sort(
    (a, b) =>
      avgRating(b) * 10 + b.stats.goals * 0.5 + b.stats.assists * 0.35 -
      (avgRating(a) * 10 + a.stats.goals * 0.5 + a.stats.assists * 0.35)
  )[0];

  const topScorer = [...allPlayers].sort((a, b) => b.stats.goals - a.stats.goals)[0];
  const topAssister = [...allPlayers].sort((a, b) => b.stats.assists - a.stats.assists)[0];
  const bestYoung = [...eligible]
    .filter((p) => p.age <= 22)
    .sort((a, b) => avgRating(b) * 10 + b.ovr * 0.2 - (avgRating(a) * 10 + a.ovr * 0.2))[0];

  const userLeague = state.clubs[state.userClubId].leagueId;
  const userStandings = getLeagueStandings(userLeague, state.clubs, state.fixtures);
  const championClub = state.clubs[userStandings[0]?.clubId ?? state.userClubId];

  const awards: SeasonAward[] = [];
  if (bestPlayer) {
    awards.push({
      title: 'Altın Top / Yılın Futbolcusu',
      winnerName: bestPlayer.name,
      clubName: state.clubs[bestPlayer.clubId]?.name ?? '',
      clubId: bestPlayer.clubId,
      metricLabel: `${avgRating(bestPlayer).toFixed(2)} Ort. Reyting · ${bestPlayer.stats.goals}G ${bestPlayer.stats.assists}A`,
    });
  }
  if (topScorer) {
    awards.push({
      title: 'Avrupa Gol Kralı',
      winnerName: topScorer.name,
      clubName: state.clubs[topScorer.clubId]?.name ?? '',
      clubId: topScorer.clubId,
      metricLabel: `${topScorer.stats.goals} Gol (${topScorer.stats.apps} Maç)`,
    });
  }
  if (topAssister) {
    awards.push({
      title: 'Asist Kralı',
      winnerName: topAssister.name,
      clubName: state.clubs[topAssister.clubId]?.name ?? '',
      clubId: topAssister.clubId,
      metricLabel: `${topAssister.stats.assists} Asist (${topAssister.stats.apps} Maç)`,
    });
  }
  if (bestYoung) {
    awards.push({
      title: 'Yılın Genç Oyuncusu (U22)',
      winnerName: bestYoung.name,
      clubName: state.clubs[bestYoung.clubId]?.name ?? '',
      clubId: bestYoung.clubId,
      metricLabel: `${bestYoung.age} Yaş · ${bestYoung.ovr} OVR · ${avgRating(bestYoung).toFixed(2)} Reyting`,
    });
  }
  if (championClub) {
    awards.push({
      title: 'Yılın Teknik Direktörü & Başkanı',
      winnerName: championClub.id === state.userClubId ? state.managerName : `${championClub.shortName} Menajeri`,
      clubName: championClub.name,
      clubId: championClub.id,
      metricLabel: `${state.leagues[userLeague].name} Şampiyonu (${userStandings[0]?.points ?? 0} Puan)`,
    });
  }

  return awards;
}

export function advanceWeekAfterMatches(
  state: CareerState,
  userPlayedFixtureIds: string[]
): CareerState {
  let nextClubs = { ...state.clubs };
  let nextPlayers = { ...state.players };
  const nextFixtures = state.fixtures.map((f) => ({ ...f }));
  const nextCashFlow = [...state.cashFlowLog];
  const nextNews = [...state.news];

  // 1. Quick simulate all unplayed matches of the current week
  for (let i = 0; i < nextFixtures.length; i++) {
    const fx = nextFixtures[i];
    if (fx.week === state.week && !fx.played && !userPlayedFixtureIds.includes(fx.id)) {
      const sim = quickSimulateMatch(fx, nextClubs, nextPlayers);
      const applied = applyMatchResultToDatabase(fx, sim, nextClubs, nextPlayers);
      nextFixtures[i] = applied.updatedFixture;
      nextClubs = applied.updatedClubs;
      nextPlayers = applied.updatedPlayers;
    }
  }

  // 2. Advance Knockout Cups / European Tournaments if round just finished
  const newKnockoutFixtures = advanceKnockoutRounds(nextFixtures, state.week, state.seasonIndex);
  const allFixtures = [...nextFixtures, ...newKnockoutFixtures];

  // 3. Weekly Finances for all clubs (and detailed cashflow log for user club)
  const weekMatches = allFixtures.filter((f) => f.week === state.week && f.played);
  for (const club of Object.values(nextClubs)) {
    const clubPlayers = Object.values(nextPlayers).filter((p) => p.clubId === club.id);
    const weeklyWagesM = clubPlayers.reduce((s, p) => s + p.weeklyWage, 0) / 1000;
    const sponsorIncomeM = club.sponsors.reduce((s, sp) => s + sp.weeklyIncome, 0);
    const tvIncomeM = state.leagues[club.leagueId].tvWeeklyBonus * 0.45;
    const debtInterestM = Number((club.debt * club.weeklyDebtInterestRate).toFixed(2));

    let ticketIncomeM = 0;
    const homeMatch = weekMatches.find((m) => m.homeClubId === club.id);
    if (homeMatch) {
      const opp = nextClubs[homeMatch.awayClubId];
      const priceElasticity = Math.max(0.45, Math.min(1.05, 1.15 - club.ticketPrice / 135));
      const supportFactor = 0.6 + (club.fanSupport / 100) * 0.4;
      const oppDraw = opp && opp.reputation >= 85 ? 1.08 : 0.95;
      const attendanceRatio = Math.min(0.99, Math.max(0.42, priceElasticity * supportFactor * oppDraw));
      ticketIncomeM = Number(((club.stadiumCapacity * attendanceRatio * club.ticketPrice) / 1_000_000).toFixed(2));
    }

    const netDelta = Number(
      (ticketIncomeM + sponsorIncomeM + tvIncomeM - weeklyWagesM - debtInterestM).toFixed(2)
    );
    let nextCash = Number((club.cash + netDelta).toFixed(2));
    let nextDebt = club.debt;
    let trustDelta = 0;

    // Realistic debt/deficit enforcement: negative cash triggers automatic emergency credit interest & board anger
    if (nextCash < 0) {
      const shortfall = Math.abs(nextCash);
      nextDebt = Number((nextDebt + shortfall).toFixed(2));
      nextCash = 0;
      trustDelta = -2;
    }

    nextClubs[club.id] = {
      ...club,
      cash: nextCash,
      debt: nextDebt,
      boardTrust: Math.max(5, Math.min(99, club.boardTrust + trustDelta)),
      transferBudget: Number(Math.min(club.transferBudget, Math.max(0, nextCash)).toFixed(2)),
    };

    if (club.id === state.userClubId) {
      if (ticketIncomeM > 0) {
        nextCashFlow.push({
          week: state.week,
          category: 'BILET',
          label: `Maç Günü Bilet Geliri (${club.stadiumName})`,
          amount: ticketIncomeM,
        });
      }
      nextCashFlow.push({
        week: state.week,
        category: 'SPONSOR',
        label: 'Sponsorluk & Yayın Geliri',
        amount: Number((sponsorIncomeM + tvIncomeM).toFixed(2)),
      });
      nextCashFlow.push({
        week: state.week,
        category: 'MAAS',
        label: 'Haftalık Kadro Maaş Ödemesi',
        amount: -Number(weeklyWagesM.toFixed(2)),
      });
      if (debtInterestM > 0) {
        nextCashFlow.push({
          week: state.week,
          category: 'FAIZ',
          label: 'Kulüp Borcu Haftalık Faizi',
          amount: -debtInterestM,
        });
      }
    }
  }

  // 4. Training, Recovery, Injury Countdown & Young Player Growth
  for (const pid of Object.keys(nextPlayers)) {
    const p = nextPlayers[pid];
    const club = nextClubs[p.clubId];
    if (!club) continue;

    const focus = club.trainingFocus;
    const medBonus = club.facilities.medical * 1.5;
    const trainBonus = club.facilities.training * 0.04;
    const baseRecovery = focus === 'RECOVERY' ? 24 : focus === 'FITNESS' ? 12 : 16;

    let ovr = p.ovr;
    const attrs = { ...p.attributes };
    if (p.age <= 23 && ovr < p.pot && p.injuryWeeks === 0) {
      const growthProb = 0.07 + trainBonus + (focus === 'TACTICAL' ? 0.03 : 0);
      if (Math.random() < growthProb) {
        ovr = Math.min(p.pot, ovr + 1);
        if (focus === 'ATTACK') attrs.shooting = Math.min(99, attrs.shooting + 2);
        else if (focus === 'DEFENSE') attrs.defending = Math.min(99, attrs.defending + 2);
        else if (focus === 'FITNESS') attrs.physical = Math.min(99, attrs.physical + 2);
        else attrs.passing = Math.min(99, attrs.passing + 1);
      }
    } else if (p.age >= 33 && Math.random() < 0.035) {
      ovr = Math.max(60, ovr - 1);
      attrs.pace = Math.max(40, attrs.pace - 1);
    }

    nextPlayers[pid] = {
      ...p,
      ovr,
      attributes: attrs,
      stamina: Math.min(100, Math.round(p.stamina + baseRecovery + medBonus)),
      injuryWeeks: Math.max(0, p.injuryWeeks - 1),
      injuryName: p.injuryWeeks - 1 <= 0 ? undefined : p.injuryName,
      suspendedWeeks: Math.max(0, p.suspendedWeeks - 1),
    };
  }

  // Auto-update AI club lineups after injuries/suspensions
  for (const cid of Object.keys(nextClubs)) {
    if (cid === state.userClubId) continue;
    const c = nextClubs[cid];
    const cPlayers = Object.values(nextPlayers).filter((p) => p.clubId === cid);
    const best = pickBestLineup(cPlayers, c.tactics.formation);
    nextClubs[cid] = { ...c, startingXI: best.startingXI, bench: best.bench };
  }

  // 5. AI Rival Transfers & Incoming Offers
  const aiTransferRes = runAiTransfersAndOffers(
    nextClubs,
    nextPlayers,
    state.userClubId,
    state.week,
    state.seasonLabel
  );
  nextClubs = aiTransferRes.clubs;
  nextPlayers = aiTransferRes.players;

  // Keep non-expired offers + new incoming offers
  const activeOffers = [
    ...state.incomingOffers.filter((o) => o.expiresWeek > state.week && nextPlayers[o.playerId]?.clubId === state.userClubId),
    ...aiTransferRes.newOffers,
  ];

  // 6. Press & Fan Reactions for User
  const userMatchesThisWeek = weekMatches.filter(
    (m) => m.homeClubId === state.userClubId || m.awayClubId === state.userClubId
  );
  const { press, fans } = generateWeeklyPressAndFans(
    nextClubs[state.userClubId],
    userMatchesThisWeek,
    nextClubs,
    state.week
  );

  // 7. Check Season End (after Week 18)
  const isSeasonOver = state.week >= state.maxLeagueWeeks;
  let latestAwards = state.latestAwards;
  const nextHistory = [...state.history];

  if (isSeasonOver) {
    // Distribute Season League & Cup Prize Money
    const leagueChampions = {} as Record<LeagueId, string>;
    (Object.keys(LEAGUES_DATA) as LeagueId[]).forEach((lid) => {
      const table = getLeagueStandings(lid, nextClubs, allFixtures);
      const champId = table[0]?.clubId;
      if (champId) {
        leagueChampions[lid] = nextClubs[champId].name;
      }
      table.forEach((row, idx) => {
        const prize = Number(
          (state.leagues[lid].championPrize * Math.max(0.2, 1 - idx * 0.085)).toFixed(1)
        );
        const c = nextClubs[row.clubId];
        if (c) {
          nextClubs[c.id] = {
            ...c,
            cash: Number((c.cash + prize).toFixed(1)),
            transferBudget: Number((c.transferBudget + prize * 0.6).toFixed(1)),
          };
          if (c.id === state.userClubId) {
            nextCashFlow.push({
              week: state.week,
              category: 'ODUL',
              label: `${state.leagues[lid].name} ${idx + 1}. Sıra Ödül Primi`,
              amount: prize,
            });
          }
        }
      });
    });

    const userLeague = nextClubs[state.userClubId].leagueId;
    const userTable = getLeagueStandings(userLeague, nextClubs, allFixtures);
    const userPos = userTable.findIndex((r) => r.clubId === state.userClubId) + 1;
    const userPts = userTable[userPos - 1]?.points ?? 0;

    const ccFinal = allFixtures.find((f) => f.competition === 'CHAMPIONS_CUP' && f.roundName === 'Final');
    const esFinal = allFixtures.find((f) => f.competition === 'EUROPA_SHIELD' && f.roundName === 'Final');
    const cupFinal = allFixtures.find(
      (f) => f.competition === 'CUP' && f.leagueId === userLeague && f.roundName === 'Kupa Finali'
    );

    const getWinnerName = (fx?: MatchFixture) => {
      if (!fx || !fx.played) return '-';
      const winId =
        (fx.homeGoals ?? 0) > (fx.awayGoals ?? 0)
          ? fx.homeClubId
          : (fx.awayGoals ?? 0) > (fx.homeGoals ?? 0)
          ? fx.awayClubId
          : fx.penaltyWinnerId ?? fx.homeClubId;
      return nextClubs[winId]?.name ?? '-';
    };

    const tempState: CareerState = {
      ...state,
      clubs: nextClubs,
      players: nextPlayers,
      fixtures: allFixtures,
    };
    latestAwards = computeSeasonAwards(tempState);

    nextHistory.unshift({
      seasonLabel: state.seasonLabel,
      clubId: state.userClubId,
      clubName: nextClubs[state.userClubId].name,
      leaguePosition: userPos,
      leagueName: state.leagues[userLeague].name,
      cupResult:
        cupFinal && (cupFinal.homeClubId === state.userClubId || cupFinal.awayClubId === state.userClubId)
          ? getWinnerName(cupFinal) === nextClubs[state.userClubId].name
            ? 'Şampiyon'
            : 'Finalist'
          : 'Elendi',
      europeResult:
        ccFinal && (ccFinal.homeClubId === state.userClubId || ccFinal.awayClubId === state.userClubId)
          ? getWinnerName(ccFinal) === nextClubs[state.userClubId].name
            ? 'Şampiyonlar Kupası Şampiyonu'
            : 'Şampiyonlar Kupası Finalisti'
          : 'Turnuva Katılımı',
      points: userPts,
      awards: latestAwards,
      leagueChampions,
      championsCupWinner: getWinnerName(ccFinal),
      europaShieldWinner: getWinnerName(esFinal),
    });

    nextNews.unshift({
      id: `news_end_${state.seasonIndex}`,
      week: state.week,
      category: 'ODUL',
      title: `${state.seasonLabel} Sezonu Tamamlandı!`,
      summary: `${state.leagues[userLeague].name} şampiyonu ${leagueChampions[userLeague]}. Ödül töreni ve yeni sezon hazırlıkları başladı.`,
    });
  }

  return {
    ...state,
    week: isSeasonOver ? state.week : state.week + 1,
    phase: isSeasonOver ? 'SEASON_END' : 'REGULAR',
    clubs: nextClubs,
    players: nextPlayers,
    fixtures: allFixtures,
    transfers: [...aiTransferRes.newTransfers, ...state.transfers],
    incomingOffers: activeOffers,
    cashFlowLog: nextCashFlow.slice(-60),
    pressQuestion: press ?? state.pressQuestion,
    fanReactions: [...fans, ...state.fanReactions].slice(0, 25),
    news: [...aiTransferRes.newNews, ...nextNews].slice(0, 35),
    history: nextHistory,
    latestAwards,
  };
}

export function startNextSeason(state: CareerState): CareerState {
  const nextSeasonIdx = state.seasonIndex + 1;
  const startYear = 2026 + nextSeasonIdx;
  const nextSeasonLabel = `${startYear}-${startYear + 1}`;

  const nextClubs = { ...state.clubs };
  const nextPlayers = { ...state.players };

  // Age all players +1, reset season stats, renew expiring AI contracts
  for (const pid of Object.keys(nextPlayers)) {
    const p = nextPlayers[pid];
    const nextAge = p.age + 1;
    let ovr = p.ovr;
    if (nextAge <= 22 && ovr < p.pot) ovr = Math.min(p.pot, ovr + 1);
    else if (nextAge >= 34) ovr = Math.max(60, ovr - 1);

    const newVal = Number(
      Math.max(0.8, p.marketValue * (nextAge <= 24 ? 1.08 : nextAge >= 31 ? 0.8 : 0.98)).toFixed(1)
    );

    nextPlayers[pid] = {
      ...p,
      age: nextAge,
      ovr,
      marketValue: newVal,
      contractYearsLeft: p.contractYearsLeft <= 1 ? 2 : p.contractYearsLeft - 1,
      stamina: 96,
      injuryWeeks: 0,
      injuryName: undefined,
      suspendedWeeks: 0,
      yellowAccumulator: 0,
      stats: {
        apps: 0,
        goals: 0,
        assists: 0,
        cleanSheets: 0,
        yellowCards: 0,
        redCards: 0,
        ratingSum: 0,
      },
    };
  }

  // Generate 1 Academy Youth prospect per club based on Academy Facility Level
  let youthSeq = Date.now();
  for (const club of Object.values(nextClubs)) {
    const posPool: Position[] = ['DEF', 'MID', 'FWD'];
    const pos = posPool[nextSeasonIdx % posPool.length];
    const baseOvr = 64 + club.facilities.academy * 2;
    const pot = Math.min(93, baseOvr + 9 + club.facilities.academy * 2);
    const id = `p_y_${youthSeq++}`;
    nextPlayers[id] = {
      id,
      name: `${club.shortName} Altyapı #${nextSeasonIdx + 1}`,
      age: 17,
      nationality: state.leagues[club.leagueId].country,
      position: pos,
      ovr: baseOvr,
      pot,
      marketValue: Number((baseOvr * 0.08).toFixed(1)),
      weeklyWage: 10,
      contractYearsLeft: 4,
      stamina: 98,
      morale: 85,
      form: 7.0,
      injuryWeeks: 0,
      suspendedWeeks: 0,
      yellowAccumulator: 0,
      role: pos === 'DEF' ? 'DEF_BALL' : pos === 'MID' ? 'MID_B2B' : 'FWD_INSIDE',
      attributes: {
        pace: baseOvr + 4,
        shooting: baseOvr,
        passing: baseOvr + 1,
        dribbling: baseOvr + 2,
        defending: pos === 'DEF' ? baseOvr + 2 : baseOvr - 15,
        physical: baseOvr - 2,
      },
      stats: { apps: 0, goals: 0, assists: 0, cleanSheets: 0, yellowCards: 0, redCards: 0, ratingSum: 0 },
      transferListed: false,
      clubId: club.id,
    };
    const clubPlayers = Object.values(nextPlayers).filter((p) => p.clubId === club.id);
    const best = pickBestLineup(clubPlayers, club.tactics.formation);
    nextClubs[club.id] = {
      ...club,
      transferBudget: Number((club.cash * 0.65).toFixed(1)),
      startingXI: best.startingXI,
      bench: best.bench,
    };
  }

  // Generate new season fixtures
  let fixtures: MatchFixture[] = [];
  (Object.keys(LEAGUES_DATA) as LeagueId[]).forEach((lid) => {
    const ids = Object.values(nextClubs)
      .filter((c) => c.leagueId === lid)
      .map((c) => c.id);
    fixtures = fixtures.concat(generateRoundRobinFixtures(ids, lid, nextSeasonIdx));
  });
  fixtures = fixtures.concat(generateInitialKnockoutCups(nextClubs, nextSeasonIdx));

  return {
    ...state,
    seasonIndex: nextSeasonIdx,
    seasonLabel: nextSeasonLabel,
    week: 1,
    phase: 'REGULAR',
    clubs: nextClubs,
    players: nextPlayers,
    fixtures,
    incomingOffers: [],
    latestAwards: [],
    news: [
      {
        id: `news_new_${nextSeasonIdx}`,
        week: 1,
        category: 'YONETIM' as const,
        title: `${nextSeasonLabel} Sezonu Başladı!`,
        summary: `Altyapıdan yeni genç yetenekler A takıma yükseldi ve yaz transfer dönemi açıldı.`,
      },
      ...state.news,
    ].slice(0, 35),
  };
}
