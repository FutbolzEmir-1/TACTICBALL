import { FORMATION_SLOTS, pickBestLineup } from '../data/database2026_27';
import {
  Club,
  ClubTactics,
  MatchEvent,
  MatchFixture,
  MatchStats,
  Player,
  Position,
} from '../types/game';

const INJURY_NAMES = [
  'Kas Zorlanması',
  'Arka Adale Çekmesi',
  'Ayak Bileği Burkulması',
  'Diz Esnemesi',
  'Kasık Ağrısı',
];

export interface LiveMatchState {
  fixtureId: string;
  minute: number;
  finished: boolean;
  homeClubId: string;
  awayClubId: string;
  homeGoals: number;
  awayGoals: number;
  homeXI: string[];
  awayXI: string[];
  homeBench: string[];
  awayBench: string[];
  homeTactics: ClubTactics;
  awayTactics: ClubTactics;
  homeSubsUsed: number;
  awaySubsUsed: number;
  homeRedIds: string[];
  awayRedIds: string[];
  homeYellowIds: string[];
  awayYellowIds: string[];
  homeInjuredOutIds: string[];
  awayInjuredOutIds: string[];
  playedPlayerIds: string[];
  events: MatchEvent[];
  stats: MatchStats;
  playerRatings: Record<string, number>;
  homePossessionTicks: number;
  awayPossessionTicks: number;
  penaltyWinnerId?: string;
}

export interface TeamStrength {
  attack: number;
  midfield: number;
  defense: number;
  gk: number;
  overall: number;
}

function getPositionalFit(player: Player, targetSlot: Position): number {
  if (player.position === targetSlot) return 1.0;
  if (player.secondaryPosition === targetSlot) return 0.95;
  if (targetSlot === 'GK' || player.position === 'GK') return 0.42;
  if (
    (player.position === 'DEF' && targetSlot === 'MID') ||
    (player.position === 'MID' && (targetSlot === 'DEF' || targetSlot === 'FWD')) ||
    (player.position === 'FWD' && targetSlot === 'MID')
  ) {
    return 0.89;
  }
  return 0.74;
}

export function evaluateTeamStrength(
  club: Club,
  players: Record<string, Player>,
  xiIds: string[],
  tactics: ClubTactics,
  redCardIds: string[] = []
): TeamStrength {
  const slots = FORMATION_SLOTS[tactics.formation];
  let gkSum = 0;
  let gkCount = 0;
  let defSum = 0;
  let defCount = 0;
  let midSum = 0;
  let midCount = 0;
  let fwdSum = 0;
  let fwdCount = 0;

  xiIds.forEach((pid, idx) => {
    if (redCardIds.includes(pid)) return;
    const p = players[pid];
    if (!p) return;
    const slotPos = slots[idx] ?? p.position;
    const fit = getPositionalFit(p, slotPos);
    const staminaFactor =
      p.stamina >= 80
        ? 1.0
        : p.stamina >= 60
        ? 0.9 + ((p.stamina - 60) / 20) * 0.1
        : 0.76 + (p.stamina / 60) * 0.14;
    const moraleFactor = 0.93 + (p.morale / 100) * 0.14;
    const eff = p.ovr * fit * staminaFactor * moraleFactor;

    if (slotPos === 'GK') {
      gkSum += eff;
      gkCount++;
    } else if (slotPos === 'DEF') {
      const wingBonus = p.role === 'DEF_WINGBACK' ? 1.02 : 1.0;
      defSum += eff * (p.role === 'DEF_STOPPER' ? 1.03 : 1.0);
      if (wingBonus > 1) fwdSum += eff * 0.08;
      defCount++;
    } else if (slotPos === 'MID') {
      midSum += eff;
      if (p.role === 'MID_ANCHOR') defSum += eff * 0.12;
      if (p.role === 'MID_CAM') fwdSum += eff * 0.15;
      midCount++;
    } else {
      fwdSum += eff * (p.role === 'FWD_COMPLETE' || p.role === 'FWD_POACHER' ? 1.03 : 1.0);
      fwdCount++;
    }
  });

  const gk = gkCount > 0 ? gkSum / gkCount : 55;
  let defense = defCount > 0 ? defSum / defCount : 60;
  let midfield = midCount > 0 ? midSum / midCount : 60;
  let attack = fwdCount > 0 ? fwdSum / fwdCount : 60;

  // Tactical modifiers
  if (tactics.mentality === 'DEFENSIVE') {
    defense *= 1.07;
    attack *= 0.92;
  } else if (tactics.mentality === 'ATTACKING') {
    attack *= 1.06;
    defense *= 0.95;
  } else if (tactics.mentality === 'ALL_OUT') {
    attack *= 1.12;
    defense *= 0.87;
  }

  if (tactics.pressing === 'GEGENPRESS') {
    midfield *= 1.05;
    attack *= 1.03;
  } else if (tactics.pressing === 'LOW') {
    defense *= 1.04;
    midfield *= 0.96;
  }

  if (tactics.passing === 'SHORT') {
    midfield *= 1.03;
  } else if (tactics.passing === 'DIRECT') {
    attack *= 1.03;
    midfield *= 0.98;
  }

  // Red card penalty
  const redPenalty = Math.max(0.65, 1 - redCardIds.length * 0.1);
  defense *= redPenalty;
  midfield *= redPenalty;
  attack *= redPenalty;

  const overall = gk * 0.15 + defense * 0.28 + midfield * 0.3 + attack * 0.27;
  return { attack, midfield, defense, gk, overall };
}

function weightedPick(
  xiIds: string[],
  players: Record<string, Player>,
  redIds: string[],
  weightFn: (p: Player) => number
): Player | null {
  const candidates = xiIds
    .filter((id) => !redIds.includes(id))
    .map((id) => players[id])
    .filter(Boolean);
  if (candidates.length === 0) return null;

  const weights = candidates.map((p) => Math.max(0.05, weightFn(p)));
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < candidates.length; i++) {
    r -= weights[i];
    if (r <= 0) return candidates[i];
  }
  return candidates[0];
}

export function createLiveMatchState(
  fixture: MatchFixture,
  clubs: Record<string, Club>,
  players: Record<string, Player>
): LiveMatchState {
  const home = clubs[fixture.homeClubId];
  const away = clubs[fixture.awayClubId];

  // Ensure AI clubs always field healthy, non-suspended best XI
  const ensureValidXI = (club: Club): { xi: string[]; bench: string[] } => {
    const clubPlayers = Object.values(players).filter((p) => p.clubId === club.id);
    const validXI = club.startingXI.filter(
      (id) => players[id] && players[id].injuryWeeks === 0 && players[id].suspendedWeeks === 0
    );
    if (validXI.length === 11) {
      return {
        xi: validXI,
        bench: club.bench.filter(
          (id) => players[id] && players[id].injuryWeeks === 0 && players[id].suspendedWeeks === 0
        ),
      };
    }
    const best = pickBestLineup(clubPlayers, club.tactics.formation);
    return { xi: best.startingXI, bench: best.bench };
  };

  const hLineup = ensureValidXI(home);
  const aLineup = ensureValidXI(away);

  const playerRatings: Record<string, number> = {};
  [...hLineup.xi, ...aLineup.xi].forEach((id) => {
    playerRatings[id] = 6.5;
  });

  return {
    fixtureId: fixture.id,
    minute: 0,
    finished: false,
    homeClubId: home.id,
    awayClubId: away.id,
    homeGoals: 0,
    awayGoals: 0,
    homeXI: [...hLineup.xi],
    awayXI: [...aLineup.xi],
    homeBench: [...hLineup.bench],
    awayBench: [...aLineup.bench],
    homeTactics: { ...home.tactics },
    awayTactics: { ...away.tactics },
    homeSubsUsed: 0,
    awaySubsUsed: 0,
    homeRedIds: [],
    awayRedIds: [],
    homeYellowIds: [],
    awayYellowIds: [],
    homeInjuredOutIds: [],
    awayInjuredOutIds: [],
    playedPlayerIds: [...hLineup.xi, ...aLineup.xi],
    events: [],
    stats: {
      homePossession: 50,
      homeShots: 0,
      awayShots: 0,
      homeShotsOnTarget: 0,
      awayShotsOnTarget: 0,
      homeXG: 0,
      awayXG: 0,
    },
    playerRatings,
    homePossessionTicks: 1,
    awayPossessionTicks: 1,
  };
}

export function performLiveSubstitution(
  state: LiveMatchState,
  side: 'HOME' | 'AWAY',
  outPlayerId: string,
  inPlayerId: string
): LiveMatchState {
  const isHome = side === 'HOME';
  const subsUsed = isHome ? state.homeSubsUsed : state.awaySubsUsed;
  if (subsUsed >= 5) return state;

  const xi = isHome ? [...state.homeXI] : [...state.awayXI];
  const bench = isHome ? [...state.homeBench] : [...state.awayBench];
  const outIdx = xi.indexOf(outPlayerId);
  const inIdx = bench.indexOf(inPlayerId);
  if (outIdx === -1 || inIdx === -1) return state;

  xi[outIdx] = inPlayerId;
  bench.splice(inIdx, 1);

  const nextRatings = { ...state.playerRatings };
  if (!nextRatings[inPlayerId]) nextRatings[inPlayerId] = 6.4;

  return {
    ...state,
    homeXI: isHome ? xi : state.homeXI,
    awayXI: isHome ? state.awayXI : xi,
    homeBench: isHome ? bench : state.homeBench,
    awayBench: isHome ? state.awayBench : bench,
    homeSubsUsed: isHome ? subsUsed + 1 : state.homeSubsUsed,
    awaySubsUsed: isHome ? state.awaySubsUsed : subsUsed + 1,
    playedPlayerIds: state.playedPlayerIds.includes(inPlayerId)
      ? state.playedPlayerIds
      : [...state.playedPlayerIds, inPlayerId],
    playerRatings: nextRatings,
  };
}

export function stepLiveMatchMinute(
  state: LiveMatchState,
  clubs: Record<string, Club>,
  players: Record<string, Player>,
  isKnockout = false
): LiveMatchState {
  if (state.finished) return state;

  const nextMin = state.minute + 1;
  const home = clubs[state.homeClubId];
  const away = clubs[state.awayClubId];

  const homeStr = evaluateTeamStrength(home, players, state.homeXI, state.homeTactics, state.homeRedIds);
  const awayStr = evaluateTeamStrength(away, players, state.awayXI, state.awayTactics, state.awayRedIds);

  // Subtle realistic home advantage (+3.2 OVR equivalent)
  const hMid = homeStr.midfield + 2.5;
  const aMid = awayStr.midfield;
  const midDiff = hMid - aMid;
  const homeShare = Math.max(0.28, Math.min(0.72, 0.5 + midDiff * 0.015));

  const homeHasBall = Math.random() < homeShare;
  let homePossTicks = state.homePossessionTicks + (homeHasBall ? 1 : 0);
  let awayPossTicks = state.awayPossessionTicks + (homeHasBall ? 0 : 1);

  const nextEvents = [...state.events];
  const nextStats = { ...state.stats };
  const nextRatings = { ...state.playerRatings };
  let homeGoals = state.homeGoals;
  let awayGoals = state.awayGoals;
  const homeRedIds = [...state.homeRedIds];
  const awayRedIds = [...state.awayRedIds];
  const homeYellowIds = [...state.homeYellowIds];
  const awayYellowIds = [...state.awayYellowIds];
  const homeInjuredOutIds = [...state.homeInjuredOutIds];
  const awayInjuredOutIds = [...state.awayInjuredOutIds];

  // Auto-AI substitutions around 62' and 76'
  let workingState: LiveMatchState = state;
  const tryAiSub = (side: 'HOME' | 'AWAY') => {
    const subsUsed = side === 'HOME' ? workingState.homeSubsUsed : workingState.awaySubsUsed;
    const xi = side === 'HOME' ? workingState.homeXI : workingState.awayXI;
    const bench = side === 'HOME' ? workingState.homeBench : workingState.awayBench;
    const redIds = side === 'HOME' ? homeRedIds : awayRedIds;
    if (subsUsed >= 4 || bench.length === 0) return;

    const tiredOut = xi
      .filter((id) => !redIds.includes(id) && players[id]?.position !== 'GK')
      .sort((a, b) => (players[a]?.stamina ?? 80) - (players[b]?.stamina ?? 80))[0];
    if (!tiredOut) return;

    const outPos = players[tiredOut]?.position;
    const freshIn =
      bench.find((id) => players[id]?.position === outPos) ||
      bench.find((id) => players[id]?.position !== 'GK');
    if (freshIn) {
      workingState = performLiveSubstitution(workingState, side, tiredOut, freshIn);
      nextEvents.push({
        minute: nextMin,
        type: 'SUB',
        clubId: side === 'HOME' ? home.id : away.id,
        playerId: freshIn,
        playerName: players[freshIn]?.name ?? '',
        assistPlayerId: tiredOut,
        assistPlayerName: players[tiredOut]?.name ?? '',
        detail: `${players[freshIn]?.name} oyuna girdi (${players[tiredOut]?.name} çıktı).`,
      });
    }
  };

  // Tempo determines event density (~0.27–0.34 chance events per minute across both teams)
  const tempoBoost =
    (state.homeTactics.tempo === 'HIGH' ? 0.03 : state.homeTactics.tempo === 'SLOW' ? -0.02 : 0) +
    (state.awayTactics.tempo === 'HIGH' ? 0.03 : state.awayTactics.tempo === 'SLOW' ? -0.02 : 0);

  const shotChance = Math.max(0.18, Math.min(0.36, 0.26 + tempoBoost));

  if (Math.random() < shotChance) {
    const attIsHome = Math.random() < homeShare * 0.92 + (homeStr.attack - awayStr.attack) * 0.004;
    const attClub = attIsHome ? home : away;
    const defClub = attIsHome ? away : home;
    const attXI = attIsHome ? workingState.homeXI : workingState.awayXI;
    const defXI = attIsHome ? workingState.awayXI : workingState.homeXI;
    const attReds = attIsHome ? homeRedIds : awayRedIds;
    const defReds = attIsHome ? awayRedIds : homeRedIds;
    const attPower = attIsHome ? homeStr.attack + 2.5 : awayStr.attack;
    const defPower = attIsHome ? awayStr.defense : homeStr.defense + 2.0;
    const defGK = attIsHome ? awayStr.gk : homeStr.gk;

    const shooter = weightedPick(attXI, players, attReds, (p) => {
      if (p.position === 'FWD') return p.role === 'FWD_POACHER' ? 5.2 : 4.2;
      if (p.position === 'MID') return p.role === 'MID_CAM' ? 2.6 : 1.4;
      if (p.position === 'DEF') return p.role === 'DEF_WINGBACK' ? 0.55 : 0.25;
      return 0.01;
    });

    if (shooter) {
      const qualityDiff = attPower - defPower;
      const baseXG = Math.max(0.05, Math.min(0.42, 0.11 + qualityDiff * 0.0045 + Math.random() * 0.14));
      const isOnTarget = Math.random() < 0.36 + (shooter.attributes.shooting - 70) * 0.006;

      if (attIsHome) {
        nextStats.homeShots += 1;
        nextStats.homeXG = Number((nextStats.homeXG + baseXG).toFixed(2));
        if (isOnTarget) nextStats.homeShotsOnTarget += 1;
      } else {
        nextStats.awayShots += 1;
        nextStats.awayXG = Number((nextStats.awayXG + baseXG).toFixed(2));
        if (isOnTarget) nextStats.awayShotsOnTarget += 1;
      }

      const gkSaveFactor = Math.max(0.72, Math.min(1.25, 1.0 - (defGK - 78) * 0.012));
      const finishBonus = 1 + (shooter.attributes.shooting - 78) * 0.008;
      const goalProb = isOnTarget ? Math.min(0.68, baseXG * 2.15 * gkSaveFactor * finishBonus) : 0;

      if (Math.random() < goalProb) {
        if (attIsHome) homeGoals += 1;
        else awayGoals += 1;

        const assister = weightedPick(
          attXI.filter((id) => id !== shooter.id),
          players,
          attReds,
          (p) => {
            if (p.position === 'MID') return p.role === 'MID_MAESTRO' || p.role === 'MID_CAM' ? 3.8 : 2.3;
            if (p.position === 'FWD') return p.role === 'FWD_WINGER' ? 2.8 : 1.7;
            if (p.position === 'DEF') return p.role === 'DEF_WINGBACK' ? 1.4 : 0.4;
            return 0.05;
          }
        );

        const hasAssist = assister && Math.random() < 0.78;
        nextRatings[shooter.id] = Math.min(10, Number(((nextRatings[shooter.id] ?? 6.5) + 1.1).toFixed(1)));
        if (hasAssist && assister) {
          nextRatings[assister.id] = Math.min(10, Number(((nextRatings[assister.id] ?? 6.5) + 0.65).toFixed(1)));
        }
        // Defending GK slight dip on conceded goal
        const gkId = defXI.find((id) => players[id]?.position === 'GK');
        if (gkId) {
          nextRatings[gkId] = Math.max(4.8, Number(((nextRatings[gkId] ?? 6.5) - 0.25).toFixed(1)));
        }

        nextEvents.push({
          minute: nextMin,
          type: 'GOAL',
          clubId: attClub.id,
          playerId: shooter.id,
          playerName: shooter.name,
          assistPlayerId: hasAssist && assister ? assister.id : undefined,
          assistPlayerName: hasAssist && assister ? assister.name : undefined,
          detail:
            hasAssist && assister
              ? `GOOOL! ${shooter.name} ağları sarsıyor (Asist: ${assister.name})`
              : `GOOOL! ${shooter.name} ceza sahasından mükemmel bitiriyor!`,
        });
      } else if (baseXG > 0.23 && isOnTarget) {
        const gkId = defXI.find((id) => players[id]?.position === 'GK');
        if (gkId) {
          nextRatings[gkId] = Math.min(10, Number(((nextRatings[gkId] ?? 6.5) + 0.25).toFixed(1)));
        }
        nextEvents.push({
          minute: nextMin,
          type: 'BIG_CHANCE',
          clubId: attClub.id,
          playerId: shooter.id,
          playerName: shooter.name,
          detail: `${shooter.name} mutlak gol şansından yararlanamadı, ${defClub.shortName} kalecisi gole izin vermedi.`,
        });
      }
    }
  }

  // Yellow & Red cards (~4% per minute total across pitch)
  if (Math.random() < 0.042) {
    const isHomeFoul = Math.random() < 0.5;
    const fClub = isHomeFoul ? home : away;
    const fXI = isHomeFoul ? workingState.homeXI : workingState.awayXI;
    const fReds = isHomeFoul ? homeRedIds : awayRedIds;
    const fYellows = isHomeFoul ? homeYellowIds : awayYellowIds;
    const pressingFactor =
      (isHomeFoul ? state.homeTactics.pressing : state.awayTactics.pressing) === 'GEGENPRESS' ? 1.25 : 1.0;

    if (Math.random() < 0.85 * pressingFactor) {
      const carded = weightedPick(fXI, players, fReds, (p) =>
        p.position === 'DEF' ? 2.5 : p.position === 'MID' ? 2.0 : 0.8
      );
      if (carded) {
        const isDirectRed = Math.random() < 0.04;
        const isSecondYellow = !isDirectRed && fYellows.includes(carded.id);
        if (isDirectRed || isSecondYellow) {
          fReds.push(carded.id);
          nextRatings[carded.id] = Math.max(4.0, Number(((nextRatings[carded.id] ?? 6.5) - 1.4).toFixed(1)));
          nextEvents.push({
            minute: nextMin,
            type: 'RED',
            clubId: fClub.id,
            playerId: carded.id,
            playerName: carded.name,
            detail: isSecondYellow
              ? `İkinci sarıdan KIRMIZI KART! ${carded.name} oyun dışı.`
              : `Doğrudan KIRMIZI KART! ${carded.name} sert müdahale sonrası atıldı.`,
          });
        } else {
          fYellows.push(carded.id);
          nextRatings[carded.id] = Math.max(5.0, Number(((nextRatings[carded.id] ?? 6.5) - 0.2).toFixed(1)));
          nextEvents.push({
            minute: nextMin,
            type: 'YELLOW',
            clubId: fClub.id,
            playerId: carded.id,
            playerName: carded.name,
            detail: `Sarı Kart: ${carded.name} (${fClub.shortName})`,
          });
        }
      }
    }
  }

  // Injuries (~0.7% per minute, scales up if tired players or low medical center)
  if (Math.random() < 0.0065) {
    const isHomeInj = Math.random() < 0.5;
    const iClub = isHomeInj ? home : away;
    const iXI = isHomeInj ? workingState.homeXI : workingState.awayXI;
    const iReds = isHomeInj ? homeRedIds : awayRedIds;
    const iOut = isHomeInj ? homeInjuredOutIds : awayInjuredOutIds;

    const victim = weightedPick(iXI, players, iReds, (p) => {
      const fatigueRisk = p.stamina < 65 ? 3.2 : p.stamina < 78 ? 1.6 : 0.8;
      return p.position === 'GK' ? 0.1 : fatigueRisk;
    });
    if (victim) {
      const medResist = (iClub.facilities.medical - 1) * 0.1;
      if (Math.random() > medResist) {
        iOut.push(victim.id);
        const injName = INJURY_NAMES[Math.floor(Math.random() * INJURY_NAMES.length)];
        nextEvents.push({
          minute: nextMin,
          type: 'INJURY',
          clubId: iClub.id,
          playerId: victim.id,
          playerName: victim.name,
          detail: `Sakatlık: ${victim.name} (${injName}) oyuna devam edemiyor.`,
        });
        // Auto-replace injured player if bench & subs remain
        const subsUsed = isHomeInj ? workingState.homeSubsUsed : workingState.awaySubsUsed;
        const bench = isHomeInj ? workingState.homeBench : workingState.awayBench;
        if (subsUsed < 5 && bench.length > 0) {
          const rep = bench.find((id) => players[id]?.position === victim.position) ?? bench[0];
          workingState = performLiveSubstitution(workingState, isHomeInj ? 'HOME' : 'AWAY', victim.id, rep);
        }
      }
    }
  }

  // AI substitutions at minutes 63 and 77 (note: only for AI sides when quick-simmed, or handled externally for user)
  if (nextMin === 63 || nextMin === 77) {
    // Callers with user control handle user side; quick sim sets both
    workingState = { ...workingState };
  }

  const finished = nextMin >= 90;
  let penaltyWinnerId: string | undefined;
  if (finished && isKnockout && homeGoals === awayGoals) {
    const hPen = homeStr.overall + homeStr.gk * 0.25 + (Math.random() * 14 - 7);
    const aPen = awayStr.overall + awayStr.gk * 0.25 + (Math.random() * 14 - 7);
    penaltyWinnerId = hPen >= aPen ? home.id : away.id;
  }

  nextStats.homePossession = Math.round((homePossTicks / (homePossTicks + awayPossTicks)) * 100);

  return {
    ...workingState,
    minute: nextMin,
    finished,
    homeGoals,
    awayGoals,
    homeRedIds,
    awayRedIds,
    homeYellowIds,
    awayYellowIds,
    homeInjuredOutIds,
    awayInjuredOutIds,
    events: nextEvents,
    stats: nextStats,
    playerRatings: nextRatings,
    homePossessionTicks: homePossTicks,
    awayPossessionTicks: awayPossTicks,
    penaltyWinnerId,
  };
}

export function quickSimulateMatch(
  fixture: MatchFixture,
  clubs: Record<string, Club>,
  players: Record<string, Player>
): LiveMatchState {
  let state = createLiveMatchState(fixture, clubs, players);
  for (let m = 1; m <= 90; m++) {
    state = stepLiveMatchMinute(state, clubs, players, Boolean(fixture.isKnockout));
    if (m === 62 || m === 76) {
      // Let both AI clubs use subs realistically
      const doSub = (side: 'HOME' | 'AWAY') => {
        const xi = side === 'HOME' ? state.homeXI : state.awayXI;
        const bench = side === 'HOME' ? state.homeBench : state.awayBench;
        const reds = side === 'HOME' ? state.homeRedIds : state.awayRedIds;
        if (bench.length === 0) return;
        const outId = xi.find((id) => !reds.includes(id) && players[id]?.position !== 'GK');
        const inId = bench.find((id) => players[id]?.position !== 'GK');
        if (outId && inId) {
          state = performLiveSubstitution(state, side, outId, inId);
        }
      };
      doSub('HOME');
      doSub('AWAY');
    }
  }
  return state;
}

export function applyMatchResultToDatabase(
  fixture: MatchFixture,
  result: LiveMatchState,
  clubs: Record<string, Club>,
  players: Record<string, Player>
): {
  updatedFixture: MatchFixture;
  updatedClubs: Record<string, Club>;
  updatedPlayers: Record<string, Player>;
} {
  const nextClubs = { ...clubs };
  const nextPlayers = { ...players };

  const homeWon =
    result.homeGoals > result.awayGoals || result.penaltyWinnerId === result.homeClubId;
  const awayWon =
    result.awayGoals > result.homeGoals || result.penaltyWinnerId === result.awayClubId;
  const isDraw = result.homeGoals === result.awayGoals && !result.penaltyWinnerId;

  // Determine MOTM
  let motmId: string | undefined;
  let bestRating = -1;
  for (const [pid, rating] of Object.entries(result.playerRatings)) {
    if (rating > bestRating) {
      bestRating = rating;
      motmId = pid;
    }
  }

  // Update player stats, stamina, cards, injuries, morale
  const homeDrain =
    result.homeTactics.pressing === 'GEGENPRESS'
      ? 22
      : result.homeTactics.pressing === 'MEDIUM'
      ? 16
      : 12;
  const awayDrain =
    result.awayTactics.pressing === 'GEGENPRESS'
      ? 22
      : result.awayTactics.pressing === 'MEDIUM'
      ? 16
      : 12;

  for (const pid of result.playedPlayerIds) {
    const p = nextPlayers[pid];
    if (!p) continue;
    const isHome = p.clubId === result.homeClubId;
    const drain = (isHome ? homeDrain : awayDrain) + (p.position === 'GK' ? -8 : 0);
    const won = isHome ? homeWon : awayWon;
    const lost = isHome ? awayWon : homeWon;

    const goalsInMatch = result.events.filter((e) => e.type === 'GOAL' && e.playerId === pid).length;
    const assistsInMatch = result.events.filter(
      (e) => e.type === 'GOAL' && e.assistPlayerId === pid
    ).length;
    const yellowsInMatch = result.events.filter(
      (e) => e.type === 'YELLOW' && e.playerId === pid
    ).length;
    const redsInMatch = result.events.filter((e) => e.type === 'RED' && e.playerId === pid).length;
    const injuredInMatch = result.events.some((e) => e.type === 'INJURY' && e.playerId === pid);

    const matchRating = result.playerRatings[pid] ?? 6.5;
    const cleanSheet =
      p.position === 'GK' || p.position === 'DEF'
        ? (isHome ? result.awayGoals === 0 : result.homeGoals === 0)
          ? 1
          : 0
        : 0;

    let yellowAcc = p.yellowAccumulator + yellowsInMatch;
    let susp = p.suspendedWeeks;
    if (redsInMatch > 0) {
      susp = Math.max(susp, 1);
    } else if (yellowAcc >= 4) {
      yellowAcc -= 4;
      susp = Math.max(susp, 1);
    }

    let injuryWeeks = p.injuryWeeks;
    let injuryName = p.injuryName;
    if (injuredInMatch) {
      const medLevel = nextClubs[p.clubId]?.facilities.medical ?? 2;
      injuryWeeks = Math.max(1, 2 + Math.floor(Math.random() * 4) - Math.floor(medLevel / 2));
      injuryName = INJURY_NAMES[Math.floor(Math.random() * INJURY_NAMES.length)];
    }

    const moraleDelta = won ? 4 : isDraw ? 0 : -4;

    nextPlayers[pid] = {
      ...p,
      stamina: Math.max(25, p.stamina - Math.max(4, drain)),
      morale: Math.max(30, Math.min(99, p.morale + moraleDelta)),
      form: Number(((p.form * 2 + matchRating) / 3).toFixed(1)),
      yellowAccumulator: yellowAcc,
      suspendedWeeks: susp,
      injuryWeeks,
      injuryName,
      stats: {
        apps: p.stats.apps + 1,
        goals: p.stats.goals + goalsInMatch,
        assists: p.stats.assists + assistsInMatch,
        cleanSheets: p.stats.cleanSheets + cleanSheet,
        yellowCards: p.stats.yellowCards + yellowsInMatch,
        redCards: p.stats.redCards + redsInMatch,
        ratingSum: Number((p.stats.ratingSum + matchRating).toFixed(1)),
      },
    };
  }

  // Update club ratings and fan/board micro-sentiment
  const adjustClubAfterMatch = (clubId: string, won: boolean, lost: boolean, gf: number, ga: number) => {
    const c = nextClubs[clubId];
    if (!c) return;
    const diff = gf - ga;
    const fanDelta = won ? 2 + (diff >= 3 ? 2 : 0) : lost ? -3 - (diff <= -3 ? 2 : 0) : 0;
    const boardDelta = won ? 1 : lost ? -2 : 0;
    nextClubs[clubId] = {
      ...c,
      fanSupport: Math.max(15, Math.min(99, c.fanSupport + fanDelta)),
      boardTrust: Math.max(10, Math.min(99, c.boardTrust + boardDelta)),
      lastMatchRatings: result.playerRatings,
    };
  };

  adjustClubAfterMatch(result.homeClubId, homeWon, awayWon, result.homeGoals, result.awayGoals);
  adjustClubAfterMatch(result.awayClubId, awayWon, homeWon, result.awayGoals, result.homeGoals);

  const updatedFixture: MatchFixture = {
    ...fixture,
    played: true,
    homeGoals: result.homeGoals,
    awayGoals: result.awayGoals,
    penaltyWinnerId: result.penaltyWinnerId,
    events: result.events,
    stats: result.stats,
    playerRatings: result.playerRatings,
    manOfTheMatchId: motmId,
  };

  return { updatedFixture, updatedClubs: nextClubs, updatedPlayers: nextPlayers };
}
