import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.tacticball.game',
  appName: 'TACTICBALL',
  webDir: 'dist',
};

export default config;
